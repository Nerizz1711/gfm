<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>CU-CAT</title>

  <?php echo $__env->make("$prefix.layout.stylesheet", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</head>

<body>

  <section id="content">
    <div class="history-detail">
      <div class="mobile-size">
        <!-- Header -->
        <?php echo $__env->make("$prefix.layout.header", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <!-- End Header -->

        <div class="row">
          <div class="col-xl-12">
            <div class="box-heading">
              <p class="name-heading"><?php echo e(@$question->curse_detail); ?> : ครั้งที่ <?php echo e(@$time->sort); ?></p>
            </div>
            <div>
              <div class="box-history-detail">
                <div class="box-history-top">
                  <div class="row">
                    <div class="col-6">
                      <h5>พบหมอครั้งที่ <?php echo e($time->sort); ?></h5>
                      <p class="date-history"><?php echo e(date('d/m/Y',strtotime('+543 Years',strtotime($time->datetime_service)))); ?></p>
                    </div>
                    <div class="col-6">
                      <select class="form-select" onchange="location = this.value;">
                        <?php if(@$question_times): ?>
                          <?php $__currentLoopData = @$question_times; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e(url("history-detail?question=$item->question_head_id&time=$item->id")); ?>" <?php if($item->id == @Request::get('time')): ?> selected <?php endif; ?>>ครั้งที่ <?php echo e($item->sort); ?></option>
                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                      </select>
                    </div>

                    <div class="col-12 text-center">
                      <div id="chart"></div>
                      <p class="result-item">ผลการประเมินครั้งที่ <?php echo e(@$time->sort); ?> : <span><?php echo e(@$curse['result_point']); ?>%</span></p>
                    </div>
                  </div>
                </div>

                <div class="row">

                  <!-- Box Detail Result Score  -->
                  <div class="col-12">
                    <div class="box-detail-result-score">
                      <h5>ผลการทดสอบครั้งที่ <?php echo e(@$time->sort); ?></h5>
                      <p class="date-history"><?php echo e(date('d/m/Y',strtotime('+543 Years',strtotime($time->datetime_service)))); ?></p>

                      <div class="box-bigScore">
                        <h1 class="text-big"><?php echo e(@$curse['result_point']); ?>% </h1> <span class="text-small">รวมคะแนน</span>
                      </div>

                      <div id="chart2"></div>

                      <div class="box-detailchart">
                        <div class="icon-chart"></div> <span>คะแนนคิดเป็นเปอร์เซ็นเต็ม 100%</span>
                      </div>
                    </div>
                  </div>
                  <!-- End Box Detail Result Score -->

                  <!-- Box Result Score -->
                  <div class="box-resultscore">
                    <h5>รายละเอียดคะแนน</h5>

                    <div class="item-score">
                      <div class="row">
                        <!-- Vas -->
                        <div class="col-6">
                          <p class="text-left">แบบทดสอบ VAS :</p>
                        </div>
                        <div class="col-6">
                          <p class="text-right"><?php echo e(@$time->vas_point); ?> คะแนน</p>
                        </div>

                        <!-- Womac -->
                        <div class="col-6">
                          <p class="text-left">แบบทดสอบ Womac :</p>
                        </div>
                        <div class="col-6">
                          <p class="text-right"><?php echo e(@$time->womac_point); ?> คะแนน</p>
                        </div>

                        <!-- SF-12 -->
                        <div class="col-6">
                          <p class="text-left">แบบทดสอบ SF-12 :</p>
                        </div>
                        <div class="col-6">
                          <p class="text-right"><?php echo e(@$time->sf12_point); ?> คะแนน</p>
                        </div>
                        <div class="col-6">
                          <p class="text-resultleft">รวมคะแนน:</p>
                        </div>
                        <div class="col-6">
                          <p class="text-resultright"><?php echo e(@$curse['result_point']); ?>%</p>
                        </div>
                      </div>
                    </div>
                  </div>
                  <!-- End Box Result Score -->

                  <!-- Box Detail Profile Doctor -->
                  <div class="box-detail-profile">
                    <h5>รายละเอียดการรักษา</h5>

                    <div class="item-detail">
                      <div class="row">
                        <div class="col-xl-6 col-lg-6 col-md-6 col-sm-6 col-6">
                          <p class="detail-left">
                            <img src="assets/img/menu-icon/icon-pill.svg" class="img-fluid" alt=""> กลุ่มการรักษา:
                          </p>
                        </div>
                        <div class="col-xl-6 col-lg-6 col-md-6 col-sm-6 col-6">
                          <p class="detail-right"><?php echo e(@$time->drug->name); ?></p>
                        </div>
                      </div>
                    </div>

                    <div class="item-detail">
                      <div class="row">
                        <div class="col-xl-6 col-lg-6 col-md-6 col-sm-6 col-6">
                          <p class="detail-left">
                            <img src="assets/img/menu-icon/icon-doctor.svg" class="img-fluid" alt=""> แพทย์ผู้รักษา:
                          </p>
                        </div>
                        <div class="col-xl-6 col-lg-6 col-md-6 col-sm-6 col-6">
                          <p class="detail-right"> <?php echo e(@$time->doctor->name); ?></p>
                        </div>
                      </div>
                    </div>

                    <div class="item-detail">
                      <div class="row">
                        <div class="col-xl-6 col-lg-6 col-md-6 col-sm-6 col-6">
                          <p class="detail-left">
                            <img src="assets/img/menu-icon/menu-doc.svg" class="img-fluid" alt=""> อื่นๆเพิ่มเติม:
                          </p>
                        </div>
                        <div class="col-xl-6 col-lg-6 col-md-6 col-sm-6 col-6">
                          <p class="detail-right"> <?php echo e(@$time->note); ?></p>
                        </div>
                      </div>
                    </div>
                  </div>
                  <!-- End Detail -->
                </div>
              </div>
              <div class="container-center">
                <a class="btn-custom btn-orange-outline" href="<?php echo e(url("history")); ?>">ดูประวัติการรักษาทั้งหมด</a>
              </div>
            </div>
          </div>
        </div>

      </div>
    </div>
  </section>

  <?php echo $__env->make("$prefix.layout.javascript", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  <script>
    var options = {
      series: [<?php echo e(@$curse['result_point']); ?>, <?php echo e(@$curse['fullpoint']); ?>],
      labels: [{
          title: ['คะแนนแบบสอบถาม'],
          date: ["<?php echo e(date('d/m/Y',strtotime('+543 Years',strtotime($time->datetime_service)))); ?>"],
        },
        {
          title: ['เปอร์เซ็นต์ที่เหลือ'],
          date: ["<?php echo e(date('d/m/Y',strtotime('+543 Years',strtotime($time->datetime_service)))); ?>"],
        }
      ],
      colors: ['#FF5050', '#f5f5f5'],
      width: '100%',
      chart: {
        type: 'donut',
        events: {
          dataPointSelection: function(event, chartContext, config) {
            console.log(event, chartContext, config);
          }
        }
      },
      dataLabels: {
        enabled: false,
      },
      legend: {
        show: false
      },
      tooltip: {
        style: {
          fontSize: '12px',
          fontFamily: 'IBM Plex Sans Thai, sans-serif',
        },
        custom: function({
          series,
          seriesIndex,
          dataPointIndex,
          w
        }) {
          return (
            '<span class="tool2">' +
            '<span class="text-time">' + w.globals.seriesNames[seriesIndex].title + '</span><br />' +
            '<span class="text-date">' + w.globals.seriesNames[seriesIndex].date + '</span><br / > ' +
            '<span class="text-value">' + series[seriesIndex] + "%" + '</span>' +
            "</span>"
          );
        }
      },
      plotOptions: {
        pie: {
          startAngle: 10,
          donut: {
            size: '80%',
            dataLabels: {
              enabled: false
            },
          }
        },
      },
    };

    var chart = new ApexCharts(document.querySelector("#chart"), options);
    chart.render();

    // Chart2

    var options = {
      series: [{
        data: [<?php echo e(@$curse['vas_point']); ?>, <?php echo e(@$curse['womac_point']); ?>, <?php echo e(@$curse['sf12_point']); ?>]
      }],
      colors: ['#ff6900', '#ff6900', '#ff6900'],

      chart: {
        type: 'bar',
        width: '100%',
        height: 200,
        toolbar: {
          show: false
        },
      },
      plotOptions: {
        bar: {
          borderRadius: 4,
          horizontal: true,
          barHeight: '20%',
        }
      },
      dataLabels: {
        enabled: false
      },
      tooltip: {
        enabled: false
      },
      xaxis: {
        categories: ['VAS', 'Womac', 'Sf12'],
        labels: {
          style: {
            fontFamily: 'IBM Plex Sans Thai, sans-serif',
            colors: ['#141414', '#141414', '#141414', '#141414'],
          },
        },
      },
      yaxis: {
        min: 0,
        max: 100,
        labels: {
          style: {
            fontFamily: 'IBM Plex Sans Thai, sans-serif',
            colors: ['#141414', '#141414', '#141414', '#141414'],
          },
        }
      },
      grid: {
        xaxis: {
          lines: {
            show: false
          }
        },
        yaxis: {
          lines: {
            show: false
          }
        }
      }
    };

    var chart2 = new ApexCharts(document.querySelector("#chart2"), options);
    chart2.render();
  </script>
</body>

</html><?php /**PATH C:\laragon\www\cretive\cu-cat.com\resources\views/front-end/history-detail.blade.php ENDPATH**/ ?>