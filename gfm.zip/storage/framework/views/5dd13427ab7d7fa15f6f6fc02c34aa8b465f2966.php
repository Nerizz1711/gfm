<?php 
$prefix = "webpanel";
?>
<nav class="side-nav">
    <ul>
        <li>
            <a href="<?php echo e(url("$prefix")); ?>" class="side-menu <?php if(@$folder == 'dashboard'): ?> side-menu--active  <?php endif; ?>">
                <div class="side-menu__icon"> <i data-lucide="home"></i> </div>
                <div class="side-menu__title"> Dashboard </div>
            </a>
        </li>

        <?php
            $member = App\Models\Backend\AdminModel::find(Auth::guard('admin')->id());
            $menus = \App\Models\Backend\MenuModel::where('position', 'main')
                    ->orderby('sort', 'asc')
                    ->get();
        ?>

        <?php if(@$menus): ?>
            <?php $__currentLoopData = $menus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $menu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php 
                $arraymenu = array();
                $subs = \App\Models\Backend\MenuModel::where(['position'=>'secondary', '_id'=>$menu->id])
                    ->orderby('sort', 'asc')
                    ->get();
                if($subs->count() > 0){
                    foreach($subs as $submenu){
                        array_push($arraymenu, $submenu->url);
                    }
                }
                ?>
            

                <?php if($subs->count() <= 0): ?> <!-- กรณีไม่มี SUB -->
                <li>
                    <a href="<?php echo e(url("$prefix/$menu->url")); ?>" class="side-menu">
                        <div class="side-menu__icon"> <i data-lucide="<?php echo e(@$menu->icon); ?>"></i> </div>
                        <div class="side-menu__title"> <?php echo e(@$menu->name); ?> </div>
                    </a>
                </li>
                <?php else: ?> <!-- แบบ มี SUB MENU -->
                <li>
                    <a id="main_menu_<?php echo e(@$menu->id); ?>" href="javascript:;" class="side-menu <?php if(@$folder == $menu->url): ?> side-menu--active  <?php endif; ?>">
                        <div class="side-menu__icon"> <i data-lucide="<?php echo e(@$menu->icon); ?>"></i> </div>
                        <div class="side-menu__title">
                            <?php echo e(@$menu->name); ?> 
                            <div class="side-menu__sub-icon "> <i data-lucide="chevron-up" class="menu__sub-icon transform rotate-180"></i> </div>
                        </div>
                    </a>
                    <?php if($subs): ?>
                    <ul id="main_sub_menu_<?php echo e(@$menu->id); ?>" class="">
                        <?php $__currentLoopData = $subs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sub): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php 
                        try{
                            if(in_array(@$folder, $arraymenu)){
                                echo "<script>
                                    var element = document.getElementById('main_menu_'+ $menu->id);
                                        element.classList.add('side-menu--active');
                                        element.classList.add('side-menu--open');
                                    var element1 = document.getElementById('main_sub_menu_'+ $menu->id);
                                        element1.classList.add('side-menu__sub-open');
                                    </script>";
                            }
                        }catch (\Exception $e) {}
                        ?>
                        <li>
                            <a href="<?php echo e("$prefix/".$sub->url); ?>" class="side-menu <?php if(@$folder == $sub->url): ?> side-menu--active <?php endif; ?>">
                                <div class="side-menu__icon">-</div>
                                <div class="side-menu__title"> <?php echo e(@$sub->name); ?></div>
                            </a>
                        </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                    <?php endif; ?>
                </li>
                <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        <?php endif; ?>


        <!-- Role : Dev , Administrator -->
        <li class="side-nav__devider my-6"></li>
        <?php
        $arraymenuadmin = ['administrator/user','administrator/permission'];
        ?>
        <li>
            <a id="main_menu_administrator" href="javascript:;" class="side-menu">
                <div class="side-menu__icon"> <i data-lucide="users"></i> </div>
                <div class="side-menu__title">
                    Administrator 
                    <div class="side-menu__sub-icon "> <i data-lucide="chevron-up" class="menu__sub-icon transform rotate-180"></i> </div>
                </div>
            </a>
            <ul id="main_sub_administrator" class="">
                <?php if(in_array(@$folder, $arraymenuadmin)): ?>
                    <script>
                    const element = document.getElementById('main_menu_administrator');
                        element.classList.add('side-menu--active');
                        element.classList.add('side-menu--open');

                    const element1 = document.getElementById('main_sub_administrator');
                        element1.classList.add('side-menu__sub-open');
                    </script>
                <?php endif; ?>
                <li>
                    <a href="<?php echo e(url("$prefix/administrator/user")); ?>" class="side-menu <?php if(@$folder == "administrator/user"): ?> side-menu--active <?php endif; ?>">
                        <div class="side-menu__icon">-</div>
                        <div class="side-menu__title"> User </div>
                    </a>
                </li>

                <li>
                    <a href="<?php echo e(url("$prefix/administrator/permission")); ?>" class="side-menu <?php if(@$folder == "administrator/permission"): ?> side-menu--active <?php endif; ?>">
                        <div class="side-menu__icon">-</div>
                        <div class="side-menu__title"> Permission </div>
                    </a>
                </li>

                <li>
                    <a href="<?php echo e(url("$prefix/administrator/menu")); ?>" class="side-menu <?php if(@$folder == "administrator/menu"): ?> side-menu--active <?php endif; ?>">
                        <div class="side-menu__icon">-</div>
                        <div class="side-menu__title"> Menu </div>
                    </a>
                </li>

            </ul>
        </li>


    </ul>
</nav><?php /**PATH C:\laragon\www\orange\pipat-template\resources\views/back-end/layout/menu-slide.blade.php ENDPATH**/ ?>