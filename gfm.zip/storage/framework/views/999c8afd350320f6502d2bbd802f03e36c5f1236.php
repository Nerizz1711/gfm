<div class="app-container container-fluid d-flex flex-column flex-md-row flex-center flex-md-stack py-3">
    <div class="text-dark order-2 order-md-1">
        <span class="text-muted fw-semibold me-1">2024&copy;</span>
        <a href="https://www.orange-thailand.com/" target="_blank" class="text-gray-800 text-hover-primary">Dev by Orange</a>
    </div>
    
</div><?php /**PATH C:\laragon\www\gfm\resources\views/back-end/layout/footer.blade.php ENDPATH**/ ?>