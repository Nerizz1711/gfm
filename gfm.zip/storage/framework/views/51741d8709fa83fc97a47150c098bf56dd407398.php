<div class="modal-header">
    <h2>แก้ไขข้อมูล ข้อมูลผู้ป่วย</h2>
    <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
        <span class="svg-icon svg-icon-1">
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="currentColor" />
                <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="currentColor" />
            </svg>
        </span>
    </div>
</div>

<div class="modal-body py-lg-10 px-lg-10">
    <form id="form_submit" method="POST" enctype="multipart/form-data">
    <?php echo csrf_field(); ?>
        <div class="row mb-2">
            <label class="col-md-3 col-form-label">รูปภาพ</label>
            <div class="col-md-9">
                <img id="example_image01" src="<?php if($row->image): ?><?php echo e($row->image); ?><?php else: ?><?php echo e('no-img.png'); ?><?php endif; ?>" class="img-fluid" alt="">
                <input name="image" id="image" type="file" class="custom-file-input" onchange="readURL01(this);" hidden>
                <div class="text-muted fs-7">อัพโหลดรูปภาพเฉพาะไฟล์ *.png, *.jpg and *.jpeg image เท่านั้น</div>
            </div>
        </div>

        <div class="row mb-2">
            <label class="col-md-3 col-form-label">ชื่อ <span class="text-danger">*</span></label>
            <div class="col-md-9">
                <input type="text" id="firstname" name="firstname" class="form-control" placeholder="กรุณากรอกชื่อ" value="<?php echo e($row->firstname); ?>" />
            </div>
        </div>

        <div class="row mb-2">
            <label class="col-md-3 col-form-label">นามสกุล <span class="text-danger">*</span></label>
            <div class="col-md-9">
                <input type="text" id="lastname" name="lastname" class="form-control" placeholder="กรุณากรอกนามสกุล" value="<?php echo e($row->lastname); ?>" />
            </div>
        </div>

        <div class="row mb-2">
            <label class="col-md-3 col-form-label">เลขบัตรประชาชน <span class="text-danger">*</span></label>
            <div class="col-md-9">
                <input type="text" id="idcard" name="idcard" class="form-control" placeholder="กรุณากรอกเลขบัตรประชาชน" value="<?php echo e($row->idcard); ?>" />
            </div>
        </div>

        <div class="row mb-2">
            <label class="col-md-3 col-form-label">เบอร์ติดต่อ <span class="text-danger">*</span></label>
            <div class="col-md-9">
                <input type="text" id="phone" name="phone" class="form-control" placeholder="กรุณากรอกเบอร์ติดต่อ" value="<?php echo e($row->phone); ?>" />
            </div>
        </div>

        <div class="row mb-2">
            <label class="col-md-3 col-form-label">เพศ <span class="text-danger">*</span></label>
            <div class="col-md-9">
                <div class="d-flex mt-3">
                    <!--begin::Radio-->
                    <div class="form-check form-check-custom form-check-solid me-5">
                        <input class="form-check-input" type="radio" value="ชาย" name="sex" id="male" <?php if($row->sex == "ชาย"): ?> checked <?php endif; ?>>
                        <label class="form-check-label" for="male">ชาย</label>
                    </div>
                    <div class="form-check form-check-custom form-check-solid">
                        <input class="form-check-input" type="radio" value="หญิง" name="sex" id="female" <?php if($row->sex == "หญิง"): ?> checked <?php endif; ?>>
                        <label class="form-check-label" for="female">หญิง</label>
                    </div>
                    <!--end::Radio-->
                </div>
            </div>
        </div>

        <div class="row mb-2">
            <label class="col-md-3 col-form-label">วันเกิด <span class="text-danger">*</span></label>
            <div class="col-md-9">
                <input type="date" id="birthdate" name="birthdate" class="form-control" placeholder="กรุณากรอกวันเกิด" value="<?php echo e($row->birthdate); ?>" />
            </div>
        </div>

        <div class="row mb-2">
            <label class="col-md-3 col-form-label">อายุ <span class="text-danger">*</span></label>
            <div class="col-md-9 col-form-label">
                <span id="show_age"><?php echo e($row->age); ?></span> ปี
                <input type="hidden" id="age" name="age" class="form-control" placeholder="" readonly value="<?php echo e($row->age); ?>" />
            </div>
        </div>

        <div class="row mb-2">
            <label class="col-md-3 col-form-label">ส่วนสูง <span class="text-danger">*</span></label>
            <div class="col-md-9">
                <input type="text" id="height" name="height" class="form-control"  onkeypress="checkbmi()" placeholder="กรุณากรอกส่วนสูง" value="<?php echo e($row->height); ?>" />
            </div>
        </div>

        <div class="row mb-2">
            <label class="col-md-3 col-form-label">น้ำหนัก <span class="text-danger">*</span></label>
            <div class="col-md-9">
                <input type="text" id="weight" name="weight"  onkeypress="checkbmi()" class="form-control" placeholder="กรุณากรอกน้ำหนัก" value="<?php echo e($row->weight); ?>" />
            </div>
        </div>

        <div class="row mb-2">
            <label class="col-md-3 col-form-label">BMI</label>
            <div class="col-md-9">
                <input type="text" id="bmi" name="bmi" class="form-control" placeholder="" readonly value="<?php echo e($row->bmi); ?>" />
            </div>
        </div>

        <div class="row mb-2">
            <label class="col-md-3 col-form-label">Email</label>
            <div class="col-md-9">
                <input type="text" id="email" name="email" class="form-control" placeholder=""  value="<?php echo e($row->email); ?>" />
            </div>
        </div>

        <div class="row mb-2">
            <label class="col-md-3 col-form-label">Password</label>
            <div class="col-md-9">
                <input type="text" id="password" name="password" class="form-control" placeholder=""  value="" />
            </div>
        </div>


        <div class="row mb-2 mt-5">
        <div class="col-md-12 text-end">
            <a href="javascript:void(0);" id="" data-bs-dismiss="modal" class="btn btn-light me-2">ยกเลิก</a>
            <button type="button" id="" onclick="check_add();" class="btn btn-primary" style="background: #1C2842;"><span class="indicator-label">บันทึก</span></button>
        </div>
        </div>
    </form>

</div>

<script>
    $("#example_image01").click(function() {
        $("input[id='image']").click();
    });

    function readURL01(input) {
        if (input.files && input.files[0]) {
            var reader = new FileReader();
            reader.onload = function(e) {
                $('#example_image01').attr('src', e.target.result);
            }
            reader.readAsDataURL(input.files[0]);
        }
    }

    function checkbmi(){
        var height = $('#height').val();
        var weight = $('#weight').val();
        var bmi = (weight) / ((height/100) * (height/100));
        $('#bmi').val(parseFloat(bmi).toFixed(2));
    }

    $('#birthdate').change(function(){
        var birthdate = new Date(document.getElementById('birthdate').value);
        var today = new Date();
        var age = Math.floor((today-birthdate)/(365.25*24*60*60*1000));
        $('#age').val(age);
        $('#show_age').html(age);
    });

    function check_add() {
        var formData = new FormData($("#form_submit")[0]);
        Swal.fire({
            icon: 'warning',
            title: 'กรุณากดยืนยันเพื่อทำรายการ',
            showCancelButton: true,
            confirmButtonText: 'ยืนยัน',
            cancelButtonText: `ยกเลิก`,
        }).then((result) => {
            if (result.isConfirmed) {
                $.ajax({
                    type: 'POST',
                    url: "<?php echo e("$segment/$folder/".$row->id); ?>",
                    data: formData,
                    processData: false,
                    contentType: false,
                    dataType: 'json',
                    success: function(data) {
                        console.log(data);
                        if (data.status == 200) {
                            Swal.fire({
                                icon: 'success',
                                title: data.message,
                                text: data.desc,
                                showCancelButton: false,
                                confirmButtonText: 'ปิด',
                            }).then((result) => {
                                location.reload();
                            });
                        } else if (data.status == 500) {
                            Swal.fire({
                                icon: 'error',
                                title: data.message,
                                text: data.desc,
                                showCancelButton: false,
                                confirmButtonText: 'ปิด',
                            }).then((result) => {
                                location.reload();
                            });
                        }
                    }
                });
            }else{
                return false;
            }
        });
    }
</script><?php /**PATH C:\laragon\www\cretive\cu-cat.com\resources\views/back-end/pages/customer/edit.blade.php ENDPATH**/ ?>