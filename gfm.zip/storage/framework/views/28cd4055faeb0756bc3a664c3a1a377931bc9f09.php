<div class="modal-content">
    <form id="frm_cus" action="" method="POST" autocomplete="off" onsubmit="return check_add();"
        enctype="multipart/form-data" class="noentersubmit">
        <?php echo e(csrf_field()); ?>

        <div class="modal-header flex-grow-1 overflow-hidden dragable_touch">
            <h2 class="font-medium text-base mr-auto">
                Add
            </h2>
            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>
        <div class="modal-body">

            <div class="grid grid-cols-12 gap-6 mt-5 mb-3">
                <div class="col-span-6 lg:col-span-6">
                    <img id="example_image01" class="mb-2" src="no-img.png" class="img-fluid" alt="">
                    <input name="image" id="image" type="file" class="custom-file-input" accept="image/*" onchange="readURL01(this);">
                </div>
            </div>

            <div class="grid grid-cols-12 gap-6 mt-5 mb-3">
                <div class="col-span-12 lg:col-span-12">
                    <label for="horizontal-form-1" class="form-label">รูปภาพ <small class="form-help">(อัพโหลดรูปภาพเฉพาะไฟล์ *.png, *.jpg and *.jpeg image เท่านั้น)</small> </label> 
                </div>
            </div>

            <div class="grid grid-cols-12 gap-6 mt-5 mb-3">
                <div class="col-span-6 lg:col-span-6">
                    <label for="crud-form-1" class="form-label">ชื่อ <span class="text-danger">*</span></label>
                    <input class="form-control" id="name" type="text" name="name" value="" placeholder="กรอกชื่อ-นามสกุล" autocomplete="off">
                </div>
                <div class="col-span-12 lg:col-span-12">
                    <label for="crud-form-1" class="form-label">รายละเอียด</label>
                    <input class="form-control" id="detail" type="text" name="detail" value="" placeholder="กรอกรายละเอียด" autocomplete="off">
                </div>
            </div>

            <div class="grid grid-cols-12 gap-6 mt-5 mb-3">
                <div class="col-span-6 lg:col-span-6">
                    <label for="crud-form-1" class="form-label">Province :</label>
                    <select name="province_id" id="province_id" class="select2 form-select w-full  province" style="width:100%;">
                        <option value="" disabled selected>กรุณาเลือกข้อมูล</option>
                        <?php if(@$provinces): ?>
                            <?php $__currentLoopData = $provinces; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($p->id); ?>" <?php if(@$address->province_id == $p->id): ?> selected <?php endif; ?>><?php echo e($p->name_th); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                    </select>
                </div>
                <div class="col-span-6 lg:col-span-6">
                    <label for="crud-form-1" class="form-label">District / Zone :</label>
                    <select name="amupur_id" id="amupur_id" class="select2 form-select district"  style="width:100%;">
                        <option value="">กรุณาเลือกข้อมูล</option>
                    </select>
                </div>
                <div class="col-span-6 lg:col-span-6">
                    <label for="crud-form-1" class="form-label">Subdistrict / Area :</label>
                    <select name="tambon_id" id="tambon_id" class="select2 form-select subdistrict"  style="width:100%;">
                        <option value="" disabled selected>กรุณาเลือกข้อมูล</option>
                    </select>
                </div>
                <div class="col-span-6 lg:col-span-6">
                    <label for="crud-form-1" class="form-label">Zipcode :</label>
                    <input class="form-control" id="zip_code" type="text" name="zip_code" value="" readonly placeholder="" autocomplete="off">
                </div>
            </div>

            <div class="grid grid-cols-12 gap-4 gap-y-5 mt-5">
                <div class="intro-y col-span-12 sm:col-span-12">
                    <label class="form-label" for="size">*อัพโหลดรูปภาพแกลลอรี่ <strong class="text-danger">(jpg, jpeg, png)</strong> เท่านั้น</label>
                    <div class="custom-file">
                        <input type="file" class="custom-file-input" name="gallery_image[]" id="gallery_image" multiple>
                        <label class="custom-file-label" for="gallery_image">Choose file</label>
                    </div>
                </div>
            </div>

        </div>
        <div class="modal-footer">
            <button type="button" data-tw-dismiss="modal" class="btn btn-outline-secondary w-20 mr-1">ปิด</button>
            <button type="button" onclick="check_add();" class="btn btn-primary w-20">บันทึก</button>
        </div>
    </form>
</div>


<script>
    var fullUrl = window.location.origin + window.location.pathname;
    $('#form_sunbmit_modal').on('keyup keypress', function(e) {
        var keyCode = e.keyCode || e.which;
        if (keyCode === 13) {
            e.preventDefault();
            return false;
        }
    });

    $("#example_image01").click(function() {
            $("input[id='image']").click();
        });

        function readURL01(input) {
            if (input.files && input.files[0]) {
                var reader = new FileReader();
                reader.onload = function(e) {
                    $('#example_image01').attr('src', e.target.result);
                }
                reader.readAsDataURL(input.files[0]);
            }
        }

        $('#province_id').change(function() {
            var province_id = $('#province_id').val();
            $.ajax({
                type: "POST",
                url: 'ajax/getProvince',
                data: {
                    _token: "<?php echo e(csrf_token()); ?>",
                    province_id: province_id,
                },
                success: function(data) {
                    $('#amupur_id').html(data);
                    $('#tambon_id').html('<option value="" selected>- กรุณาเลือกข้อมูล -</option>');
                    $('#zip_code').val(null);
                }
            });
        });

        $('#amupur_id').change(function() {
            var amupur_id = $('#amupur_id').val();
            $.ajax({
                type: "POST",
                url: 'ajax/getAmupur',
                data: {
                    _token: "<?php echo e(csrf_token()); ?>",
                    amupur_id: amupur_id,
                },
                success: function(data) {
                    $('#tambon_id').html(data);
                    $('#zip_code').val(null);
                }
            });
        });

        $('#tambon_id').change(function() {
            var tambon_id = $('#tambon_id').val();
            $.ajax({
                type: "POST",
                url: 'ajax/getTambon',
                data: {
                    _token: "<?php echo e(csrf_token()); ?>",
                    tambon_id: tambon_id,
                },
                dataType: 'json',
                success: function(data) {
                    $('#zip_code').val(data.zip_code);
                }
            });
        });

    function check_add() {
        const el = document.querySelector("#showpagemodal");
        const modal = tailwind.Modal.getOrCreateInstance(el);

        var formData = new FormData($("#frm_cus")[0]);

        Swal.fire({
            icon: 'warning',
            title: 'กรุณากดยืนยันเพื่อทำรายการ',
            showCancelButton: true,
            confirmButtonText: 'ยืนยัน',
            cancelButtonText: `ยกเลิก`,
        }).then((result) => {
            if (result.isConfirmed) {
                $.ajax({
                    type: 'POST',
                    url: fullUrl + '/add',
                    data: formData,
                    processData: false,
                    contentType: false,
                    dataType: 'json',
                    success: function(data) {
                        console.log(data);
                        if (data.result == "success") {
                            location.reload();
                        } else {
                            Swal.fire({
                                title: 'เกิดข้อผิดพลาด !',
                                text: "" + data.message,
                                icon: 'error',
                                showCancelButton: false,
                                confirmButtonColor: '#3085d6',
                                cancelButtonColor: '#d33',
                                confirmButtonText: 'ปิด',
                            });
                        }
                    }
                });
            }
        }); 

    }
</script>
<?php /**PATH C:\laragon\www\orange\pipat-template\resources\views/back-end/pages/template/modal/modal-create.blade.php ENDPATH**/ ?>