<!DOCTYPE html>
<html lang="en" class="light">
    <!-- BEGIN: Head -->
    <head>
        <?php echo $__env->make("$prefix.layout.header", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </head>
    <!-- END: Head -->
    <body class="main">
        
        <!-- BEGIN: MENU -->
        <?php echo $__env->make("$prefix.layout.menu-top", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <!-- END: Menu -->

       
        <div class="wrapper">
            <div class="wrapper-box">
                <!-- BEGIN: Side Menu -->
                <?php echo $__env->make("$prefix.layout.menu-slide", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <!-- END: Side Menu -->

                <!-- BEGIN: Content -->
                <div class="content">

                   <!-- BEGIN: Content -->
                    <div class="intro-y flex flex-col sm:flex-row items-center mt-8">
                        <h2 class="text-lg font-medium mr-auto">
                            ฟอร์มข้อมูล
                        </h2>
                    </div>
        
                    <form id="menuForm" method="post" action="" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                        <div class="grid grid-cols-12 gap-6 mt-5">
                            <div class="intro-y col-span-12 lg:col-span-12">
                                <!-- BEGIN: Form Layout -->
                                <div class="intro-y box p-5">

                                    <div class="grid grid-cols-12 gap-6 mt-5 mb-3">
                                        <div class="col-span-12 lg:col-span-12">
                                            <b>รายละเอียดสิทธิ์</b>
                                        </div>
                                    </div>

                                    <div class="grid grid-cols-12 gap-6 mt-5 mb-3">
                                        <div class="col-span-12 lg:col-span-12">
                                            <div class="form-inline"> <label for="horizontal-form-1" class="form-label sm:w-40">ชื่อสิทธิ์ <span class="text-danger">*</span></label> 
                                                <input id="horizontal-form-1" type="text" id="name" name="name" value="<?php echo e(@$row->name); ?>" class="form-control" placeholder="กรอกชื่อ"> 
                                            </div>
                                        </div>
                                    </div>

                                    <div class="grid grid-cols-12 gap-6 mt-5 mb-3">
                                        <div class="col-span-12 lg:col-span-12">
                                            <div class="form-inline"> <label for="horizontal-form-1" class="form-label sm:w-40">รายละเอียด</label> 
                                                <input id="horizontal-form-1" type="text" id="detail" name="detail" value="<?php echo e(@$row->detail); ?>" class="form-control" placeholder="กรอกรายละเอียด"> 
                                            </div>
                                        </div>
                                    </div>

                                    <div class="grid grid-cols-12 gap-6 mt-5 mb-3">
                                        <div class="col-span-12 lg:col-span-12">
                                            <div class="form-inline"> <label for="horizontal-form-1" class="form-label sm:w-40">สถานะ</label> 
                                                <div class="form-check form-switch w-full">
                                                    <input id="isActive" name="isActive" value="Y" <?php if(@$row->isActive == 'Y'): ?> checked <?php endif; ?> data-target="#input-sizing" class="show-code form-check-input mr-0 ml-3" type="checkbox">
                                                </div>
                                            </div>
                                        </div>
                                    </div>

                                
                                   
                                </div>
                                <!-- END: Form Layout -->
                            </div>


                            <div class="intro-y col-span-12 lg:col-span-12">
                                <!-- BEGIN: Form Layout -->
                                <div class="intro-y box p-5">
                                    <!-- BEGIN : Header -->
                                    <div class="flex flex-col sm:flex-row items-center p-5 border-b border-slate-200/60 dark:border-darkmode-400">
                                        <h2 class="font-medium text-base mr-auto">
                                            <i class="fa fa-cog text-danger"></i>  Permission Setting
                                        </h2>
                                    </div>
                                    <!-- END : Header -->

                                    <div class="overflow-x-auto">
                                        <table class="table">
                                            <thead class="" style="background-color: #e8ecef;">
                                                <th style="width:5%;" class="text-center text-black">#</th>
                                                <th style="width:40%;" class="text-left text-black">Menu</th>
                                                <th style="width:15%;" class="text-left text-black">
                                                    <div class="form-check form-check-sm form-check-custom form-check-solid me-3">
                                                        <input class="form-check-input" type="checkbox" check="true" check-target=".view" value="1" />
                                                    </div>
                                                    View
                                                </th>
                                                <th style="width:15%;" class="text-left text-black">
                                                    <div class="form-check form-check-sm form-check-custom form-check-solid me-3">
                                                        <input class="form-check-input" type="checkbox" check="true" check-target=".create" value="1" />
                                                    </div>
                                                    Create
                                                </th>
                                                <th style="width:15%;" class="text-left text-black">
                                                    <div class="form-check form-check-sm form-check-custom form-check-solid me-3">
                                                        <input class="form-check-input" type="checkbox" check="true" check-target=".edit" value="1" />
                                                    </div>
                                                    Edit
                                                </th>
                                                <th style="width:15%;" class="text-left text-black">
                                                    <div class="form-check form-check-sm form-check-custom form-check-solid me-3">
                                                        <input class="form-check-input" type="checkbox" check="true" check-target=".delete" value="1" />
                                                    </div>
                                                    Delete
                                                </th>
                                            </thead>
                                            <tbody>
                                                <?php if(@$menus): ?>
                                                    <?php $__currentLoopData = @$menus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index=>$m): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <?php
                                                        $second = \App\Models\Backend\MenuModel::where('_id',$m->id)->where('status','on')->get();
                                                        $role_main = \App\Models\Backend\Role_listModel::where(['role_id'=>$row->id, 'menu_id'=>$m->id])->first();
                                                        ?>

                                                        <tr>
                                                            <td class="text-center text-black"><?php echo e($index+1); ?></td>
                                                            <td class="text-black"><?php echo e($m->name); ?></td>
                                                            <td>
                                                                <input name="menu_id[]" value="<?php echo e($m->id); ?>" hidden>
                                                                <?php if(count(@$second) == null): ?>
                                                                <div class="form-check form-check-sm form-check-custom form-check-solid">
                                                                    <input class="form-check-input view" type="checkbox" <?php if(@$role_main->read == "on"): ?> checked <?php endif; ?> name="read_<?php echo e($m->id); ?>" />
                                                                </div>
                                                                <?php endif; ?>
                                                            </td>
                                                            <td>
                                                                <?php if(count(@$second) == null): ?>
                                                                <div class="form-check form-check-sm form-check-custom form-check-solid">
                                                                    <input class="form-check-input create" type="checkbox" <?php if(@$role_main->add == "on"): ?> checked <?php endif; ?> name="add_<?php echo e($m->id); ?>" />
                                                                </div>
                                                                <?php endif; ?>
                                                            </td>
                                                            <td>
                                                                <?php if(count(@$second) == null): ?>
                                                                <div class="form-check form-check-sm form-check-custom form-check-solid">
                                                                    <input class="form-check-input edit" type="checkbox" <?php if(@$role_main->edit == "on"): ?> checked <?php endif; ?> name="edit_<?php echo e($m->id); ?>" />
                                                                </div>
                                                                <?php endif; ?>
                                                            </td>
                                                            <td>
                                                                <?php if(count(@$second) == null): ?>
                                                                <div class="form-check form-check-sm form-check-custom form-check-solid">
                                                                    <input class="form-check-input delete" type="checkbox" <?php if(@$role_main->delete == "on"): ?> checked <?php endif; ?> name="delete_<?php echo e($m->id); ?>" />
                                                                </div>
                                                                <?php endif; ?>
                                                            </td>
                                                        </tr>

                                                        <?php if(count(@$second)): ?>
                                                        <?php $__currentLoopData = @$second; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                <?php
                                                                $role_sub = \App\Models\Backend\Role_listModel::where(['role_id'=>$row->id, 'menu_id'=>$s->id])->first();
                                                                ?>
                                                                <tr>
                                                                    <td class="text-center text-black"><?php echo e(($index+1).".".$i+1); ?></td>
                                                                    <td class="text-black"><?php echo e($s->name); ?></td>
                                                                    <td>
                                                                        <input name="menu_id[]" value="<?php echo e($s->id); ?>" hidden>
                                                                        <div class="form-check form-check-sm form-check-custom form-check-solid">
                                                                            <input class="form-check-input view" type="checkbox" <?php if(@$role_sub->read == "on"): ?> checked <?php endif; ?> name="read_<?php echo e($s->id); ?>" />
                                                                        </div>
                                                                    </td>
                                                                    <td>
                                                                        <div class="form-check form-check-sm form-check-custom form-check-solid">
                                                                            <input class="form-check-input create" type="checkbox" <?php if(@$role_sub->add == "on"): ?> checked <?php endif; ?> name="add_<?php echo e($s->id); ?>" />
                                                                        </div>
                                                                    </td>
                                                                    <td>
                                                                        <div class="form-check form-check-sm form-check-custom form-check-solid">
                                                                            <input class="form-check-input edit" type="checkbox" <?php if(@$role_sub->edit == "on"): ?> checked <?php endif; ?> name="edit_<?php echo e($s->id); ?>" />
                                                                        </div>
                                                                    </td>
                                                                    <td>
                                                                        <div class="form-check form-check-sm form-check-custom form-check-solid">
                                                                            <input class="form-check-input delete" type="checkbox" <?php if(@$role_sub->delete == "on"): ?> checked <?php endif; ?> name="delete_<?php echo e($s->id); ?>" />
                                                                        </div>
                                                                    </td>
                                                                </tr>
                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                        <?php endif; ?>

                                                        
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                <?php endif; ?>
                                            </tbody>
                                        </table>
                                        
                                    </div>
                                </div>
                                <!-- END: Form Layout -->
                            </div>
                        </div>

                        <div class="text-right mt-5">
                            <a class="btn btn-outline-secondary w-24 mr-1" href="<?php echo e(url("$segment/$folder")); ?>">ยกเลิก</a>
                            <button type="button" onclick="check_add();" class="btn btn-primary w-24">บันทึกข้อมูล</button>
                        </div>
                    </form>

                </div>
                <!-- END: Content -->

                
            </div>
        </div>
 
        <!-- BEGIN: JS Assets-->
        <?php echo $__env->make("$prefix.layout.script", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <script>
        $("#example_image01").click(function() {
            $("input[id='image']").click();
        });

        function readURL01(input) {
            if (input.files && input.files[0]) {
                var reader = new FileReader();
                reader.onload = function(e) {
                    $('#example_image01').attr('src', e.target.result);
                }
                reader.readAsDataURL(input.files[0]);
            }
        }

        function check_add() {
            var role = $('#role').val();
            var status_check = $('#status_check').val();
            var name = $('#name').val();
            var email = $('#email').val();
            var password = $('#password').val();
            var confirm_password = $('#confirm_password').val();
            var resetpassword = $('#resetpassword').val();

            if (role == "") {
                toastr.error('กรุณาเลือกระดับของผู้ใช้งานนี้');
                return false;
            }
            if (status_check == "") {
                toastr.error('กรุณาเลือกสถานะการใช้งาน');
                return false;
            }
            if (name == "" || email == "") {
                toastr.error('กรุณากรอกข้อมูลให้ครบถ้วนก่อนบันทึกรายการ');
                return false;
            }
            if (password != confirm_password) {
                toastr.error('กรุณากรอกรหัสผ่านให้เหมือนกัน');
                return false;
            }

            Swal.fire({
                icon: 'warning',
                title: 'กรุณากดยืนยันเพื่อทำรายการ',
                showCancelButton: true,
                confirmButtonText: 'ยืนยัน',
                cancelButtonText: `ยกเลิก`,
            }).then((result) => {
                if (result.isConfirmed) {
                    $('#menuForm').submit();
                }
            });
                
        }
        //== Script Ajax Regular ==
        $('#resetpassword').change(function() {
            if ($(this).prop("checked") == true) {
                $('#password').attr('disabled', false);
                $('#confirm_password').attr('disabled', false);
            } else if ($(this).prop("checked") == false) {
                $('#password').attr('disabled', true);
                $('#confirm_password').attr('disabled', true);
                $('#password').val(null);
                $('#confirm_password').val(null);
            }
        });

        $('.show_pass').click(function() {
            var password = $('#password').attr('type');
            if (password == "password") {
                $('#password').attr('type', 'text');
            } else {
                $('#password').attr('type', 'password');
            }
        });


        $('.show_pass_confirm').click(function() {
            var confirm_password = $('#confirm_password').attr('type');
            if (confirm_password == "password") {
                $('#confirm_password').attr('type', 'text');
            } else {
                $('#confirm_password').attr('type', 'password');
            }
        });
    
        </script>
        <!-- END: JS Assets-->
    </body>
</html><?php /**PATH C:\laragon\www\orange\pipat-template\resources\views/back-end/pages/administrator/permission/edit.blade.php ENDPATH**/ ?>