<!DOCTYPE html>
<html lang="en">
<!--begin::Head-->

<head>
    <?php echo $__env->make("$prefix.layout.head", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

</head>
<!--end::Head-->
<!--begin::Body-->

<body id="kt_app_body" data-kt-app-layout="dark-sidebar" data-kt-app-header-fixed="true" data-kt-app-sidebar-enabled="true"
    data-kt-app-sidebar-fixed="true" data-kt-app-sidebar-hoverable="true" data-kt-app-sidebar-push-header="true"
    data-kt-app-sidebar-push-toolbar="true" data-kt-app-sidebar-push-footer="true" data-kt-app-toolbar-enabled="true"
    class="app-default">


    <div class="d-flex flex-column flex-root app-root" id="kt_app_root">
        <!--begin::Page-->
        <div class="app-page flex-column flex-column-fluid" id="kt_app_page">
            <!--begin::Header-->
            <div id="kt_app_header" class="app-header">
                <!-- MENU -->
                <?php echo $__env->make("$prefix.layout.menu", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <!-- END MENU -->

                <!--begin::Main-->
                <div class="app-main flex-column flex-row-fluid" id="kt_app_main">
                    <!--begin::Content wrapper-->
                    <div class="d-flex flex-column flex-column-fluid">
                        <!--begin::Toolbar-->
                        <div id="kt_app_toolbar" class="app-toolbar py-3 py-lg-6">
                            <!--begin::Toolbar container-->
                            <?php echo $__env->make("$prefix.layout.breadcrumbs", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                            <!--end::Toolbar container-->
                        </div>
                        <!--end::Toolbar-->


                        <!--begin::Content-->
                        <div id="kt_app_content" class="app-content flex-column-fluid">
                            <!--begin::Content container-->
                            <div id="kt_app_content_container" class="app-container container-fluid">

                                <div class="card card-flush">
                                    <div class="card-header align-items-center py-5 gap-2 gap-md-5">
                                        <div class="card-toolbar flex-row-fluid justify-content-end gap-5">
                                            <div class="w-100 mw-150px">
                                                <select class="form-select form-select-solid" data-control="select2"
                                                    data-hide-search="true" data-placeholder="Status"
                                                    data-kt-ecommerce-product-filter="status">
                                                    <option></option>
                                                    <option value="">ทั้งหมด</option>
                                                    <option value="Y">ใช้งาน</option>
                                                    <option value="N">ไม่ใช้งาน</option>
                                                </select>
                                            </div>
                                            <a href="<?php echo e(url("$segment/$folder/add")); ?>" class="btn btn-primary">สร้างข้อมูล</a>
                                        </div>
                                    </div>
                                    <div class="card-body pt-0">
                                        <div class="hidden md:block mx-auto text-slate-500"><b>Showing <?php echo e($items->currentPage()); ?> to <?php echo e($items->total()); ?> of <?php echo e($items->total()); ?> entries</b></div>
                                        <table class="table align-middle table-row-dashed fs-6 gy-5"
                                            id="kt_ecommerce_products_table">
                                            <thead>
                                                <tr class="text-start text-gray-400 fw-bold fs-7 text-uppercase gs-0">
                                                    <th style="width:5%;" class="text-center">#</th>
                                                    <th style="width:40%;" class="text-left">ชื่อสิทธิ์</th>
                                                    <th style="width:15%;" class="text-center">วันที่สร้าง</th>
                                                    <th style="width:15%;" class="text-center">วันที่แก้ไข</th>
                                                    <th style="width:10%;" class="text-center">สถานะ</th>
                                                    <th style="width:15%;" class="text-center">จัดการ</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <?php if(@$items->count() > 0): ?>
                                                    <?php $__currentLoopData = @$items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <tr>
                                                            <td class="text-center"> <?php echo e($items->pages->start+$index + 1); ?></td>
                                                            <td>
                                                                <div class="d-flex flex-column">
                                                                    <span><?php echo e($item->name); ?></span>
                                                                </div>
                                                            </td>
                                                            <td class="text-center"><?php echo e(date('d/m/Y, H:i น.',strtotime($item->created_at))); ?></td>
                                                            <td class="text-center"><?php echo e(date('d/m/Y, H:i น.',strtotime($item->updated_at))); ?></td>
                                                            <td class="text-center"><?php echo \Helper::isActive($item->isActive); ?></td>
                                                            <td class="text-center">
                                                                <a href="<?php echo e(url("$segment/$folder/$item->id")); ?>" ><i class="fa fa-edit fa-2x" style="margin-right:5px;"></i></a>
                                                                <a href="javascript:void(0);" onclick="deleteItem(<?php echo e($item->id); ?>)"><i class="fa fa-trash fa-2x" style="margin-right:5px;"></i></a>
                                                            </td>
                                                        </tr>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                <?php else: ?>
                                                    <tr>
                                                        <td colspan="7" class="text-center">- No items -</td>
                                                    </tr>
                                                <?php endif; ?>

                                            </tbody>
                                        </table>

                                        <div class="table-footer mt-2">
                                            <div class="row">
                                                <div class="col-sm-5">
                                                    <p style=" ">
                                                        
                                                    </p>
                                                </div>
                                                <div class="col-sm-7" >
                                                    <?php echo $items->appends(request()->all())->links('back-end.layout.pagination'); ?>

                                                </div>
                                            </div>
                                        </div>


                                    </div>
                                </div>

                            </div>
                            <!--end::Content container-->
                        </div>
                        <!--end::Content-->


                    </div>
                </div>
            </div>
        </div>
    </div>
    <!--begin::Javascript-->
    <?php echo $__env->make("$prefix.layout.script", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <script>
        var fullUrl = window.location.origin + window.location.pathname;

        function deleteItem(ids) {
            const id = [ids];
            if (id.length > 0) {
                destroy(id)
            }
        }

        function destroy(id) {
            Swal.fire({
                title: "ลบข้อมูล",
                text: "คุณต้องการลบข้อมูลใช่หรือไม่?",
                icon: "warning",
                showCancelButton: true,
                confirmButtonColor: "#DD6B55",
                showLoaderOnConfirm: true,
                preConfirm: () => {
                    return fetch(fullUrl + '/destroy/' + id)
                        .then(response => response.json())
                        .then(data => location.reload())
                        .catch(error => {
                            Swal.showValidationMessage(`Request failed: ${error}`)
                        })
                }
            });
        }
    </script>
    <!--end::Javascript-->
</body>
<!--end::Body-->

</html>
<?php /**PATH C:\laragon\www\cretive\cu-cat.com\resources\views/back-end/pages/administrator/permission/index.blade.php ENDPATH**/ ?>