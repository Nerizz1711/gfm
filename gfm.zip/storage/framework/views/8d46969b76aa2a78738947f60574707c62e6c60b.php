<footer>
    <div class="row">
        <div class="col-6">
            <a href="<?php echo e(url("history")); ?>" class="menu-footer active-footer">
                <img src="frontend/assets/img/menu-icon/icon-history.svg" class="img-fluid" alt="">
                <p>ประวัติการรักษา</p>
            </a>
        </div>
        <div class="col-6">
            <a href="<?php echo e(url("questionnaire")); ?>" class="menu-footer active-footer">
                <img src="frontend/assets/img/menu-icon/icon-note.svg" class="img-fluid" alt="">
                <p>แบบทดสอบ</p>
            </a>
        </div>
    </div>
</footer>
<?php /**PATH C:\laragon\www\cretive\cu-cat.com\resources\views/front-end/layout/footer.blade.php ENDPATH**/ ?>