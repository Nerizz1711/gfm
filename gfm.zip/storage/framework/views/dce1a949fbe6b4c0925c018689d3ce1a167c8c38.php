<!DOCTYPE html>
<html lang="en" class="light">
    <!-- BEGIN: Head -->
    <head>
        <?php echo $__env->make("$prefix.layout.header", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </head>
    <!-- END: Head -->
    <body class="main">
        
        <!-- BEGIN: MENU -->
        <?php echo $__env->make("$prefix.layout.menu-top", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <!-- END: Menu -->

       
        <div class="wrapper">
            <div class="wrapper-box">
                <!-- BEGIN: Side Menu -->
                <?php echo $__env->make("$prefix.layout.menu-slide", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <!-- END: Side Menu -->

                <!-- BEGIN: Content -->
                <div class="content">

                   <!-- BEGIN: Content -->
                    <div class="intro-y flex flex-col sm:flex-row items-center mt-8">
                        <h2 class="text-lg font-medium mr-auto">
                            ฟอร์มข้อมูล
                        </h2>
                    </div>
        
                    <form id="menuForm" method="post" action="" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                        <div class="grid grid-cols-12 gap-6 mt-5">
                            <div class="intro-y col-span-12 lg:col-span-12">
                                <!-- BEGIN: Form Layout -->
                                <div class="intro-y box p-5">

                                    <div class="grid grid-cols-12 gap-6 mt-5 mb-3">
                                        <div class="col-span-12 lg:col-span-12">
                                            <b>รายละเอียดสิทธิ์</b>
                                        </div>
                                    </div>

                                    <div class="grid grid-cols-12 gap-6 mt-5 mb-3">
                                        <div class="col-span-12 lg:col-span-12">
                                            <div class="form-inline"> <label for="horizontal-form-1" class="form-label sm:w-40">ชื่อสิทธิ์ <span class="text-danger">*</span></label> 
                                                <input id="horizontal-form-1" type="text" id="name" name="name" class="form-control" placeholder="กรอกชื่อ"> 
                                            </div>
                                        </div>
                                    </div>

                                    <div class="grid grid-cols-12 gap-6 mt-5 mb-3">
                                        <div class="col-span-12 lg:col-span-12">
                                            <div class="form-inline"> <label for="horizontal-form-1" class="form-label sm:w-40">รายละเอียด</label> 
                                                <input id="horizontal-form-1" type="text" id="detail" name="detail" class="form-control" placeholder="กรอกรายละเอียด"> 
                                            </div>
                                        </div>
                                    </div>

                                    <div class="grid grid-cols-12 gap-6 mt-5 mb-3">
                                        <div class="col-span-12 lg:col-span-12">
                                            <div class="form-inline"> <label for="horizontal-form-1" class="form-label sm:w-40">สถานะ</label> 
                                                <div class="form-check form-switch w-full">
                                                    <input id="isActive" name="isActive" value="Y" data-target="#input-sizing" class="show-code form-check-input mr-0 ml-3" type="checkbox">
                                                </div>
                                            </div>
                                        </div>
                                    </div>

                                
                                    <div class="text-right mt-5">
                                        <a class="btn btn-outline-secondary w-24 mr-1" href="<?php echo e(url("$segment/$folder")); ?>">ยกเลิก</a>
                                        <button type="button" onclick="check_add();" class="btn btn-primary w-24">บันทึกข้อมูล</button>
                                    </div>
                                </div>
                                <!-- END: Form Layout -->
                            </div>
                        </div>
                    </form>

                </div>
                <!-- END: Content -->

                
            </div>
        </div>
 
        <!-- BEGIN: JS Assets-->
        <?php echo $__env->make("$prefix.layout.script", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <script>
        $("#example_image01").click(function() {
            $("input[id='image']").click();
        });

        function readURL01(input) {
            if (input.files && input.files[0]) {
                var reader = new FileReader();
                reader.onload = function(e) {
                    $('#example_image01').attr('src', e.target.result);
                }
                reader.readAsDataURL(input.files[0]);
            }
        }

        function check_add() {
            var name = $('#name').val();
            var detail = $('#detail').val();
            if (name == "") {
                toastr.error('กรุณากรอกข้อมูลให้ครบถ้วนก่อนบันทึกรายการ');
                return false;
            }
            Swal.fire({
                icon: 'warning',
                title: 'กรุณากดยืนยันเพื่อทำรายการ',
                showCancelButton: true,
                confirmButtonText: 'ยืนยัน',
                cancelButtonText: `ยกเลิก`,
            }).then((result) => {
                if (result.isConfirmed) {
                    $('#menuForm').submit();
                }
            });
           
        }
        //== Script Ajax Regular ==
        $('#resetpassword').change(function() {
            if ($(this).prop("checked") == true) {
                $('#password').attr('disabled', false);
                $('#confirm_password').attr('disabled', false);
            } else if ($(this).prop("checked") == false) {
                $('#password').attr('disabled', true);
                $('#confirm_password').attr('disabled', true);
                $('#password').val(null);
                $('#confirm_password').val(null);
            }
        });

        $('.show_pass').click(function() {
            var password = $('#password').attr('type');
            if (password == "password") {
                $('#password').attr('type', 'text');
            } else {
                $('#password').attr('type', 'password');
            }
        });


        $('.show_pass_confirm').click(function() {
            var confirm_password = $('#confirm_password').attr('type');
            if (confirm_password == "password") {
                $('#confirm_password').attr('type', 'text');
            } else {
                $('#confirm_password').attr('type', 'password');
            }
        });
    
        </script>
        <!-- END: JS Assets-->
    </body>
</html><?php /**PATH C:\laragon\www\orange\pipat-template\resources\views/back-end/pages/administrator/permission/add.blade.php ENDPATH**/ ?>