<!DOCTYPE html>
<html lang="en">
<!--begin::Head-->

<head>
    <?php echo $__env->make("$prefix.layout.head", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

</head>
<!--end::Head-->
<!--begin::Body-->

<body id="kt_app_body" data-kt-app-layout="dark-sidebar" data-kt-app-header-fixed="true" data-kt-app-sidebar-enabled="true"
    data-kt-app-sidebar-fixed="true" data-kt-app-sidebar-hoverable="true" data-kt-app-sidebar-push-header="true"
    data-kt-app-sidebar-push-toolbar="true" data-kt-app-sidebar-push-footer="true" data-kt-app-toolbar-enabled="true"
    class="app-default">


    <div class="d-flex flex-column flex-root app-root" id="kt_app_root">
        <!--begin::Page-->
        <div class="app-page flex-column flex-column-fluid" id="kt_app_page">
            <!--begin::Header-->
            <div id="kt_app_header" class="app-header">
                <!-- MENU -->
                <?php echo $__env->make("$prefix.layout.menu", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <!-- END MENU -->

                <!--begin::Main-->
                <div class="app-main flex-column flex-row-fluid" id="kt_app_main">
                    <!--begin::Content wrapper-->
                    <div class="d-flex flex-column flex-column-fluid">
                        <!--begin::Toolbar-->
                        <div id="kt_app_toolbar" class="app-toolbar py-3 py-lg-6">
                            <!--begin::Toolbar container-->
                            <?php echo $__env->make("$prefix.layout.breadcrumbs", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                            <!--end::Toolbar container-->
                        </div>
                        <!--end::Toolbar-->


                        <!--begin::Content-->
                        <div id="kt_app_content" class="app-content flex-column-fluid">
                            <!--begin::Content container-->
                            <div id="kt_app_content_container" class="app-container container-fluid">
                                <form id="menuForm" method="post" action="" onsubmit="return check_add();"  enctype="multipart/form-data">
                                    <?php echo csrf_field(); ?>
                                <div class=" d-flex flex-column flex-lg-row">

                                    <div class="d-flex flex-column flex-row-fluid gap-7 gap-lg-10">
                                        <div class="card card-flush py-4">
                                            <div class="card-body pt-0">

                                                <div class="row">
                                                    <div class="col-md-12">
                                                        <div class="mb-3 fv-row">
                                                            <label class="form-label">ช่องที่มีเครื่องหมาย <span class="text-danger">*</span> เป็นช่องที่ต้องกรอกข้อมูล</label>
                                                        </div>
                                                    </div>
                                               </div>

                                                <div class="row">
                                                    <div class="col-md-6 mb-3">
                                                        <label class="form-label">เลือกประเภทคำถาม <span class="text-danger">*</span></label>
                                                        <select class="form-control" name="type" id="type" onchange="change_type();">
                                                            <option value="">กรุณาเลือก</option>
                                                            <option value="vas">VAS</option>
                                                            <option value="womac">Womac Score</option>
                                                            <option value="sf12">SF12</option>
                                                        </select>
                                                    </div>
                                                </div>

                                               
                                               
                                            </div>
                                        </div>

                                        <!-- ประเภทคำถาม VAS -->
                                        <div id="show_type_1" class="card card-flush py-4">
                                            <div class="card-header">
                                                <div class="card-title">
                                                    <h2>คำถาม</h2>
                                                </div>
                                            </div>
                                            <div class="card-body pt-0">
                                                <div class="row mb-2">
                                                    <div class="col-md-6">
                                                        <div class="mb-4 fv-row">
                                                            <label class="form-label">ชื่อคำถาม <span class="text-danger">*</span></label>
                                                            <input type="text" id="name" name="name" class="form-control mb-2" placeholder="" value="" />
                                                        </div>
                                                    </div>
                                                </div>

                                                <div class="row mb-2">
                                                    <div class="col-md-6">
                                                        <div class="mb-4 fv-row">
                                                            <label class="form-label">รายละเอียด <span class="text-danger">*</span></label>
                                                            <input type="text" id="detail" name="detail" class="form-control mb-2" placeholder="" value="" />
                                                        </div>
                                                    </div>
                                                </div>

                                                <div class="row mb-2">
                                                    <div class="col-md-6">
                                                        <div class="mb-4 fv-row">
                                                            <label class="form-label">จำนวนระดับ</label>
                                                            <input type="text" id="level" name="level" class="form-control mb-2" placeholder="" value="0" disabled />
                                                        </div>
                                                    </div>
                                                </div>

                                                

                                                <div hidden id="sf12show" class="row mb-2">
                                                    <?php for($i=1;$i<=6;$i++): ?>
                                                    <div class="row mb-2">
                                                        <div class="col-md-4">
                                                            <div class="mb-4 fv-row">
                                                                <label class="form-label">คำตอบที่ <?php echo e(@$i); ?></label>
                                                                <input type="text" id="sf12_choice<?php echo e(@$i); ?>" name="sf12_choice<?php echo e(@$i); ?>" class="form-control mb-2" placeholder="" value="" />
                                                            </div>
                                                        </div>
                                                        <div class="col-md-2">
                                                            <div class="mb-4 fv-row">
                                                                <label class="form-label">คะแนน</label>
                                                                <input type="number" id="sf12_point<?php echo e(@$i); ?>" name="sf12_point<?php echo e(@$i); ?>" class="form-control mb-2" placeholder="" value="" />
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <?php endfor; ?>

                                                </div>

                                            </div>
                                        </div>
                                        <!-- ประเภทคำถาม Womac -->
                                        <!-- ประเภทคำถาม SF12 -->

                                        <div class="d-flex justify-content-end">
                                            <a href="<?php echo e(url("$segment/$folder")); ?>" id="" class="btn btn-light me-5">ยกเลิก</a>
                                            <button type="submit" id="" class="btn btn-primary"><span class="indicator-label">บันทึก</span></button>
                                        </div>
                                    </div>
                                </div>

                            </form>
                            </div>
                            <!--end::Content container-->
                        </div>
                        <!--end::Content-->


                    </div>
                </div>
            </div>
        </div>
    </div>
    <!--begin::Javascript-->
    <?php echo $__env->make("$prefix.layout.script", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <script>
        function change_type(){
            var type = $('#type').val();
            if(type == ""){
                $('#level').val("");
                $('#sf12show').attr('hidden',true);
            }
            else if(type == "vas"){
                $('#level').val(10);
                $('#sf12show').attr('hidden',true);
            }
            else if(type == "womac"){
                $('#level').val(4);
                $('#sf12show').attr('hidden',true);
            }
            else if(type == "sf12"){
                $('#level').val("สร้างคำตอบและคะแนนเอง");
                $('#sf12show').attr('hidden',false);
            }
        }

        function check_add() {
            // var role = $('#role').val();
            // var status_check = $('#status_check').val();
            // var name = $('#name').val();
            // var username = $('#username').val();
            // var password = $('#password').val();
            // var confirm_password = $('#confirm_password').val();

            // if (role == "") {
            //     toastr.error('กรุณาเลือกระดับของผู้ใช้งานนี้');
            //     return false;
            // }
            // if (status_check == "") {
            //     toastr.error('กรุณาเลือกสถานะการใช้งาน');
            //     return false;
            // }
            // if (name == "" || username == "" || password == "" || confirm_password == "") {
            //     toastr.error('กรุณากรอกข้อมูลให้ครบถ้วนก่อนบันทึกรายการ');
            //     return false;
            // }
            // if (password != confirm_password) {
            //     toastr.error('กรุณากรอกรหัสผ่านให้เหมือนกัน');
            //     return false;
            // }
        }
    </script>
    <!--end::Javascript-->
</body>
<!--end::Body-->

</html>
<?php /**PATH C:\laragon\www\cretive\cu-cat.com\resources\views/back-end/pages/question/add.blade.php ENDPATH**/ ?>