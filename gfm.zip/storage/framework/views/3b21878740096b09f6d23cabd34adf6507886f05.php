<!DOCTYPE html>
<html lang="en">
<!--begin::Head-->

<head>
    <?php echo $__env->make("$prefix.layout.head", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

</head>
<!--end::Head-->
<!--begin::Body-->

<body id="kt_app_body" data-kt-app-layout="dark-sidebar" data-kt-app-header-fixed="true" data-kt-app-sidebar-enabled="true"
    data-kt-app-sidebar-fixed="true" data-kt-app-sidebar-hoverable="true" data-kt-app-sidebar-push-header="true"
    data-kt-app-sidebar-push-toolbar="true" data-kt-app-sidebar-push-footer="true" data-kt-app-toolbar-enabled="true"
    class="app-default">


    <div class="d-flex flex-column flex-root app-root" id="kt_app_root">
        <!--begin::Page-->
        <div class="app-page flex-column flex-column-fluid" id="kt_app_page">
            <!--begin::Header-->
            <div id="kt_app_header" class="app-header">
                <!-- MENU -->
                <?php echo $__env->make("$prefix.layout.menu", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <!-- END MENU -->

                <!--begin::Main-->
                <div class="app-main flex-column flex-row-fluid" id="kt_app_main">
                    <!--begin::Content wrapper-->
                    <div class="d-flex flex-column flex-column-fluid">
                        <!--begin::Toolbar-->
                        <div id="kt_app_toolbar" class="app-toolbar py-3 py-lg-6">
                            <!--begin::Toolbar container-->
                            <?php echo $__env->make("$prefix.layout.breadcrumbs", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                            <!--end::Toolbar container-->
                        </div>
                        <!--end::Toolbar-->


                        <!--begin::Content-->
                        <div id="kt_app_content" class="app-content flex-column-fluid">
                            <!--begin::Content container-->
                            <div id="kt_app_content_container" class="app-container container-fluid">
                                

                                <div class="row">
                                    <div class="col-md-3">
                                        <div class="card mb-5 mb-xl-8">
                                            <div class="card-body pt-15">
                                                <div class="d-flex flex-center flex-column mb-5">
                                                    <div class="symbol symbol-150px symbol-circle mb-7">
                                                        <img src="<?php echo e($row->image); ?>" alt="image">
                                                    </div>
                                                    <a href="<?php echo e(url("$segment/$folder/view/$row->id")); ?>" class="fs-3 text-gray-800 text-hover-primary fw-bold mb-1"><?php echo e($row->fullname()); ?></a>
                                                </div>
                                                <div class="d-flex flex-stack fs-4 py-3">
                                                    <div class="fw-bold">รายละเอียด</div>
                                                    <?php echo @Helper::checkCurse(Auth::guard('user')->id()); ?>

                                                </div>
                                                <div class="separator separator-dashed my-3"></div>

                                                <div class="row">
                                                    <div class="col-md-12 fw-bold mt-5">เลขบัตรประชาชน</div>
                                                    <div class="col-md-12 text-gray-600"><?php echo e($row->idcard); ?></div>
                                                </div>

                                                <div class="row">
                                                    <div class="col-md-12 fw-bold mt-5">เบอร์โทรศัพท์</div>
                                                    <div class="col-md-12 text-gray-600"><?php echo e($row->phone); ?></div>
                                                </div>

                                                <div class="row">
                                                    <div class="col-md-12 fw-bold mt-5">เพศ</div>
                                                    <div class="col-md-12 text-gray-600"><?php echo e($row->sex); ?></div>
                                                </div>

                                                <div class="row">
                                                    <div class="col-md-12 fw-bold mt-5">วันเกิด</div>
                                                    <div class="col-md-12 text-gray-600"><?php echo e(date('d-m-Y',strtotime($row->birthdate))); ?></div>
                                                </div>

                                                <div class="row">
                                                    <div class="col-md-12 fw-bold mt-5">อายุ</div>
                                                    <div class="col-md-12 text-gray-600"><?php echo e($row->age); ?></div>
                                                </div>

                                                <div class="separator separator-dashed my-3"></div>
                                                <div class="row">
                                                    <div class="col-md-12 fw-bold">ข้อมูลดัชนีมวลกาย</div>
                                                </div>

                                                <div class="row">
                                                    <div class="col-md-12 fw-bold mt-5">ส่วนสูง</div>
                                                    <div class="col-md-12 text-gray-600"><?php echo e($row->height); ?></div>
                                                </div>

                                                <div class="row">
                                                    <div class="col-md-12 fw-bold mt-5">น้ำหนัก</div>
                                                    <div class="col-md-12 text-gray-600"><?php echo e($row->weight); ?></div>
                                                </div>

                                                <div class="row">
                                                    <div class="col-md-12 fw-bold mt-5">BMI</div>
                                                    <div class="col-md-12 text-gray-600"><?php echo e($row->bmi); ?></div>
                                                </div>


                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-9">
                                        <div class="row">
                                            <div class="col-md-12 mb-2 text-end">
                                                <a href="javascript:void(0);" onclick="createModal();" class="btn btn-sm btn-info">+ สร้างนัดหมายใหม่</a>
                                            </div>
                                        </div>
                                    <form id="menuForm" method="post" action="" onsubmit="return check_add();"  enctype="multipart/form-data">
                                    <?php echo csrf_field(); ?>
                                        <div class="flex-lg-row-fluid ms-lg-15">
                                            <ul class="nav nav-custom nav-tabs nav-line-tabs nav-line-tabs-2x border-0 fs-4 fw-semibold mb-8" role="tablist">
                                                <li class="nav-item" role="presentation">
                                                    <a class="nav-link text-active-primary pb-4 active" data-bs-toggle="tab" href="#cure-overview" aria-selected="true" role="tab">ภาพรวม</a>
                                                </li>
                                                <?php if(@$times): ?>
                                                    <?php $__currentLoopData = @$times; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index=>$time): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <li class="nav-item" role="presentation">
                                                        <a class="nav-link text-active-primary pb-4" data-bs-toggle="tab" href="#cure-<?php echo e(@$index+1); ?>" aria-selected="true" role="tab">พบหมอ ครั้งที่ <?php echo e(@$index+1); ?></a>
                                                    </li>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                <?php endif; ?>
											</ul>
                                            
                                            <div class="tab-content">
                                                <div class="tab-pane fade show active" id="cure-overview" role="tabpanel">
                                                    
                                                        <div class="d-flex flex-column flex-row-fluid gap-7 gap-lg-10">
                                                            <div class="card card-flush py-4">
                                                                <div class="card-header">
                                                                    <div class="card-title">
                                                                        <h2>ภาพรวม</h2>
                                                                    </div>
                                                                </div>
                                                                <div class="card-body pt-0">

                                                                    <div class="row mb-2">
                                                                        <label class="col-md-3 col-form-label">
                                                                            <img src="frontend/assets/img/menu-icon/icon-pill.svg" class="img-fluid" alt=""> มารับการรักษาเรื่อง
                                                                        </label>
                                                                        <div class="col-md-9">
                                                                            <input type="text" id="curse_detail" name="curse_detail" class="form-control" placeholder="กรุณากรอกข้อมูลการมารักษา" value="<?php echo e(@$questions->curse_detail); ?>" />
                                                                        </div>
                                                                    </div>
                                                                    <div class="row mb-2">
                                                                        <label class="col-md-3 col-form-label">
                                                                            <img src="frontend/assets/img/menu-icon/menu-doc.svg" class="img-fluid" alt=""> อื่นๆเพิ่มเติม
                                                                        </label>
                                                                        <div class="col-md-9">
                                                                            <input type="text" id="note" name="note" class="form-control" placeholder="กรอกข้อมูลอื่นๆเพิ่มเติม" value="<?php echo e(@$questions->note); ?>" />
                                                                        </div>
                                                                    </div>

                                                                    <div class="row mb-2">
                                                                        <label class="col-md-3 col-form-label">
                                                                            <img src="frontend/assets/img/menu-icon/menu-doc.svg" class="img-fluid" alt=""> วันที่นัดหมายครั้งแรก
                                                                        </label>
                                                                        <div class="col-md-9">
                                                                            <input type="text" class="form-control form-control-solid" readonly name="created_at" value="<?php echo e(date('d/m/Y',strtotime("+543 Years",strtotime($questions->created_at)))); ?>">
                                                                        </div>
                                                                    </div>

                                                                    <div class="row mb-2">
                                                                        <label class="col-md-3 col-form-label">
                                                                            <img src="frontend/assets/img/menu-icon/menu-doc.svg" class="img-fluid" alt=""> เวลาที่นัดหมายครั้งแรก
                                                                        </label>
                                                                        <div class="col-md-9">
                                                                            <input type="text" class="form-control form-control-solid" readonly name="created_at" value="<?php echo e(date('H:i น.',strtotime("+543 Years",strtotime($questions->created_at)))); ?>">
                                                                        </div>
                                                                    </div>

                                                                    <div class="row mb-2">
                                                                        <label class="col-md-3 col-form-label">
                                                                            <img src="frontend/assets/img/menu-icon/menu-doc.svg" class="img-fluid" alt=""> วันที่นัดหมายล่าสุด
                                                                        </label>
                                                                        <div class="col-md-9">
                                                                            <input type="text" class="form-control form-control-solid" readonly name="updated_at" value="<?php echo e(date('d/m/Y',strtotime("+543 Years",strtotime($questions->updated_at)))); ?>">
                                                                        </div>
                                                                    </div>

                                                                    <div class="row mb-2">
                                                                        <label class="col-md-3 col-form-label">
                                                                            <img src="frontend/assets/img/menu-icon/menu-doc.svg" class="img-fluid" alt=""> เวลาที่นัดหมายล่าสุด
                                                                        </label>
                                                                        <div class="col-md-9">
                                                                            <input type="text" class="form-control form-control-solid" readonly name="updated_at" value="<?php echo e(date('H:i น.',strtotime("+543 Years",strtotime($questions->updated_at)))); ?>">
                                                                        </div>
                                                                    </div>

                                                                    <div class="row mb-2">
                                                                        <label class="col-md-3 col-form-label">
                                                                            <img src="frontend/assets/img/menu-icon/menu-doc.svg" class="img-fluid" alt=""> สถานะการรักษา
                                                                        </label>
                                                                        <div class="col-md-9">
                                                                            <select class="form-select" id="isActive" name="isActive">
                                                                                <option value="waiting" <?php if($questions->isActive == "waiting"): ?> selected <?php endif; ?>>ยังอยู่ขั้นตอนการรักษา</option>
                                                                                <option value="success" <?php if($questions->isActive == "success"): ?> selected <?php endif; ?>>รักษาสำเร็จ</option>
                                                                                <option value="reject" <?php if($questions->isActive == "reject"): ?> selected <?php endif; ?>>รักษาไม่สำเร็จ</option>
                                                                            </select>
                                                                        </div>
                                                                    </div>

                                                                    

                                                                </div>
                                                            </div>
                                                        </div>
                                                    
                                                </div>
                                                <?php 
                                                $count_row = 0;
                                                ?>
                                            <?php if(@$times): ?>
                                                <?php $__currentLoopData = @$times; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index=>$time): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <?php $count_row++; ?>
                                                    <div class="tab-pane fade" id="cure-<?php echo e(@$index+1); ?>" role="tabpanel">
                                                        <input type="hidden" id="question_time_id_<?php echo e($index); ?>" name="question_time_id_<?php echo e($index); ?>" value="<?php echo e($time->id); ?>">
                                                        <div class="d-flex flex-column flex-row-fluid gap-7 gap-lg-10">
                                                            <div class="card card-flush py-4">
                                                                <div class="card-header">
                                                                    <div class="card-title">
                                                                        <h2>พบหมอ ครั้งที่ <?php echo e($index+1); ?></h2> 
                                                                    </div>
                                                                </div>
                                                                <div class="card-body pt-0">
                                                                    <div class="row mb-2">
                                                                        <div class="col-md-12">
                                                                            <a href="javascript:void(0);" onclick="editModal('<?php echo e($time->id); ?>');" style="margin-left:5px;" class="btn btn-sm btn-info"> แก้ไขนัดหมาย</a>
                                                                        </div>
                                                                    </div>

                                                                    <div class="row mb-2">
                                                                        <label class="col-md-3 col-form-label">
                                                                            <img src="frontend/assets/img/menu-icon/icon-doctor.svg" class="img-fluid" alt=""> แพทย์ผู้รักษา
                                                                        </label>
                                                                        <div class="col-md-9">
                                                                            <select readonly id="doctor_id_<?php echo e($index); ?>" name="doctor_id_<?php echo e($index); ?>" class="form-select form-select-solid" disabled>
                                                                                <option value="">กรุณาเลือกแพทย์ที่รักษา</option>
                                                                                <?php if(@$doctors): ?>
                                                                                    <?php $__currentLoopData = @$doctors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $doctor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                                    <option value="<?php echo e(@$doctor->id); ?>" <?php if($doctor->id == $time->doctor_id): ?> selected <?php endif; ?>><?php echo e(@$doctor->name); ?></option>
                                                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                                <?php endif; ?>
                                                                            </select>
                                                                        </div>
                                                                    </div>
                                                                    <div class="row mb-2">
                                                                        <label class="col-md-3 col-form-label">
                                                                            <img src="frontend/assets/img/menu-icon/icon-pill.svg" class="img-fluid" alt=""> ยาที่รักษา
                                                                        </label>
                                                                        <div class="col-md-9">
                                                                            <select readonly id="drug_id_<?php echo e($index); ?>" name="drug_id_<?php echo e($index); ?>" class="form-select form-select-solid" disabled>
                                                                                <option value="">กรุณาเลือกกลุ่มยาที่รักษา</option>
                                                                                <?php if(@$drugs): ?>
                                                                                    <?php $__currentLoopData = @$drugs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $drug): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                                    <option value="<?php echo e(@$drug->id); ?>" <?php if($drug->id == $time->drug_id): ?> selected <?php endif; ?>><?php echo e(@$drug->name); ?></option>
                                                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                                <?php endif; ?>
                                                                            </select>
                                                                        </div>
                                                                    </div>
                                                                    <div class="row mb-2">
                                                                        <label class="col-md-3 col-form-label">
                                                                            <img src="frontend/assets/img/menu-icon/menu-doc.svg" class="img-fluid" alt=""> อื่นๆเพิ่มเติม
                                                                        </label>
                                                                        <div class="col-md-9">
                                                                            <input disabled type="text" id="note_<?php echo e($index); ?>" name="note_<?php echo e($index); ?>" class="form-control" placeholder="กรุณาเลือกกลุ่มการรักษา" value="<?php echo e(@$time->note); ?>" />
                                                                        </div>
                                                                    </div>
    
                                                                    <div class="row mb-2">
                                                                        <label class="col-md-3 col-form-label">
                                                                            <img src="frontend/assets/img/menu-icon/menu-doc.svg" class="img-fluid" alt=""> วันที่นัดหมาย
                                                                        </label>
                                                                        <div class="col-md-9">
                                                                            <input disabled type="text" class="form-control form-control-solid" readonly name="datetime_service" value="<?php echo e(date('d/m/Y',strtotime("+543 Years",strtotime(@$time->datetime_service)))); ?>">
                                                                        </div>
                                                                    </div>
    
                                                                    <div class="row mb-2">
                                                                        <label class="col-md-3 col-form-label">
                                                                            <img src="frontend/assets/img/menu-icon/menu-doc.svg" class="img-fluid" alt=""> เวลาที่นัดหมาย
                                                                        </label>
                                                                        <div class="col-md-9">
                                                                            <input disabled type="text" class="form-control form-control-solid" readonly name="datetime_service" value="<?php echo e(date('H:i น.',strtotime("+543 Years",strtotime(@$time->datetime_service)))); ?>">
                                                                        </div>
                                                                    </div>

                                                                    <div class="row mb-2 mt-3">
                                                                        <div class="col-md-12">
                                                                            <div class="card-title">
                                                                                <h2>คะแนนการแบบทดสอบสมรรถณะของข้อเข่า</h2>
                                                                            </div>
                                                                        </div>
                                                                    </div>

                                                                    <div class="row mb-2">
                                                                        <label class="col-md-10 col-form-label">
                                                                            <img src="frontend/assets/img/menu-icon/menu-doc.svg" class="img-fluid" alt=""> ท่าที่ 1 : Timed Up and Go (TUG) ให้ผู้ป่วยลุกจากเก้าอี้เดินตรงไป 3 เมตร กลับตัวแล้วเดินกลับมานั่งที่เก้าอี้ตามเดิม
                                                                        </label>
                                                                        <div class="col-md-2">
                                                                            <input type="number" style="text-align:right;" class="form-control" id="performance1_point_<?php echo e($index); ?>" name="performance1_point_<?php echo e($index); ?>" value="<?php echo e($time->performance1_point); ?>">
                                                                        </div>
                                                                    </div>

                                                                    <div class="row mb-2">
                                                                        <label class="col-md-10 col-form-label">
                                                                            <img src="frontend/assets/img/menu-icon/menu-doc.svg" class="img-fluid" alt=""> ท่าที่ 2 : Five Time Sit to Stand Test (5TSST) ให้ผู้ป่วยทําการทดสอบลุกนั่ง 5 ครั้ง
                                                                        </label>
                                                                        <div class="col-md-2">
                                                                            <input type="number" style="text-align:right;" class="form-control" id="performance2_point_<?php echo e($index); ?>" name="performance2_point_<?php echo e($index); ?>" value="<?php echo e($time->performance2_point); ?>">
                                                                        </div>
                                                                    </div>

                                                                    <div class="row mb-2">
                                                                        <label class="col-md-10 col-form-label">
                                                                            <img src="frontend/assets/img/menu-icon/menu-doc.svg" class="img-fluid" alt=""> ท่าที่ 3 : 3-minute walk test (3MWT) การทดสอบสมรรถภาพทางกายด้วยการเดิน 3นาที โดยให้ได้ระยะทางมากที่สุด
                                                                        </label>
                                                                        <div class="col-md-2">
                                                                            <input type="number" style="text-align:right;" class="form-control" id="performance3_point_<?php echo e($index); ?>" name="performance3_point_<?php echo e($index); ?>" value="<?php echo e($time->performance3_point); ?>">
                                                                        </div>
                                                                    </div>

                                                                    <div class="row mb-2 mt-3">
                                                                        <div class="col-md-12">
                                                                            <div class="card-title">
                                                                                <h2>คะแนนรวมแบบทดสอบ</h2>
                                                                            </div>
                                                                        </div>
                                                                    </div>

                                                                    <div class="row mb-2">
                                                                        <label class="col-md-10 col-form-label">
                                                                            <img src="frontend/assets/img/menu-icon/menu-doc.svg" class="img-fluid" alt=""> VAS
                                                                        </label>
                                                                        <div class="col-md-2">
                                                                            <input type="text" style="text-align:right;" class="form-control form-control-solid" readonly value="<?php echo e($time->vas_point); ?>">
                                                                        </div>
                                                                    </div>

                                                                    <div class="row mb-2">
                                                                        <label class="col-md-10 col-form-label">
                                                                            <img src="frontend/assets/img/menu-icon/menu-doc.svg" class="img-fluid" alt=""> Womac Score
                                                                        </label>
                                                                        <div class="col-md-2">
                                                                            <input type="text" style="text-align:right;" class="form-control form-control-solid" readonly value="<?php echo e($time->womac_point); ?>">
                                                                        </div>
                                                                    </div>

                                                                    <div class="row mb-2">
                                                                        <label class="col-md-10 col-form-label">
                                                                            <img src="frontend/assets/img/menu-icon/menu-doc.svg" class="img-fluid" alt=""> SF - 12
                                                                        </label>
                                                                        <div class="col-md-2">
                                                                            <input type="text" style="text-align:right;" class="form-control form-control-solid" readonly value="<?php echo e($time->sf12_point); ?>">
                                                                        </div>
                                                                    </div>

                                                                    <div class="row mb-2">
                                                                        <label class="col-md-10 col-form-label">
                                                                            <img src="frontend/assets/img/menu-icon/menu-doc.svg" class="img-fluid" alt=""> รวมคะแนน
                                                                        </label>
                                                                        <div class="col-md-2">
                                                                            <input type="text" style="text-align:right;" class="form-control form-control-solid" readonly value="<?php echo e($time->vas_point + $time->sf12_point + $time->womac_point); ?>">
                                                                        </div>
                                                                    </div>

                                                                   
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            <?php endif; ?>
                                            </div>

                                        </div>
                                        <input type="hidden" id="count_row" name="count_row" value="<?php echo e(@$count_row); ?>">
                                        <div class="d-flex justify-content-end mt-3">
                                            <a href="<?php echo e(url("$segment/$folder/view/$questions->customer_id")); ?>" id="" class="btn btn-light me-5">ยกเลิก</a>
                                            <button type="submit" id="" class="btn btn-primary"><span class="indicator-label">บันทึก</span></button>
                                        </div>
                                    </form>

                                    </div>
                                </div>

                            </div>
                            <!--end::Content container-->
                        </div>
                        <!--end::Content-->


                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="modal fade" id="modelShow" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered mw-650px">
            <div class="modal-content">
                <div class="show_modal"></div>
            </div>
        </div>
    </div>

    
    <!--begin::Javascript-->
    <?php echo $__env->make("$prefix.layout.script", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <script>
        function createModal() {
            $.ajax({
                type: 'GET',
                url: "<?php echo e("$segment/$folder/questions/$questions->id/add"); ?>",
                data: {
                    "_token": "<?php echo e(csrf_token()); ?>",
                },
                dataType: 'html',
                success: function(data) {
                    $('#modelShow').modal('show');
                    $('.show_modal').html(data);
                }
            })
        }

        function editModal(question_time_id) {
            $.ajax({
                type: 'GET',
                url: "<?php echo e("$segment/$folder/questions/$questions->id/edit"); ?>",
                data: {
                    "_token": "<?php echo e(csrf_token()); ?>",
                    question_time_id: question_time_id,
                },
                dataType: 'html',
                success: function(data) {
                    $('#modelShow').modal('show');
                    $('.show_modal').html(data);
                }
            })
        }
        

        var options = {
            series: [67, 33],
            colors: ['#FF6900', '#EAEAEA'],
            chart: {
                width: '100%',
                type: 'pie',

            },
            dataLabels: {
                enabled: true,
                textAnchor: 'middle',
                style: {
                    fontSize: "28px",
                    fontFamily: 'IBM Plex Sans Thai, sans-serif',
                    colors: ['#fff', 'transparent'],
                },
                formatter: function(val, opts) {
                    return val + '%'
                },
            },
            legend: {
                show: false
            },
            tooltip: {
                enabled: false
            },

            plotOptions: {
                pie: {
                    dataLabels: {
                        offset: -50,
                    },
                }
            },
        };

        var chart = new ApexCharts(document.querySelector("#chart"), options);
        chart.render();
    </script>
    <script>
        $("#example_image01").click(function() {
            $("input[id='image']").click();
        });

        function readURL01(input) {
            if (input.files && input.files[0]) {
                var reader = new FileReader();
                reader.onload = function(e) {
                    $('#example_image01').attr('src', e.target.result);
                }
                reader.readAsDataURL(input.files[0]);
            }
        }

        function check_add() {
            // var role = $('#role').val();
            // var status_check = $('#status_check').val();
            // var name = $('#name').val();
            // var username = $('#username').val();
            // var password = $('#password').val();
            // var confirm_password = $('#confirm_password').val();

            // if (role == "") {
            //     toastr.error('กรุณาเลือกระดับของผู้ใช้งานนี้');
            //     return false;
            // }
            // if (status_check == "") {
            //     toastr.error('กรุณาเลือกสถานะการใช้งาน');
            //     return false;
            // }
            // if (name == "" || username == "" || password == "" || confirm_password == "") {
            //     toastr.error('กรุณากรอกข้อมูลให้ครบถ้วนก่อนบันทึกรายการ');
            //     return false;
            // }
            // if (password != confirm_password) {
            //     toastr.error('กรุณากรอกรหัสผ่านให้เหมือนกัน');
            //     return false;
            // }
        }
    </script>
    <!--end::Javascript-->
</body>
<!--end::Body-->

</html>
<?php /**PATH C:\laragon\www\cretive\cu-cat.com\resources\views/back-end/pages/customer/view-cure.blade.php ENDPATH**/ ?>