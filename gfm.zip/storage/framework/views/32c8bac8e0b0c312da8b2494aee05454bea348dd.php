<!DOCTYPE html>
<html lang="en">
<!--begin::Head-->

<head>
    <?php echo $__env->make("$prefix.layout.head", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

</head>
<!--end::Head-->
<!--begin::Body-->

<body id="kt_app_body" data-kt-app-layout="dark-sidebar" data-kt-app-header-fixed="true" data-kt-app-sidebar-enabled="true"
    data-kt-app-sidebar-fixed="true" data-kt-app-sidebar-hoverable="true" data-kt-app-sidebar-push-header="true"
    data-kt-app-sidebar-push-toolbar="true" data-kt-app-sidebar-push-footer="true" data-kt-app-toolbar-enabled="true"
    class="app-default">


    <div class="d-flex flex-column flex-root app-root" id="kt_app_root">
        <!--begin::Page-->
        <div class="app-page flex-column flex-column-fluid" id="kt_app_page">
            <!--begin::Header-->
            <div id="kt_app_header" class="app-header">
                <!-- MENU -->
                <?php echo $__env->make("$prefix.layout.menu", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <!-- END MENU -->

                <!--begin::Main-->
                <div class="app-main flex-column flex-row-fluid" id="kt_app_main">
                    <!--begin::Content wrapper-->
                    <div class="d-flex flex-column flex-column-fluid">
                        <!--begin::Toolbar-->
                        <div id="kt_app_toolbar" class="app-toolbar py-3 py-lg-6">
                            <!--begin::Toolbar container-->
                            <?php echo $__env->make("$prefix.layout.breadcrumbs", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                            <!--end::Toolbar container-->
                        </div>
                        <!--end::Toolbar-->


                        <!--begin::Content-->
                        <div id="kt_app_content" class="app-content flex-column-fluid">
                            <!--begin::Content container-->
                            <div id="kt_app_content_container" class="app-container container-fluid">
                                <form id="menuForm" method="post" action="" onsubmit="return check_add();"  enctype="multipart/form-data">
                                    <?php echo csrf_field(); ?>

                                    <div class="card card-flush py-4 mb-2">
                                        <div class="card-header">
                                            <div class="card-title">
                                                <h2>รายละเอียดสิทธิ์</h2>
                                            </div>
                                        </div>
                                        <div class="card-body pt-0">

                                            <div class="row mb-2">
                                                <label class="col-md-3 col-form-label">ชื่อสิทธิ์ <span class="text-danger">*</span></label>
                                                <div class="col-md-9">
                                                    <input type="text" id="name" name="name" class="form-control mb-2" placeholder="กรอกชื่อ" value="" />
                                                </div>
                                            </div>
                                            <div class="row mb-2">
                                                <label class="col-md-3 col-form-label">รายละเอียด</label>
                                                <div class="col-md-9">
                                                    <input type="text" id="detail" name="detail" class="form-control mb-2" placeholder="กรอกรายละเอียด" value="" />
                                                </div>
                                            </div>
                                            <div class="row mb-2">
                                                <label class="col-md-3 col-form-label">สถานะ</label>
                                                <div class="col-md-9">
                                                    <label class="form-check form-switch form-switch-sm form-check-custom form-check-solid">
                                                        <input class="form-check-input" type="checkbox" value="Y" id="isActive" name="isActive">
                                                        <span class="form-check-label fw-semibold text-muted" for="">ใช้งาน</span>
                                                    </label>
                                                </div>
                                            </div>
                                        </div>
                                    </div>

                                    <div class="d-flex justify-content-end">
                                        <a href="<?php echo e(url("$segment/$folder")); ?>" id="" class="btn btn-light me-5">ยกเลิก</a>
                                        <button type="submit" id="" class="btn btn-primary"><span class="indicator-label">บันทึก</span></button>
                                    </div>

                                </form>
                            </div>
                            <!--end::Content container-->
                        </div>
                        <!--end::Content-->


                    </div>
                </div>
            </div>
        </div>
    </div>
    <!--begin::Javascript-->
    <?php echo $__env->make("$prefix.layout.script", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <script>
        function check_add() {
            // var role = $('#role').val();
            // var status_check = $('#status_check').val();
            // var name = $('#name').val();
            // var username = $('#username').val();
            // var password = $('#password').val();
            // var confirm_password = $('#confirm_password').val();

            // if (role == "") {
            //     toastr.error('กรุณาเลือกระดับของผู้ใช้งานนี้');
            //     return false;
            // }
            // if (status_check == "") {
            //     toastr.error('กรุณาเลือกสถานะการใช้งาน');
            //     return false;
            // }
            // if (name == "" || username == "" || password == "" || confirm_password == "") {
            //     toastr.error('กรุณากรอกข้อมูลให้ครบถ้วนก่อนบันทึกรายการ');
            //     return false;
            // }
            // if (password != confirm_password) {
            //     toastr.error('กรุณากรอกรหัสผ่านให้เหมือนกัน');
            //     return false;
            // }
        }
    </script>
    <!--end::Javascript-->
</body>
<!--end::Body-->

</html>
<?php /**PATH C:\laragon\www\cretive\cu-cat.com\resources\views/back-end/pages/administrator/permission/add.blade.php ENDPATH**/ ?>