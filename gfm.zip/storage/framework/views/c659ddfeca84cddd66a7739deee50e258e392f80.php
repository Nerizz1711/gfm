<!DOCTYPE html>
<html lang="en">
<!--begin::Head-->

<head>
    <?php echo $__env->make("$prefix.layout.head", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

</head>
<!--end::Head-->
<!--begin::Body-->

<body id="kt_app_body" data-kt-app-layout="dark-sidebar" data-kt-app-header-fixed="true" data-kt-app-sidebar-enabled="true"
    data-kt-app-sidebar-fixed="true" data-kt-app-sidebar-hoverable="true" data-kt-app-sidebar-push-header="true"
    data-kt-app-sidebar-push-toolbar="true" data-kt-app-sidebar-push-footer="true" data-kt-app-toolbar-enabled="true"
    class="app-default">


    <div class="d-flex flex-column flex-root app-root" id="kt_app_root">
        <!--begin::Page-->
        <div class="app-page flex-column flex-column-fluid" id="kt_app_page">
            <!--begin::Header-->
            <div id="kt_app_header" class="app-header">
                <!-- MENU -->
                <?php echo $__env->make("$prefix.layout.menu", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <!-- END MENU -->

                <!--begin::Main-->
                <div class="app-main flex-column flex-row-fluid" id="kt_app_main">
                    <!--begin::Content wrapper-->
                    <div class="d-flex flex-column flex-column-fluid">
                        <!--begin::Toolbar-->
                        <div id="kt_app_toolbar" class="app-toolbar py-3 py-lg-6 container-xxl">
                            <!--begin::Toolbar container-->
                            <?php echo $__env->make("$prefix.layout.breadcrumbs", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                            <!--end::Toolbar container-->
                        </div>
                        <!--end::Toolbar-->


                        <!--begin::Content-->
                        <div id="kt_app_content" class="app-content flex-column-fluid">
                            <!--begin::Content container-->
                            <div id="kt_app_content_container" class="app-container container-xxl">
                                

                                <div class="card mb-5 mb-xl-10">
                                    <div class="card-body pt-9 pb-0">
                                        <!--begin::Details-->
                                        <div class="d-flex flex-wrap flex-sm-nowrap mb-3">
                                            <!--begin: Pic-->
                                            <div class="me-7 mb-4">
                                                <div class="symbol symbol-100px symbol-lg-160px symbol-fixed position-relative">
                                                    <img src="<?php echo e($row->image); ?>" alt="image">
                                                    <div class="position-absolute translate-middle bottom-0 start-100 mb-6 bg-success rounded-circle border border-4 border-body h-20px w-20px"></div>
                                                </div>
                                            </div>
                                            <!--end::Pic-->
                                            <!--begin::Info-->
                                            <div class="flex-grow-1">
                                                <!--begin::Title-->
                                                <div class="d-flex justify-content-between align-items-start flex-wrap mb-2">
                                                    <!--begin::User-->
                                                    <div class="d-flex flex-column">
                                                        <!--begin::Name-->
                                                        <div class="d-flex align-items-center mb-2">
                                                            <a href="#" class="text-gray-900 text-hover-primary fs-2 fw-bold me-1"><?php echo e($row->name); ?></a>
                                                        </div>
                                                        <!--end::Name-->
                                                        <!--begin::Info-->
                                                        <div class="d-flex flex-wrap fw-semibold fs-6 mb-4 pe-2">
                                                            <a href="#" class="d-flex align-items-center text-gray-400 text-hover-primary me-5 mb-2">
                                                            <span class="svg-icon svg-icon-4 me-1">
                                                                <svg width="18" height="18" viewBox="0 0 18 18" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                                    <path opacity="0.3" d="M16.5 9C16.5 13.125 13.125 16.5 9 16.5C4.875 16.5 1.5 13.125 1.5 9C1.5 4.875 4.875 1.5 9 1.5C13.125 1.5 16.5 4.875 16.5 9Z" fill="currentColor"></path>
                                                                    <path d="M9 16.5C10.95 16.5 12.75 15.75 14.025 14.55C13.425 12.675 11.4 11.25 9 11.25C6.6 11.25 4.57499 12.675 3.97499 14.55C5.24999 15.75 7.05 16.5 9 16.5Z" fill="currentColor"></path>
                                                                    <rect x="7" y="6" width="4" height="4" rx="2" fill="currentColor"></rect>
                                                                </svg>
                                                            </span>
                                                            <!--end::Svg Icon-->Developer</a>

                                                            <a href="#" class="d-flex align-items-center text-gray-400 text-hover-primary mb-2">
                                                            <!--begin::Svg Icon | path: icons/duotune/communication/com011.svg-->
                                                            <span class="svg-icon svg-icon-4 me-1">
                                                                <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                                    <path opacity="0.3" d="M21 19H3C2.4 19 2 18.6 2 18V6C2 5.4 2.4 5 3 5H21C21.6 5 22 5.4 22 6V18C22 18.6 21.6 19 21 19Z" fill="currentColor"></path>
                                                                    <path d="M21 5H2.99999C2.69999 5 2.49999 5.10005 2.29999 5.30005L11.2 13.3C11.7 13.7 12.4 13.7 12.8 13.3L21.7 5.30005C21.5 5.10005 21.3 5 21 5Z" fill="currentColor"></path>
                                                                </svg>
                                                            </span>
                                                            <!--end::Svg Icon--><?php echo e($row->email); ?></a>
                                                        </div>
                                                        <!--end::Info-->
                                                    </div>
                                                </div>
                                                <!--end::Title-->

                                                <div class="d-flex flex-wrap flex-stack">
                                                    <div class="d-flex flex-column flex-grow-1 pe-8">
                                                        <div class="d-flex flex-wrap">
                                                            <div class="border border-gray-300 border-dashed rounded min-w-125px py-3 px-4 me-6 mb-3">
                                                                <!--begin::Number-->
                                                                <div class="d-flex align-items-center">
                                                                    <span class="svg-icon svg-icon-3 svg-icon-success me-2">
                                                                      
                                                                    </span>
                                                                    <div class="fs-2 fw-bold counted" data-kt-countup="true" data-kt-countup-value="100" data-kt-countup-prefix="$" data-kt-initialized="1">100</div>
                                                                </div>
                                                                <div class="fw-semibold fs-6 text-gray-400">ยอดการรักษา</div>
                                                            </div>
                                                            <!--end::Stat-->
                                                            <!--begin::Stat-->
                                                           
                                                        </div>
                                                        <!--end::Stats-->
                                                    </div>
                                                    <!--end::Wrapper-->
                                                </div>
                                                <!--end::Stats-->
                                            </div>
                                            <!--end::Info-->
                                        </div>
                                        <!--end::Details-->
                                        <!--begin::Navs-->
                                        <ul class="nav nav-stretch nav-line-tabs nav-line-tabs-2x border-transparent fs-5 fw-bold">
                                            <!--begin::Nav item-->
                                            <li class="nav-item mt-2">
                                                <a class="nav-link text-active-primary ms-0 me-10 py-5 active" href="../../demo1/dist/account/overview.html">Overview</a>
                                            </li>
                                        </ul>
                                        <!--begin::Navs-->
                                    </div>
                                </div>

                                <div class="card mb-5 mb-xl-10" id="kt_profile_details_view">
                                    <div class="card-header cursor-pointer">
                                        <div class="card-title m-0">
                                            <h3 class="fw-bold m-0">Profile Details</h3>
                                        </div>
                                        <a href="<?php echo e(url("$segment/$folder/$row->id")); ?>" class="btn btn-sm btn-primary align-self-center">แก้ไขข้อมูล</a>
                                    </div>
                                    <div class="card-body p-9">

                                        <div class="row mb-7">
                                            <label class="col-lg-4 fw-semibold text-muted">คำนำหน้าชื่อ</label>
                                            <div class="col-lg-8">
                                                <span class="fw-bold fs-6 text-gray-800"><?php echo e($row->title); ?></span>
                                            </div>
                                        </div>

                                        <div class="row mb-7">
                                            <label class="col-lg-4 fw-semibold text-muted">ชื่อภาษาไทย</label>
                                            <div class="col-lg-8">
                                                <span class="fw-bold fs-6 text-gray-800"><?php echo e($row->name_th); ?></span>
                                            </div>
                                        </div>

                                        <div class="row mb-7">
                                            <label class="col-lg-4 fw-semibold text-muted">ชื่อภาษาอังกฤษ</label>
                                            <div class="col-lg-8">
                                                <span class="fw-bold fs-6 text-gray-800"><?php echo e($row->name_en); ?></span>
                                            </div>
                                        </div>

                                        <div class="row mb-7">
                                            <label class="col-lg-4 fw-semibold text-muted">เลขบัตรประชาชน/พาสปอร์ต</label>
                                            <div class="col-lg-8">
                                                <span class="fw-bold fs-6 text-gray-800"><?php echo e($row->idcard); ?></span>
                                            </div>
                                        </div>
                                       

                                        <div class="row mb-7">
                                            <label class="col-lg-4 fw-semibold text-muted">วันเกิด</label>
                                            <div class="col-lg-8">
                                                <span class="fw-bold fs-6 text-gray-800"><?php echo e($row->birthdate); ?></span>
                                            </div>
                                        </div>
                                       

                                        <div class="row mb-7">
                                            <label class="col-lg-4 fw-semibold text-muted">เบอร์โทร</label>
                                            <div class="col-lg-8">
                                                <span class="fw-bold fs-6 text-gray-800"><?php echo e($row->phone); ?></span>
                                            </div>
                                        </div>
                                       

                                        <div class="row mb-7">
                                            <label class="col-lg-4 fw-semibold text-muted">อีเมล</label>
                                            <div class="col-lg-8">
                                                <span class="fw-bold fs-6 text-gray-800"><?php echo e($row->email); ?></span>
                                            </div>
                                        </div>
                                       
                                        <?php if($row->isActive == 'Y'): ?>
                                        <div class="notice d-flex bg-light-success rounded border-success border border-dashed p-6">
                                            <span class="svg-icon svg-icon-2tx svg-icon-success me-4">
                                                <i style="font-size:24px;" class="fa fa-check-circle text-success"></i>
                                            </span>
                                            <div class="d-flex flex-stack flex-grow-1">
                                                <div class="fw-semibold">
                                                    <h4 class="fw-bold text-success">สถานะ : ใช้งานปกติ</h4>
                                                    <div class="fs-6 text-gray-700">ผู้ใช้งานสามารถเข้าใช้งานเว็บไซต์ได้ปกติ !</div>
                                                </div>
                                            </div>
                                            <!--end::Wrapper-->
                                        </div>
                                        <?php else: ?>
                                        <div class="notice d-flex bg-light-danger rounded border-danger border border-dashed p-6">
                                            <span class="svg-icon svg-icon-2tx svg-icon-danger me-4">
                                                <i style="font-size:24px;" class="fa fa-times-circle text-danger"></i>
                                            </span>
                                            <div class="d-flex flex-stack flex-grow-1">
                                                <div class="fw-semibold">
                                                    <h4 class="fw-bold text-danger">สถานะ : ไม่สามารถใช้งานได้ !</h4>
                                                    <div class="fs-6 text-gray-700">ผู้ใช้งานนี้ถูกปิดการใช้งานอยู่ จะไม่สามารถเข้าสู่เว็บไซต์ได้ ถ้าหากต้องการให้ใช้งานได้กรุณาเปลี่ยนสถานะ !</div>
                                                </div>
                                            </div>
                                            <!--end::Wrapper-->
                                        </div>
                                        <?php endif; ?>

                                        <!--end::Notice-->
                                    </div>
                                    <!--end::Card body-->
                                </div>

                                <div class="card mb-5 mb-lg-10">
                                    <!--begin::Card header-->
                                    <div class="card-header">
                                        <!--begin::Heading-->
                                        <div class="card-title">
                                            <h3>Login Sessions</h3>
                                        </div>
                                        <!--end::Heading-->
                                        <!--begin::Toolbar-->
                                        <div class="card-toolbar">
                                            <div class="my-1 me-4">
                                                <!--begin::Select-->
                                                <select class="form-select form-select-sm form-select-solid w-125px select2-hidden-accessible" data-control="select2" data-placeholder="Select Hours" data-hide-search="true" data-select2-id="select2-data-10-ogtg" tabindex="-1" aria-hidden="true" data-kt-initialized="1">
                                                    <option value="1" selected="selected" data-select2-id="select2-data-12-1vgh">1 Hours</option>
                                                    <option value="2">6 Hours</option>
                                                    <option value="3">12 Hours</option>
                                                    <option value="4">24 Hours</option>
                                                </select><span class="select2 select2-container select2-container--bootstrap5" dir="ltr" data-select2-id="select2-data-11-7hxr" style="width: 100%;"><span class="selection"><span class="select2-selection select2-selection--single form-select form-select-sm form-select-solid w-125px" role="combobox" aria-haspopup="true" aria-expanded="false" tabindex="0" aria-disabled="false" aria-labelledby="select2-cgjn-container" aria-controls="select2-cgjn-container"><span class="select2-selection__rendered" id="select2-cgjn-container" role="textbox" aria-readonly="true" title="1 Hours">1 Hours</span><span class="select2-selection__arrow" role="presentation"><b role="presentation"></b></span></span></span><span class="dropdown-wrapper" aria-hidden="true"></span></span>
                                                <!--end::Select-->
                                            </div>
                                            <a href="#" class="btn btn-sm btn-primary my-1">View All</a>
                                        </div>
                                        <!--end::Toolbar-->
                                    </div>
                                    <!--end::Card header-->
                                    <!--begin::Card body-->
                                    <div class="card-body p-0">
                                        <!--begin::Table wrapper-->
                                        <div class="table-responsive">
                                            <!--begin::Table-->
                                            <table class="table align-middle table-row-bordered table-row-solid gy-4 gs-9">
                                                <!--begin::Thead-->
                                                <thead class="border-gray-200 fs-5 fw-semibold bg-lighten">
                                                    <tr>
                                                        <th class="min-w-250px">Location</th>
                                                        <th class="min-w-100px">Status</th>
                                                        <th class="min-w-150px">Device</th>
                                                        <th class="min-w-150px">IP Address</th>
                                                        <th class="min-w-150px">Time</th>
                                                    </tr>
                                                </thead>
                                                <!--end::Thead-->
                                                <!--begin::Tbody-->
                                                <tbody class="fw-6 fw-semibold text-gray-600">
                                                    <tr>
                                                        <td>
                                                            <a href="#" class="text-hover-primary text-gray-600">USA(5)</a>
                                                        </td>
                                                        <td>
                                                            <span class="badge badge-light-success fs-7 fw-bold">OK</span>
                                                        </td>
                                                        <td>Chrome - Windows</td>
                                                        <td>236.125.56.78</td>
                                                        <td>2 mins ago</td>
                                                    </tr>
                                                    <tr>
                                                        <td>
                                                            <a href="#" class="text-hover-primary text-gray-600">United Kingdom(10)</a>
                                                        </td>
                                                        <td>
                                                            <span class="badge badge-light-success fs-7 fw-bold">OK</span>
                                                        </td>
                                                        <td>Safari - Mac OS</td>
                                                        <td>236.125.56.78</td>
                                                        <td>10 mins ago</td>
                                                    </tr>
                                                    <tr>
                                                        <td>
                                                            <a href="#" class="text-hover-primary text-gray-600">Norway(-)</a>
                                                        </td>
                                                        <td>
                                                            <span class="badge badge-light-danger fs-7 fw-bold">ERR</span>
                                                        </td>
                                                        <td>Firefox - Windows</td>
                                                        <td>236.125.56.10</td>
                                                        <td>20 mins ago</td>
                                                    </tr>
                                                    <tr>
                                                        <td>
                                                            <a href="#" class="text-hover-primary text-gray-600">Japan(112)</a>
                                                        </td>
                                                        <td>
                                                            <span class="badge badge-light-success fs-7 fw-bold">OK</span>
                                                        </td>
                                                        <td>iOS - iPhone Pro</td>
                                                        <td>236.125.56.54</td>
                                                        <td>30 mins ago</td>
                                                    </tr>
                                                    <tr>
                                                        <td>
                                                            <a href="#" class="text-hover-primary text-gray-600">Italy(5)</a>
                                                        </td>
                                                        <td>
                                                            <span class="badge badge-light-warning fs-7 fw-bold">WRN</span>
                                                        </td>
                                                        <td>Samsung Noted 5- Android</td>
                                                        <td>236.100.56.50</td>
                                                        <td>40 mins ago</td>
                                                    </tr>
                                                </tbody>
                                                <!--end::Tbody-->
                                            </table>
                                            <!--end::Table-->
                                        </div>
                                        <!--end::Table wrapper-->
                                    </div>
                                    <!--end::Card body-->
                                </div>

                            </div>
                            <!--end::Content container-->
                        </div>
                        <!--end::Content-->


                    </div>
                </div>
            </div>
        </div>
    </div>
    <!--begin::Javascript-->
    <?php echo $__env->make("$prefix.layout.script", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <script>
        $("#example_image01").click(function() {
            $("input[id='image']").click();
        });

        function readURL01(input) {
            if (input.files && input.files[0]) {
                var reader = new FileReader();
                reader.onload = function(e) {
                    $('#example_image01').attr('src', e.target.result);
                }
                reader.readAsDataURL(input.files[0]);
            }
        }

        function check_add() {
            // var role = $('#role').val();
            // var status_check = $('#status_check').val();
            // var name = $('#name').val();
            // var username = $('#username').val();
            // var password = $('#password').val();
            // var confirm_password = $('#confirm_password').val();

            // if (role == "") {
            //     toastr.error('กรุณาเลือกระดับของผู้ใช้งานนี้');
            //     return false;
            // }
            // if (status_check == "") {
            //     toastr.error('กรุณาเลือกสถานะการใช้งาน');
            //     return false;
            // }
            // if (name == "" || username == "" || password == "" || confirm_password == "") {
            //     toastr.error('กรุณากรอกข้อมูลให้ครบถ้วนก่อนบันทึกรายการ'); 
            //     return false;
            // }
            // if (password != confirm_password) {
            //     toastr.error('กรุณากรอกรหัสผ่านให้เหมือนกัน');
            //     return false;
            // }
        }
    </script>
    <!--end::Javascript-->
</body>
<!--end::Body-->

</html>
<?php /**PATH C:\laragon\www\cretive\cu-cat.com\resources\views/back-end/pages/administrator/user/view.blade.php ENDPATH**/ ?>