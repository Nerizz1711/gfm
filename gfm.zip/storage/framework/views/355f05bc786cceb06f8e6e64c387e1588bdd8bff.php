<!doctype html>
<html lang="en">

<head>

      <?php echo $__env->make("back-end.layout.header", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</head>

<body data-sidebar="dark">

      <!-- Script Zone -->
      <?php echo $__env->make("back-end.layout.script", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
      <script>
            const url = '<?php echo e(@$url); ?>';
            $(function() {
                  Swal.fire({
                        title: "สำเร็จ",
                        text: "ระบบได้ทำการบันทึกข้อมูลเรียบร้อย",
                        icon: "success",
                        allowOutsideClick: false,
                  }).then((result) => {
                        if (url == '') {
                              window.location = window.location.href;
                        } else {
                              window.location = url
                        }
                  });
            })
      </script>

</body>

</html><?php /**PATH C:\laragon\www\orange\pipat-template\resources\views/back-end/alert/success.blade.php ENDPATH**/ ?>