<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>CU-CAT</title>

    <?php echo $__env->make("$prefix.layout.stylesheet", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</head>

<body>

    <section id="content">
        <div class="performance">
            <div class="mobile-size">
                <!-- Header -->
                <?php echo $__env->make("$prefix.layout.header", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <!-- End Header -->

                <div class="row">
                    <div class="col-xl-12">
                        <div class="box-heading">
                            <p class="name-heading">แบบทดสอบสมรรถณะของข้อเข่า <br />ผลรวม 27 คะแนน</p>
                        </div>
                        <div class="container-center">
                            <?php
              $name = array(
                '1' => 'ท่าที่ 1 : Five Time Sit to Stand Test (5TSST) ให้ผู้ป่วยทําการทดสอบลุกนั่ง 5 ครั้ง',
                '2' => 'ท่าที่ 2 : Timed Up and Go (TUG) ให้ผู้ป่วยลุกจากเก้าอี้เดินตรงไป 3 เมตร กลับตัวแล้วเดินกลับมานั่งที่เก้าอี้ตามเดิม',
                '3' => 'ท่าที่ 3 : 3-minute walk test (3MWT) การทดสอบสมรรถภาพทางกายด้วยการเดิน 3นาที โดยให้ได้ระยะทางมากที่สุด',
              );
              for ($i = 1; $i <= 3; $i++) {
              ?>
                            <div class="box-performance">
                                <h5><?php echo $name[$i]; ?></h5>
                                <img src="frontend/gif/<?php echo e(@$i); ?>.gif" class="img-fluid" alt="" style="margin: 0rem !important;">
                                
                            </div>
                            <hr />
                            <?php } ?>

                            <a href="<?php echo e(url("home")); ?>" class="btn-custom  btn-grays-outline" tabindex="-1" role="button"
                                aria-disabled="false">ย้อนกลับ</a>
                        </div>
                    </div>

                </div>
            </div>
    </section>

    <?php echo $__env->make("$prefix.layout.javascript", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

</body>

</html>
<?php /**PATH C:\laragon\www\cretive\cu-cat.com\resources\views/front-end/performance.blade.php ENDPATH**/ ?>