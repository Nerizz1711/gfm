<!DOCTYPE html>
<html lang="en" class="light">
    <!-- BEGIN: Head -->
    <head>
        <?php echo $__env->make("$prefix.layout.header", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </head>
    <!-- END: Head -->
    <body class="main">
        
        <!-- BEGIN: MENU -->
        <?php echo $__env->make("$prefix.layout.menu-top", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <!-- END: Menu -->

       
        <div class="wrapper">
            <div class="wrapper-box">
                <!-- BEGIN: Side Menu -->
                <?php echo $__env->make("$prefix.layout.menu-slide", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <!-- END: Side Menu -->

                <!-- BEGIN: Content -->
                <div class="content">

                    <div class="intro-y flex flex-col sm:flex-row items-center mt-8 mb-2">
                        <h2 class="text-lg font-medium mr-auto">
                            TEMPLATE FORM
                        </h2>
                        <div class="w-full sm:w-auto flex mt-4 sm:mt-0">
                        </div>
                    </div>
        
                    <div class="intro-y box">
                        <div class="p-5" id="head-options-table">
                            
                        </div>
                    </div>
                </div>
                <!-- END: Content -->

                
            </div>
        </div>
 
        <!-- BEGIN: JS Assets-->
        <?php echo $__env->make("$prefix.layout.script", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <!-- END: JS Assets-->

        <script>
            var fullUrl = window.location.origin + window.location.pathname;
    
        </script>
    </body>
</html><?php /**PATH C:\laragon\www\orange\pipat-template\resources\views/back-end/pages/template/index/index.blade.php ENDPATH**/ ?>