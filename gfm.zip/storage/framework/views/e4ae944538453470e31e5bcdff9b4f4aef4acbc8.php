<div class="container pd-15">
    <div class="header">
        <div class="logo-navbar"><a href="<?php echo e(url("home")); ?>">CU-CAT</a></div>

        <button class="hamburger">
            <div class="bar"></div>
        </button>
    </div>

    <?php 
    $customer = \App\Models\Backend\CustomerModel::find(Auth::guard('user')->id());
    ?>

    <nav class="mobile-nav">
        <a href="javascript:void(0)">
            <div class="box-profile">
                <img src="<?php echo e(@$customer->image); ?>" class="img-fluid img-profile" alt="">

                <div class="box-detail">
                    <h4 class="name-profile"><?php echo e(@$customer->fullname()); ?></h4>
                    <p class="id-profile">ID:<?php echo e(@$customer->id); ?></p>
                </div>
            </div>
            <hr />
        </a>

        <h3 class="nav-header">Menu</h3>
        <div class="box-menu">
            <div class="row">
                <div class="col-xl-6 col-md-6 col-sm-6 col-6">
                    <a href="<?php echo e(url("present-detail")); ?>" class="menu-item">
                        <div class="box-icon">
                            <img src="frontend/assets/img/menu-icon/icon-health.svg" class="img-fluid" alt="">
                        </div>
                        <span>การรักษาปัจจุบัน</span>
                    </a>
                </div>

                <div class="col-xl-6 col-md-6 col-sm-6 col-6">
                    <a href="<?php echo e(url("history")); ?>" class="menu-item">
                        <div class="box-icon">
                            <img src="frontend/assets/img/menu-icon/icon-history.svg" class="img-fluid" alt="">
                        </div>
                        <span>ประวัติการรักษา</span>
                    </a>
                </div>

                <div class="col-xl-6 col-md-6 col-sm-6 col-6">
                    <a href="<?php echo e(url("profile-setting")); ?>" class="menu-item">
                        <div class="box-icon">
                            <img src="frontend/assets/img/menu-icon/icon-note.svg" class="img-fluid" alt="">
                        </div>
                        <span>แก้ไขข้อมูล</span>
                    </a>
                </div>
                <div class="col-xl-6 col-md-6 col-sm-6 col-6">
                    <a href="<?php echo e(url("home")); ?>" class="menu-item">
                        <div class="box-icon">
                            <img src="frontend/assets/img/menu-icon/icon-home.svg" class="img-fluid" alt="">
                        </div>
                        <span>แดชบอร์ด</span>
                    </a>
                </div>
            </div>
        </div>


        <div class="box-logout">
            <a href="<?php echo e(url("logout")); ?>" class="btn-custom btn-grays-outline">ออกจากระบบ</a>
        </div>
    </nav>
</div>
<?php /**PATH C:\laragon\www\cretive\cu-cat.com\resources\views/front-end/layout/header.blade.php ENDPATH**/ ?>