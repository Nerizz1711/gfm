<!doctype html>
<html lang="en">

<head>

    <?php echo $__env->make("front-end.layout.stylesheet", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</head>

<body data-sidebar="dark">

    <!-- Script Zone -->
    <?php echo $__env->make("front-end.layout.javascript", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <script>
        const url = '<?php echo e(@$url); ?>';
        $(function() {
            Swal.fire({
                title: "<?php echo e(@$title); ?>",
                text: "<?php echo e(@$text); ?>",
                html: "<?php echo e(@$html); ?>",
                icon: "<?php echo e(@$icon); ?>",
                allowOutsideClick: false,
            }).then((result) => {
                if (url == '') {
                    window.location = window.location.href;
                } else {
                    window.location = url
                }
            });
        })
    </script>

</body>

</html><?php /**PATH C:\laragon\www\cretive\cu-cat.com\resources\views/front-end/alert/alert.blade.php ENDPATH**/ ?>