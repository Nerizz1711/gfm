<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>CU-CAT</title>

    <?php echo $__env->make("$prefix.layout.stylesheet", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</head>

<body>

    <section id="content">
        <div class="history">
            <div class="mobile-size">
                <!-- Header -->
                <?php echo $__env->make("$prefix.layout.header", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <!-- End Header -->

                <div class="row">
                    <div class="col-12">
                        <div class="box-heading">
                            <p class="name-heading">ประวัติการรักษา</p>
                        </div>
                        <div>
                            <div class="row">
                                <div class="col-12">
                                    <div class="box-resultgraph">
                                        <h5>พบหมอครั้งที่ <?php echo e(@$time->sort); ?></h5>

                                        <div id="chart"></div>

                                    </div>
                                </div>
                            </div>

                            <!-- History Box -->
                            <div class="box-history">
                                <h5>ประวัติการรักษาล่าสุด</h5>
                                <?php if($historys): ?>
                                    <?php $__currentLoopData = $historys; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div class="box-itemhistory">
                                            <a href="<?php echo e(url("history-detail?question=$item->question_head_id&time=$item->id")); ?>">
                                                <div class="row">
                                                    <div class="col-2">
                                                        <div class="box-circle">
                                                            <img src="assets/img/menu-icon/icon-note-gra.svg"
                                                                class="img-fluid" alt="">
                                                        </div>
                                                    </div>
                                                    <div class="col-10">
                                                        <p class="title-history">พบหมอครั้งที่ <?php echo $key + 1; ?>
                                                        </p>
                                                        <p class="date-history">
                                                            <?php echo e(\Helper::convertThaiDate($item['datetime_service'])); ?></p>
                                                    </div>
                                                </div>
                                            </a>
                                        </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endif; ?>

                            </div>
                            <!-- End History Box -->
                        </div>
                    </div>
                </div>
                <!-- Footer -->
                <?php echo $__env->make("$prefix.layout.footer", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <!-- End Footer -->
            </div>
        </div>
    </section>

    <?php echo $__env->make("$prefix.layout.javascript", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <?php 
    echo "<script>";
        echo "var data_graph = $graph_data;";
        echo "var data_title = $graph_title;";
        echo "var data_date = $graph_date;";
        echo "var data_url = $graph_url;";
    echo "</script>";
    ?>
    <script>
        const url = "../demo/history-detail.php"
        var options = {
            series: [{
                // data: [40, 80, 33, 50],
                // title: ['ครั้งที่ 1', 'ครั้งที่ 2', 'ครั้งที่ 3', 'ครั้งที่ 4'],
                // date: ["27/03/2566", "27/03/2566", "27/03/2566", "27/03/2566", "27/03/2566"],

                data: data_graph,
                title: data_title,
                date: data_date,
                link: data_url
            }, ],
            chart: {
                width: '100%',
                height: 350,
                type: 'line',
                dropShadow: {
                    enabled: true,
                    color: '#000',
                    top: 18,
                    left: 7,
                    blur: 10,
                    opacity: 0.2
                },
                toolbar: {
                    show: false
                },
                events: {
                    markerClick: function(a, b, c) {
                        window.location.href = (c.w.globals.initialSeries[c.seriesIndex].link[c.dataPointIndex])
                    }
                },
            },
            colors: ['#ff6900', '#ff6900'],
            dataLabels: {
                enabled: true,
            },
            stroke: {
                curve: 'straight',
                width: 2,
            },

            grid: {
                borderColor: '#eee',
                row: {
                    colors: ['transparent', 'transparent'],
                    opacity: 0.5
                },
                padding: {
                    top: 0,
                    right: 25,
                    bottom: 0,
                    left: 25
                },
            },
            xaxis: {
                categories: ['ครั้งที่ 1', 'ครั้งที่ 2', 'ครั้งที่ 3', 'ครั้งที่ 4'],
                labels: {
                    rotate: 0,
                    style: {
                        colors: ['#888888', '#888888', '#888888', '#888888'],
                        fontFamily: 'IBM Plex Sans Thai, sans-serif',
                    }
                },
            },
            yaxis: {
                min: 0,
                max: 100,
                labels: {
                    style: {
                        fontFamily: 'IBM Plex Sans Thai, sans-serif',
                        colors: ['#888888', '#888888', '#888888', '#888888'],
                    },
                }
            },
            dataLabels: {
                enabled: false,
            },
            legend: {
                show: false
            },
            markers: {
                size: 6,
                colors: '#fff',
                strokeColors: '#ff6900',
                strokeWidth: 5,
                hover: {
                    size: undefined,
                    sizeOffset: 3
                }
            },
            tooltip: {
                style: {
                    fontSize: '12px',
                    fontFamily: 'IBM Plex Sans Thai, sans-serif',
                },
                custom: function({
                    series,
                    seriesIndex,
                    dataPointIndex,
                    w
                }) {
                    return (
                        '<span class="tool">' +
                        '<span class="text-time">' + w.globals.initialSeries[seriesIndex].title[
                            dataPointIndex] + '</span><br />' +
                        '<span class="text-date">' + w.globals.initialSeries[seriesIndex].date[dataPointIndex] +
                        '</span><br / > ' +
                        '<a href="javascript:void(0)" class="btn-view">ดูรายละเอียด</a>' +
                        "</span>"
                    );
                }
            }
        };

        var chart = new ApexCharts(document.querySelector("#chart"), options);
        chart.render();
    </script>

</body>

</html>
<?php /**PATH C:\laragon\www\cretive\cu-cat.com\resources\views/front-end/history.blade.php ENDPATH**/ ?>