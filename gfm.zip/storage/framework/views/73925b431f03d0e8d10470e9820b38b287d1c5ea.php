<!DOCTYPE html>
<html lang="en">

<head>
    <base href="<?php echo e(url('/th')); ?>" />
    <title>CRETIVE - BACKEND</title>
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>" />
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <link rel="canonical" href="https://preview.keenthemes.com/metronic8" />
    <link rel="shortcut icon" href="assets/media/logos/favicon.ico" />
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Inter:300,400,500,600,700" />
    <link href="<?php echo e(asset('assets/plugins/global/plugins.bundle.css')); ?>" rel="stylesheet" type="text/css" />
    <link href="<?php echo e(asset('assets/css/style.bundle.css')); ?>" rel="stylesheet" type="text/css" />
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('cusmike/toastr/toastr.min.css')); ?>">
</head>

<body id="kt_body" class="app-blank bgi-size-cover bgi-position-center bgi-no-repeat">
    <script>
        var defaultThemeMode = "light";
        var themeMode;
        if (document.documentElement) {
            if (document.documentElement.hasAttribute("data-bs-theme-mode")) {
                themeMode = document.documentElement.getAttribute("data-bs-theme-mode");
            } else {
                if (localStorage.getItem("data-bs-theme") !== null) {
                    themeMode = localStorage.getItem("data-bs-theme");
                } else {
                    themeMode = defaultThemeMode;
                }
            }
            if (themeMode === "system") {
                themeMode = window.matchMedia("(prefers-color-scheme: dark)").matches ? "dark" : "light";
            }
            document.documentElement.setAttribute("data-bs-theme", themeMode);
        }
    </script>
    <div class="d-flex flex-column flex-root" id="kt_app_root">
        <style>
            body {
                background-image: url('assets/media/auth/bg4.jpg');
            }

            [data-bs-theme="dark"] body {
                background-image: url('assets/media/auth/bg4-dark.jpg');
            }
        </style>
        <div class="d-flex flex-column flex-column-fluid flex-lg-row">

            <div class="d-flex flex-center w-lg-50 pt-15 pt-lg-0 px-10">
                <div class="d-flex flex-center flex-lg-start flex-column">
                    
                    <h2 class="text-white fw-normal m-0">Cu-cat.com</h2>
                </div>
            </div>
            <div class="d-flex flex-center w-lg-50 p-10">
                <div class="card rounded-3 w-md-550px">
                    <div class="card-body d-flex flex-column p-10 p-lg-20 pb-lg-10">
                        <div class="d-flex flex-center flex-column-fluid pb-15 pb-lg-20">
                            <form id="frm_cus" class="form w-100" action="" method="post" onsubmit="return login_submit();">
                                <div class="text-center mb-11">
                                    <h1 class="text-dark fw-bolder mb-3">Sign In</h1>
                                </div>
                                <div class="fv-row mb-8">
                                    <input type="text" placeholder="Username & Email" id="username" name="username" autocomplete="off"class="form-control bg-transparent" />
                                </div>
                                <div class="fv-row mb-3">
                                    <input type="password" placeholder="Password" id="password" name="password" autocomplete="off" class="form-control bg-transparent" />
                                </div>
                                <div class="d-flex flex-stack flex-wrap gap-3 fs-base fw-semibold mb-8">
                                    <div></div>
                                    
                                </div>
                                <div class="d-grid mb-10">
                                    <button type="button" onclick="login_submit();" id="kt_sign_in_submit" class="btn btn-primary">
                                        <span class="indicator-label">Sign In</span>
                                        <span class="indicator-progress">Please wait...
                                            <span
                                                class="spinner-border spinner-border-sm align-middle ms-2"></span></span>
                                    </button>
                                </div>
                                
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <script src="<?php echo e(asset('assets/plugins/global/plugins.bundle.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/scripts.bundle.js')); ?>"></script>
    
    <script src="<?php echo e(asset('cusmike/toastr/toastr.js')); ?>"></script>

    <script>
        var fullUrl = window.location.origin + window.location.pathname;

        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            }
        });
        function contact() {
            // alert(1)
            toastr.error("The system is not activated yet.");
            return false;
        }

        function login_submit() {
            var formData = new FormData($("#frm_cus")[0]);
            var username = $('#username').val();
            var password = $('#password').val();
            if(username == "" || password == ""){
                toastr.error("Sorry, please complete the information.");
                return false;
            }
            
            $.ajax({
                type: 'POST',
                url: fullUrl,
                data: formData,
                processData: false,
                contentType: false,
                dataType: 'json',
                success: function(data) {
                    console.log(data);
                    if(data.result == "success"){
                       location.reload();
                    }else{
                        Swal.fire({
                            title: "" + data.title,
                            text: "" + data.text,
                            icon: 'error',
                            showCancelButton: false,
                            confirmButtonColor: '#3085d6',
                            cancelButtonColor: '#d33',
                            confirmButtonText: 'Close',
                        });
                    }
                }
            });
        }
    </script>
</body>

</html>
<?php /**PATH C:\laragon\www\cretive\cu-cat.com\resources\views/back-end/auth/login.blade.php ENDPATH**/ ?>