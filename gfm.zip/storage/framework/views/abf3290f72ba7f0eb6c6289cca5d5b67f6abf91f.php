<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>CU-CAT</title>

    <?php echo $__env->make("$prefix.layout.stylesheet", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</head>

<body>
    <section id="content">
        <div class="home">
            <div class="mobile-size">
                <!-- Header -->
                <?php echo $__env->make("$prefix.layout.header", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <!-- End Header -->

                <div class="row">
                    <div class="col-xl-12">
                        <div class="box-profilepage">
                            <div class="box-image">
                                <img src="<?php echo e(@$customer->image); ?>" class="img-fluid" alt="">
                            </div>

                            <p class="name-profile"><?php echo e(@$customer->fullname()); ?></p>
                        </div>
                        <div>
                            <!-- Box Detail Profile -->
                            <div class="box-detail-profile">
                                <h5>รายละเอียดการรักษา</h5>
                                <?php 
                                $drug = "-";
                                $doctor = "-";
                                $note = "-";
                                if(@$history != null){
                                    $drug = @$history->drug->name;
                                    $doctor = @$history->doctor->name;
                                    $note = @$history->note;
                                }
                                ?>
                                <div class="item-detail">
                                    <div class="row">
                                        <div class="col-xl-6 col-lg-6 col-md-6 col-sm-6 col-6">
                                            <p class="detail-left">
                                                <img src="frontend/assets/img/menu-icon/icon-pill.svg" class="img-fluid"
                                                    alt=""> กลุ่มการรักษา:
                                            </p>
                                        </div>
                                        <div class="col-xl-6 col-lg-6 col-md-6 col-sm-6 col-6">
                                            <p class="detail-right"><?php echo e(@$drug); ?></p>
                                        </div>
                                    </div>
                                </div>

                                <div class="item-detail">
                                    <div class="row">
                                        <div class="col-xl-6 col-lg-6 col-md-6 col-sm-6 col-6">
                                            <p class="detail-left">
                                                <img src="frontend/assets/img/menu-icon/icon-doctor.svg"
                                                    class="img-fluid" alt=""> แพทย์ผู้รักษา:
                                            </p>
                                        </div>
                                        <div class="col-xl-6 col-lg-6 col-md-6 col-sm-6 col-6">
                                            <p class="detail-right"><?php echo e(@$doctor); ?></p>
                                        </div>
                                    </div>
                                </div>

                                <div class="item-detail">
                                    <div class="row">
                                        <div class="col-xl-6 col-lg-6 col-md-6 col-sm-6 col-6">
                                            <p class="detail-left">
                                                <img src="frontend/assets/img/menu-icon/menu-doc.svg" class="img-fluid"
                                                    alt=""> อื่นๆเพิ่มเติม:
                                            </p>
                                        </div>
                                        <div class="col-xl-6 col-lg-6 col-md-6 col-sm-6 col-6">
                                            <p class="detail-right"><?php echo e(@$note); ?></p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <!-- End Detail -->
                            <!-- Box Graph -->
                            <div class="box-graph">
                                <div class="row">
                                    <div class="col-4">
                                        <h4>Dashboard</h4>
                                    </div>
                                    <div class="col-8">
                                        <div class="box-flexstar">
                                            <?php for ($i = 1; $i <= 10; $i++) { ?>
                                            <div class="star <?php if ($i <= 5) {
                                                echo 'active-star';
                                            } ?>">
                                                <i class="fa-solid fa-star"></i>
                                            </div>
                                            <?php } ?>
                                        </div>
                                    </div>

                                    <?php if(@$curse['status'] == 200 && @$curse['time']): ?>
                                    <div class="col-12">
                                        <div class="box-resultgraph">
                                            <h5>การรักษาครั้งที่ <?php echo e(@$curse['time']); ?></h5>
                                            <div id="chart"></div>
                                            <div class="row">
                                                <div class="col-md-12 text-center">
                                                    <?php if(@$curse['question_time']->performance1_point != null && @$curse['question_time']->performance2_point != null && @$curse['question_time']->performance3_point != null): ?>
                                                        <p class="result-item"><b class="text-danger">ผลการประเมินการรักษา : <?php echo e(@$curse['result_point']); ?> %</b> <span>(<?php echo e(date('d/m/Y',strtotime('+543 Years',strtotime($history->datetime_service)))); ?>)</span></p>
                                                    <?php else: ?>
                                                        <p class="result-item">
                                                            <b class="text-danger">ผลการประเมินการรักษาแบบไม่ทางการ : <?php echo e(@$curse['result_point']); ?> %</b>
                                                            <br/><small>(รอการให้คะแนนสมรรถภาพทางร่างกาย)</small>
                                                            <br/><span>(<?php echo e(date('d/m/Y',strtotime('+543 Years',strtotime(@$history->datetime_service)))); ?>)</span>
                                                        </p>
                                                    <?php endif; ?>
                                               
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <?php else: ?>
                                    <div class="col-12">
                                        <div class="box-resultgraph">
                                            <h5>ยังไม่มีการรักษา</h5>
                                            <div id="chart"></div>
                                        </div>
                                    </div>
                                    <?php endif; ?>
                                </div>
                            </div>
                            <!-- End Box Graph -->
                        </div>
                    </div>
                </div>

                <!-- Footer -->
                <?php echo $__env->make("$prefix.layout.footer", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <!-- End Footer -->
            </div>
        </div>
    </section>

    <?php echo $__env->make("$prefix.layout.javascript", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <script>
        var options = {
            series: [<?php echo e(@$curse['result_point']); ?>, <?php echo e(@$curse['fullpoint']); ?>],
            colors: ['#FF6900', '#EAEAEA'],
            chart: {
                width: '100%',
                type: 'pie',

            },
            dataLabels: {
                enabled: true,
                textAnchor: 'middle',
                style: {
                    fontSize: "28px",
                    fontFamily: 'IBM Plex Sans Thai, sans-serif',
                    colors: ['#fff', 'transparent'],
                },
                formatter: function(val, opts) {
                    return val + '%'
                },
            },
            legend: {
                show: false
            },
            tooltip: {
                enabled: false
            },

            plotOptions: {
                pie: {
                    dataLabels: {
                        offset: -50,
                    },
                }
            },
        };

        var chart = new ApexCharts(document.querySelector("#chart"), options);
        chart.render();
    </script>
</body>

</html>
<?php /**PATH C:\laragon\www\cretive\cu-cat.com\resources\views/front-end/home.blade.php ENDPATH**/ ?>