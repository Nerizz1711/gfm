<meta charset="utf-8">
<base href="<?php echo e(url('/th')); ?>">
<meta name="csrf-token" content="<?php echo e(csrf_token()); ?>" />
<link href="<?php echo e(asset('backend/dist/images/logo.svg')); ?>" rel="shortcut icon">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="description" content="ORANGE TECHNOLOGY">
<meta name="keywords" content="ORANGE TECHNOLOGY">
<title>ORANGE TEMPLATE V.2 ICEWALL</title>
<!-- BEGIN: CSS Assets-->
<link rel="stylesheet" href="<?php echo e(asset('backend/dist/css/app.css')); ?>" />
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('backend/libs/toastr/toastr.min.css')); ?>">
<!-- END: CSS Assets-->
<!-- Sweet Alert-->
<link href="<?php echo e(asset('backend/libs/sweetalert2/sweetalert2.min.css')); ?>" rel="stylesheet" type="text/css" />
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('backend/libs/fontawesome/icons.min.css')); ?>">

<style>
    .swal2-container {
  z-index: 99999 !important;
}
</style><?php /**PATH C:\laragon\www\orange\pipat-template\resources\views/back-end/layout/header.blade.php ENDPATH**/ ?>