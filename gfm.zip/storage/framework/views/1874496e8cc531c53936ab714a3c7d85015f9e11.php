<link rel="stylesheet" href="frontend/assets/css/style.css">
<link rel="stylesheet" href="frontend/assets/css/bootstrap.css">
<link rel="stylesheet" href="frontend/assets/css/all.min.css">
<link rel="stylesheet" href="frontend/assets/css/icofont.css">
<link rel="stylesheet" href="frontend/assets/libs/apexcharts/apexcharts.css">
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('cusmike/sweetalert.css')); ?>">
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('cusmike/toastr/toastr.min.css')); ?>">
<?php /**PATH C:\laragon\www\cretive\cu-cat.com\resources\views/front-end/layout/stylesheet.blade.php ENDPATH**/ ?>