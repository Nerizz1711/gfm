<!-- Modal Zone -->
<div class="modal fade" id="modal_01" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered modal-lg">
        <div class="modal-content rounded">
        </div>
    </div>
</div>

<script>
    var hostUrl = "assets/";
</script>
<script src="<?php echo e(asset('backend/assets/plugins/global/plugins.bundle.js')); ?>"></script>
<script src="<?php echo e(asset('backend/assets/js/scripts.bundle.js')); ?>"></script>
<script src="<?php echo e(asset('backend/assets/plugins/custom/datatables/datatables.bundle.js')); ?>"></script>
<?php /**PATH C:\laragon\www\gfm\resources\views/front-end/layout/script.blade.php ENDPATH**/ ?>