   <div class="modal-content">
       <div class="modal-body">

           <div class="grid grid-cols-1 gap-6 mt-8 text-center">
               <b>VIEW LOG DETAIL</b>
           </div>

           <div class="grid grid-cols-1 gap-6 mt-3">
               <div class="col-span-12 lg:col-span-3 2xl:col-span-2">
                   <div class="intro-y border border-gray-300 border-dashed rounded p-5">
                       <div class="col-span-12 lg:col-span-1 2xl:col-span-1 mt-3">
                           <div class="form-inline">
                               <b for="horizontal-form-1" class="form-label sm:w-20">CODE</b>
                               <b for="horizontal-form-1" class="form-label text-red-500"><?php echo e(@$data->id); ?></b>
                           </div>
                       </div>

                       <div class="col-span-12 lg:col-span-1 2xl:col-span-1 mt-3">
                           <div class="form-inline">
                               <b for="horizontal-form-1" class="form-label sm:w-20">Date</b>
                               <b for="horizontal-form-1"
                                   class="form-label text-red-500"><?php echo e(date('Y-m-d', strtotime(@$data->date))); ?></b>
                           </div>
                       </div>

                       <div class="col-span-12 lg:col-span-1 2xl:col-span-1 mt-3">
                           <div class="form-inline">
                               <b for="horizontal-form-1" class="form-label sm:w-20">Time</b>
                               <b for="horizontal-form-1"
                                   class="form-label  text-red-500"><?php echo e(date('H:i น.', strtotime(@$data->date))); ?></b>
                           </div>
                       </div>

                       <div class="col-span-12 lg:col-span-1 2xl:col-span-1 mt-3">
                           <div class="form-inline">
                               <b for="horizontal-form-1" class="form-label sm:w-20">Level</b>
                               <b for="horizontal-form-1" class="form-label  text-red-500"> <?php echo Helper::typeLogs($data->level); ?></b>
                           </div>
                       </div>

                       <div class="col-span-12 lg:col-span-1 2xl:col-span-1 mt-3">
                           <div class="form-inline">
                               <b for="horizontal-form-1" class="form-label sm:w-20">Type</b>
                               <b for="horizontal-form-1" class="form-label  text-red-500"><?php echo Helper::typeLogsSystem(@$data->type); ?></b>
                           </div>
                       </div>

                       <div class="col-span-12 lg:col-span-1 2xl:col-span-1 mt-3">
                           <div class="form-inline">
                               <b for="horizontal-form-1" class="form-label sm:w-20">Env</b>
                               <b for="horizontal-form-1" class="form-label text-red-500"><?php echo e(@$data->env); ?></b>
                           </div>
                       </div>

                   </div>

               </div>
           </div>

           <div class="grid grid-cols-1 gap-6 mt-3">
               <div class="col-span-12 lg:col-span-3 2xl:col-span-2">
                   <div class="intro-y border border-gray-300 border-dashed rounded p-5">

                       <div class="col-span-12 lg:col-span-3 2xl:col-span-2 mt-3">
                           <div class="form-inline">
                               <b for="horizontal-form-1" class="form-label sm:w-20">Description</b>
                           </div>
                       </div>

                       <div class="col-span-12 lg:col-span-1 2xl:col-span-1 mt-3">
                           <div class="form-inline">
                               <b for="horizontal-form-1" class="form-label sm:w-20">Line :</b>
                               <b for="horizontal-form-1" class="form-label text-red-500"><?php echo e(@$data->line); ?></b>
                           </div>
                       </div>

                       <div class="col-span-12 lg:col-span-1 2xl:col-span-1 mt-3">
                           <div class="form-inline">
                               <b for="horizontal-form-1" class="form-label sm:w-20">Url :</b>
                               <b for="horizontal-form-1" class="form-label text-red-500"><?php echo e(@$data->url); ?></b>
                           </div>
                       </div>

                       <div class="col-span-12 lg:col-span-1 2xl:col-span-1 mt-3">
                           <div class="form-inline">
                               <b for="horizontal-form-1" class="form-label sm:w-20">Description :</b>
                               <b for="horizontal-form-1" class="text-left text-red-500"><?php echo e(@$data->desc); ?></b>
                           </div>
                       </div>


                   </div>

               </div>
           </div>

           <div class="grid grid-cols-1 gap-6 mt-3 text-center">
               <div class="col-span-12 lg:col-span-3 2xl:col-span-2">
                    <div class="col-span-12 lg:col-span-3 2xl:col-span-2 mt-3">
                        <button type="button" data-tw-dismiss="modal" class="btn btn-danger w-20 mr-1">ปิด</button>
                </div>
               </div>
           </div>
       </div>


   </div>
<?php /**PATH C:\laragon\www\orange\pipat-template\resources\views/back-end/pages/log/show-log.blade.php ENDPATH**/ ?>