<!DOCTYPE html>
<html lang="en" class="light">
    <!-- BEGIN: Head -->
    <head>
        <?php echo $__env->make("$prefix.layout.header", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </head>
    <!-- END: Head -->
    <body class="main">
        
        <!-- BEGIN: MENU -->
        <?php echo $__env->make("$prefix.layout.menu-top", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <!-- END: Menu -->

       
        <div class="wrapper">
            <div class="wrapper-box">
                <!-- BEGIN: Side Menu -->
                <?php echo $__env->make("$prefix.layout.menu-slide", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <!-- END: Side Menu -->

                <!-- BEGIN: Content -->
                <div class="content">

                   <!-- BEGIN: Content -->
                    <div class="intro-y flex flex-col sm:flex-row items-center mt-8">
                        <h2 class="text-lg font-medium mr-auto">
                            ฟอร์มข้อมูล
                        </h2>
                    </div>
        
                    <form id="menuForm" method="post" action="" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                        <div class="grid grid-cols-12 gap-6 mt-5">
                            <div class="intro-y col-span-12 lg:col-span-6">
                                <!-- BEGIN: Form Layout -->
                                <div class="intro-y box p-5">

                                    <div class="grid grid-cols-12 gap-6 mt-5 mb-3">
                                        <div class="col-span-6 lg:col-span-6">
                                            <img id="example_image01" class="mb-2" src="<?php if($row->image): ?><?php echo e($row->image); ?><?php else: ?><?php echo e('no-img.png'); ?><?php endif; ?>" class="img-fluid" alt="">
                                            <input name="image" id="image" type="file" class="custom-file-input" accept="image/*" onchange="readURL01(this);">
                                        </div>
                                    </div>
    
                                    <div class="grid grid-cols-12 gap-6 mt-5 mb-3">
                                        <div class="col-span-12 lg:col-span-12">
                                            <label for="horizontal-form-1" class="form-label">รูปภาพ <small class="form-help">(อัพโหลดรูปภาพเฉพาะไฟล์ *.png, *.jpg and *.jpeg image เท่านั้น)</small> </label> 
                                        </div>
                                    </div>
                                    
                                    

                                    <div class="grid grid-cols-12 gap-6 mt-5 mb-3">
                                        <div class="col-span-6 lg:col-span-6">
                                            <label for="crud-form-1" class="form-label">ชื่อ <span class="text-danger">*</span></label>
                                            <input class="form-control" id="name" type="text" name="name" value="<?php echo e(@$row->name); ?>" placeholder="กรอกชื่อ-นามสกุล" autocomplete="off">
                                        </div>
                                        <div class="col-span-12 lg:col-span-12">
                                            <label for="crud-form-1" class="form-label">รายละเอียด</label>
                                            <input class="form-control" id="detail" type="text" name="detail" value="<?php echo e(@$row->detail); ?>" placeholder="กรอกรายละเอียด" autocomplete="off">
                                        </div>
                                    </div>

                                     <div class="grid grid-cols-12 gap-6 mt-5 mb-3">
                                        <div class="col-span-6 lg:col-span-6">
                                            <label for="crud-form-1" class="form-label">Province :</label>
                                            <select name="province_id" id="province_id" class="select2 form-select w-full  province" style="width:100%;">
                                                <option value="" disabled selected>กรุณาเลือกข้อมูล</option>
                                                <?php if(@$provinces): ?>
                                                    <?php $__currentLoopData = $provinces; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($p->id); ?>" <?php if(@$row->province_id == $p->id): ?> selected <?php endif; ?>><?php echo e($p->name_th); ?></option>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                <?php endif; ?>
                                            </select>
                                        </div>
                                        <div class="col-span-6 lg:col-span-6">
                                            <label for="crud-form-1" class="form-label">District / Zone :</label>
                                            <select name="amupur_id" id="amupur_id" class="select2 form-select district"  style="width:100%;">
                                                <option value="">กรุณาเลือกข้อมูล</option>
                                                <?php if(@$amupurs): ?>
                                                    <?php $__currentLoopData = $amupurs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $amupur): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($amupur->id); ?>" <?php if(@$row->amupur_id == $amupur->id): ?> selected <?php endif; ?>><?php echo e($amupur->name_th); ?></option>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                <?php endif; ?>
                                            </select>
                                        </div>
                                        <div class="col-span-6 lg:col-span-6">
                                            <label for="crud-form-1" class="form-label">Subdistrict / Area :</label>
                                            <select name="tambon_id" id="tambon_id" class="select2 form-select subdistrict"  style="width:100%;">
                                                <option value="" disabled selected>กรุณาเลือกข้อมูล</option>
                                                <?php if(@$tambons): ?>
                                                    <?php $__currentLoopData = $tambons; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tambon): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($tambon->id); ?>" <?php if(@$row->tambon_id == $tambon->id): ?> selected <?php endif; ?>><?php echo e($tambon->name_th); ?></option>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                <?php endif; ?>
                                            </select>
                                        </div>
                                        <div class="col-span-6 lg:col-span-6">
                                            <label for="crud-form-1" class="form-label">Zipcode :</label>
                                            <input class="form-control" id="zip_code" type="text" name="zip_code" value="<?php echo e(@$row->zip_code); ?>" readonly placeholder="" autocomplete="off">
                                        </div>
                                    </div>

                                </div>
                                <!-- END: Form Layout -->
                            </div>
                        </div>

                        <div class="grid grid-cols-12 gap-6 mt-5">
                            <div class="intro-y col-span-12 lg:col-span-12">
                                <!-- BEGIN: Form Layout -->
                                <div class="">
                                    <b>Gallery</b>
                                </div>
                        
                                <div class="intro-y grid grid-cols-12 gap-3 sm:gap-6 mt-5 sortable-list">
                                <?php if(@$gallerys): ?>
                                    <?php $__currentLoopData = @$gallerys; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $gallery): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div id="gallery_<?php echo e($gallery->id); ?>" class="list-unstyled intro-y col-span-6 sm:col-span-4 md:col-span-3 2xl:col-span-2">
                                        <div class="box rounded-md px-5 pt-8 pb-5 px-3 sm:px-5 relative zoom-in">
                                            <img src="<?php echo e($gallery->image); ?>" data-action="zoom" alt="" style="width:100%; height:170px;">
                                            <div class="mt-2">
                                                <div title="ลบรูปภาพ" class="tooltip w-5 h-5 flex items-center justify-center absolute rounded-full text-white bg-danger right-0 top-0 -mr-2 -mt-2"> 
                                                    <i onclick="gallery_delete('<?php echo e($gallery->id); ?>');" data-lucide="x" class="w-4 h-4"></i> 
                                                </div>
                                                
                                            </div>
        
                                        </div>
                                    </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endif; ?>
                                </div>
                            </div>
                        </div>
                        

                        <div class="grid grid-cols-12 gap-6">
                            <div class="intro-y col-span-12 lg:col-span-6">
                                <!-- BEGIN: Form Layout -->
                                <div class="intro-y p-5">
                                    <div class="grid grid-cols-12 gap-4 gap-y-5">
                                        <div class="intro-y col-span-12 sm:col-span-12">
                                            <label class="form-label" for="size">*อัพโหลดรูปภาพแกลลอรี่ รองรับไฟล์ <strong class="text-danger">(jpg, jpeg, png)</strong> เท่านั้น</label>
                                            <div class="custom-file">
                                                <input type="file" class="custom-file-input" name="gallery_image[]" id="gallery_image" multiple>
                                                <label class="custom-file-label" for="gallery_image">Choose file</label>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <!-- END: Form Layout -->
                            </div>
                        </div>

                        
                        <div class="text-right mt-5">
                            <a class="btn btn-outline-secondary w-24 mr-1" href="<?php echo e(url("$segment/$folder")); ?>">ยกเลิก</a>
                            <button type="button" onclick="check_add();" class="btn btn-primary w-24">บันทึกข้อมูล</button>
                        </div>

                    </form>

                </div>


                
                <!-- END: Content -->

                
            </div>
        </div>
 
        <!-- BEGIN: JS Assets-->
        <?php echo $__env->make("$prefix.layout.script", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <script>
        $("#example_image01").click(function() {
            $("input[id='image']").click();
        });

        function readURL01(input) {
            if (input.files && input.files[0]) {
                var reader = new FileReader();
                reader.onload = function(e) {
                    $('#example_image01').attr('src', e.target.result);
                }
                reader.readAsDataURL(input.files[0]);
            }
        }

        function check_add() {
            var role = $('#role').val();
            var status_check = $('#status_check').val();
            var name = $('#name').val();
            var email = $('#email').val();
            var password = $('#password').val();
            var confirm_password = $('#confirm_password').val();
            var resetpassword = $('#resetpassword').val();

            if (role == "") {
                toastr.error('กรุณาเลือกระดับของผู้ใช้งานนี้');
                return false;
            }
            if (status_check == "") {
                toastr.error('กรุณาเลือกสถานะการใช้งาน');
                return false;
            }
            if (name == "" || email == "") {
                toastr.error('กรุณากรอกข้อมูลให้ครบถ้วนก่อนบันทึกรายการ');
                return false;
            }
            if (password != confirm_password) {
                toastr.error('กรุณากรอกรหัสผ่านให้เหมือนกัน');
                return false;
            }

            Swal.fire({
                icon: 'warning',
                title: 'กรุณากดยืนยันเพื่อทำรายการ',
                showCancelButton: true,
                confirmButtonText: 'ยืนยัน',
                cancelButtonText: `ยกเลิก`,
            }).then((result) => {
                if (result.isConfirmed) {
                    $('#menuForm').submit();
                }
            });
                
        }
        
        function gallery_delete(id){
            Swal.fire({
                icon: 'warning',
                title : 'กรุณายืนยันเพื่อทำรายการ',
                text: 'เมื่อทำการลบข้อมูลแล้วจะไม่สามารถนำมาใช้ได้อีก !',
                showCancelButton: true,
                confirmButtonText: 'ยืนยัน',
                cancelButtonText: `ยกเลิก`,
            }).then((result) => {
                if (result.isConfirmed) {
                    $.ajax({
                        type: "POST",
                        url: 'webpanel/ajax/gallery/delete',
                        data: {
                            id: id,
                            "_token": "<?php echo e(csrf_token()); ?>",
                        },
                        dataType: 'json',
                        success: function(data) {
                            if(data.status == 200){
                                $('#gallery_' + id).remove();
                            }
                        }
                    });
                }
            });
           
        }
       

        $('#province_id').change(function() {
            var province_id = $('#province_id').val();
            $.ajax({
                type: "POST",
                url: 'ajax/getProvince',
                data: {
                    _token: "<?php echo e(csrf_token()); ?>",
                    province_id: province_id,
                },
                success: function(data) {
                    $('#amupur_id').html(data);
                    $('#tambon_id').html('<option value="" selected>- กรุณาเลือกข้อมูล -</option>');
                    $('#zip_code').val(null);
                }
            });
        });

        $('#amupur_id').change(function() {
            var amupur_id = $('#amupur_id').val();
            $.ajax({
                type: "POST",
                url: 'ajax/getAmupur',
                data: {
                    _token: "<?php echo e(csrf_token()); ?>",
                    amupur_id: amupur_id,
                },
                success: function(data) {
                    $('#tambon_id').html(data);
                    $('#zip_code').val(null);
                }
            });
        });

        $('#tambon_id').change(function() {
            var tambon_id = $('#tambon_id').val();
            $.ajax({
                type: "POST",
                url: 'ajax/getTambon',
                data: {
                    _token: "<?php echo e(csrf_token()); ?>",
                    tambon_id: tambon_id,
                },
                dataType: 'json',
                success: function(data) {
                    $('#zip_code').val(data.zip_code);
                }
            });
        });
    
        </script>
        <!-- END: JS Assets-->
    </body>
</html><?php /**PATH C:\laragon\www\orange\pipat-template\resources\views/back-end/pages/template/standard/edit.blade.php ENDPATH**/ ?>