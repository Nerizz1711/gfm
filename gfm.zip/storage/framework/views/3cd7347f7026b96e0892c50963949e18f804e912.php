<!DOCTYPE html>
<html lang="en" class="light">
    <!-- BEGIN: Head -->
    <head>
        <?php echo $__env->make("$prefix.layout.header", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </head>
    <!-- END: Head -->
    <body class="main">
        
        <!-- BEGIN: MENU -->
        <?php echo $__env->make("$prefix.layout.menu-top", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <!-- END: Menu -->

       
        <div class="wrapper">
            <div class="wrapper-box">
                <!-- BEGIN: Side Menu -->
                <?php echo $__env->make("$prefix.layout.menu-slide", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <!-- END: Side Menu -->

                <!-- BEGIN: Content -->
                <div class="content">
                    <div class="intro-y grid grid-cols-12 gap-6 mt-5">
                        <!-- BEGIN: Release -->
                        <div class="intro-y col-span-12 md:col-span-6 xl:col-span-6 box">
                            <div class="flex items-center border-b border-slate-200/60 dark:border-darkmode-400 px-5 py-4">
                                <div class="ml-3 mr-auto">
                                    <a href="" class="font-medium">Release Note.</a> 
                                    <div class="flex text-slate-500 truncate text-xs mt-0.5"> 20/06/2566 </div>
                                </div>
                            </div>
                            <div class="px-5 pt-3 pb-5 border-t border-slate-200/60 dark:border-darkmode-400">
                                <div class="intro-y col-span-12 md:col-span-6 xl:col-span-6 mb-2">
                                </div>
                            </div>
                        </div>

                        <div class="intro-y col-span-12 md:col-span-6 xl:col-span-6 box">
                            <div class="flex items-center border-b border-slate-200/60 dark:border-darkmode-400 px-5 py-4">
                                <div class="ml-3 mr-auto">
                                    <a href="" class="font-medium">Release Note.</a> 
                                    <div class="flex text-slate-500 truncate text-xs mt-0.5"> 19/06/2566 </div>
                                </div>
                            </div>
                            <div class="px-5 pt-3 pb-5 border-t border-slate-200/60 dark:border-darkmode-400">
                                <div class="intro-y col-span-12 md:col-span-6 xl:col-span-6 mb-2">
                                    <b>Template Form Menu</b>
                                    <br>- Standard sub menu  (Datatable, Add, Edit, Delete) 
                                    <br>- Modal sub menu (Datatable, Add, Edit, Delete) 
                                </div>
                                <div class="intro-y col-span-12 md:col-span-6 xl:col-span-6">
                                    <b>Administrator Menu</b>
                                    <br>- User sub menu (Datatable, Add, Edit, Delete) | Auth Middleware Webpanel to login
                                    <br>- Permission sub menu (Datatable, Add, Edit, Delete) | Role
                                </div>
                            </div>
                        </div>
                        <!-- END: Release -->
                    </div>
                </div>
                <!-- END: Content -->

                
            </div>
        </div>
 
        <!-- BEGIN: JS Assets-->
        <?php echo $__env->make("$prefix.layout.script", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <!-- END: JS Assets-->
    </body>
</html><?php /**PATH C:\laragon\www\orange\pipat-template\resources\views/back-end/pages/dashboard/index.blade.php ENDPATH**/ ?>