<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.7.0/jquery.min.js"></script>
<script src="frontend/assets/js/bootstrap.min.js"></script>
<script src="frontend/assets/js/all.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/imask/3.3.0/imask.min.js"></script>
<script src="frontend/assets/js/menu.js"></script>
<script src="frontend/assets/libs/apexcharts/apexcharts.js"></script>
<script src="<?php echo e(asset('cusmike/toastr/toastr.js')); ?>"></script>
<script src="<?php echo e(asset('cusmike/sweetalert2.all.min.js')); ?>"></script><?php /**PATH C:\laragon\www\cretive\cu-cat.com\resources\views/front-end/layout/javascript.blade.php ENDPATH**/ ?>