<!DOCTYPE html>
<html lang="en">
<!--begin::Head-->

<head>
    <?php echo $__env->make("$prefix.layout.head", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

</head>
<!--end::Head-->
<!--begin::Body-->

<body id="kt_app_body" data-kt-app-layout="dark-sidebar" data-kt-app-header-fixed="true" data-kt-app-sidebar-enabled="true"
    data-kt-app-sidebar-fixed="true" data-kt-app-sidebar-hoverable="true" data-kt-app-sidebar-push-header="true"
    data-kt-app-sidebar-push-toolbar="true" data-kt-app-sidebar-push-footer="true" data-kt-app-toolbar-enabled="true"
    class="app-default">


    <div class="d-flex flex-column flex-root app-root" id="kt_app_root">
        <!--begin::Page-->
        <div class="app-page flex-column flex-column-fluid" id="kt_app_page">
            <!--begin::Header-->
            <div id="kt_app_header" class="app-header">
                <!-- MENU -->
                <?php echo $__env->make("$prefix.layout.menu", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <!-- END MENU -->

                <!--begin::Main-->
                <div class="app-main flex-column flex-row-fluid" id="kt_app_main">
                    <!--begin::Content wrapper-->
                    <div class="d-flex flex-column flex-column-fluid">
                        <!--begin::Toolbar-->
                        <div id="kt_app_toolbar" class="app-toolbar py-3 py-lg-6">
                            <!--begin::Toolbar container-->
                            <?php echo $__env->make("$prefix.layout.breadcrumbs", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                            <!--end::Toolbar container-->
                        </div>
                        <!--end::Toolbar-->


                        <!--begin::Content-->
                        <div id="kt_app_content" class="app-content flex-column-fluid">
                            <!--begin::Content container-->
                            <div id="kt_app_content_container" class="app-container container-fluid">


                                <div class="row g-5 g-xl-10 mb-5 mb-xl-10">
                                    <div class="col-md-6 col-lg-6 col-xl-6 col-xxl-3 mb-md-5 mb-xl-10">
                                        <div class="card card-flush bgi-no-repeat bgi-size-contain bgi-position-x-end h-md-50 mb-5 mb-xl-10" style="background-color: #F1416C;background-image:url('assets/media/patterns/vector-1.png')">
                                            <div class="card-header pt-5">
                                                <div class="card-title d-flex flex-column">
                                                    <span class="fs-2hx fw-bold text-white me-2 lh-1 ls-n2">69</span>
                                                    <span class="text-white opacity-75 pt-1 fw-semibold fs-6">Active Projects</span>
                                                </div>
                                            </div>
                                            <div class="card-body d-flex align-items-end pt-0">
                                                <div class="d-flex align-items-center flex-column mt-3 w-100">
                                                    <div class="d-flex justify-content-between fw-bold fs-6 text-white opacity-75 w-100 mt-auto mb-2">
                                                        <span>43 Pending</span>
                                                        <span>72%</span>
                                                    </div>
                                                    <div class="h-8px mx-3 w-100 bg-white bg-opacity-50 rounded">
                                                        <div class="bg-white rounded h-8px" role="progressbar" style="width: 72%;" aria-valuenow="50" aria-valuemin="0" aria-valuemax="100"></div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="card card-flush h-md-50 mb-5 mb-xl-10">
                                            <div class="card-header pt-5">
                                                <div class="card-title d-flex flex-column">
                                                    <span class="fs-2hx fw-bold text-dark me-2 lh-1 ls-n2"><?php echo e(@$customerCount); ?></span>
                                                    <span class="text-gray-400 pt-1 fw-semibold fs-6">ยอดผู้ป่วย</span>
                                                </div>
                                            </div>
                                            <div class="card-body d-flex flex-column justify-content-end pe-0">
                                                <span class="fs-6 fw-bolder text-gray-800 d-block mb-2">ข้อมูลผู้ป่วยล่าสุด</span>
                                                <div class="symbol-group symbol-hover flex-nowrap">
                                                    <?php if(@$customers): ?>
                                                        <?php $__currentLoopData = @$customers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index=>$customer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <a href="<?php echo e(url("$segment/customer/view/$customer->id")); ?>">
                                                            <div class="symbol symbol-35px symbol-circle" data-bs-toggle="tooltip" title="<?php echo e($customer->fullname()); ?>">
                                                                <span class="symbol-label bg-warning text-inverse-warning fw-bold"><?php echo e(Str::substr($customer->fullname(),0,1)); ?></span>
                                                            </div>
                                                        </a>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    <?php endif; ?>
                                                    <a href="<?php echo e(url("$segment/customer")); ?>" class="symbol symbol-35px symbol-circle">
                                                        <span class="symbol-label bg-dark text-gray-300 fs-8 fw-bold">+<?php echo e(@$customerCount); ?></span>
                                                    </a>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                
                            </div>
                        </div>
                        <!--end::Content-->


                    </div>
                </div>
            </div>
        </div>
    </div>
    <!--begin::Javascript-->
    <?php echo $__env->make("$prefix.layout.script", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!--end::Javascript-->
</body>
<!--end::Body-->

</html>
<?php /**PATH C:\laragon\www\cretive\cu-cat.com\resources\views/back-end/pages/dashboard/index.blade.php ENDPATH**/ ?>