<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>CU-CAT</title>
  <?php echo $__env->make("$prefix.layout.stylesheet", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</head>

<body>
  <section id="content">
    <div class="profile">
      <div class="mobile-size">
        <!-- Header -->
        <?php echo $__env->make("$prefix.layout.header", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <!-- End Header -->

        <div class="row">
          <div class="col-xl-12">
            <div class="box-heading">
              <p class="name-heading">แก้ไขข้อมูล</p>
            </div>
            <div class="container-center">
              <!-- Form Edit Profile -->
              <form id="menuForm" method="post" action="" onsubmit="return check_add();" >
                <?php echo csrf_field(); ?>
                <div class="mb-3">
                  <label for="firstname" class="form-label"><span class="text-danger">*</span> ชื่อ</label>
                  <input type="text" name="firstname" class="form-control" id="firstname" placeholder="กรอกชื่อ" value="<?php echo e($customer->firstname); ?>">
                </div>

                <div class="mb-3">
                  <label for="lastname" class="form-label"><span class="text-danger">*</span> นามสกุล</label>
                  <input type="text" name="lastname" class="form-control" id="lastname" placeholder="กรอกนามสกุล" value="<?php echo e($customer->lastname); ?>">
                </div>

                <div class="mb-3">
                  <label for="idcard" class="form-label">เลขบัตรประชาชน </label>
                  <input type="text" name="idcard" class="form-control" id="idcard" placeholder="เลขบัตรประชาชน" value="<?php echo e($customer->idcard); ?>" disabled>
                </div>

                <div class="mb-3">
                  <label for="sex" class="form-label">เพศ</label>

                  <div>
                    <input type="radio" class="btn-check" name="sex" value="ชาย" id="gendertype1" autocomplete="off" <?php if($customer->sex == "ชาย"): ?> checked <?php endif; ?>>
                    <label class="btn btn-outline-primary" for="gendertype1"><i class="fa-solid fa-mars"></i> ชาย</label>

                    <input type="radio" class="btn-check" name="sex" value="หญิง" id="gendertype2" autocomplete="off" <?php if($customer->sex == "หญิง"): ?> checked <?php endif; ?>>
                    <label class="btn btn-outline-primary" for="gendertype2"><i class="fa-solid fa-venus"></i> หญิง </label>
                  </div>
                </div>

                <div class="mb-3">
                  <label for="birthdate" class="form-label"><span class="text-danger">*</span>  วันเกิด</label>
                  <input type="date" name="birthdate" class="form-control" id="birthdate" placeholder="วว/ดด/ปปปป" value="<?php echo e($customer->birthdate); ?>">
                </div>

                <div class="mb-3">
                  <label for="age" class="form-label">อายุ</label>
                  <span id="show_age"><?php echo e($customer->age); ?></span> ปี
                  <input type="hidden" id="age" name="age" class="form-control" placeholder="" readonly value="<?php echo e($customer->age); ?>" />
                </div>
                <button class="btn-custom btn-orange">บันทึก</button>
              </form>
              <!-- End Form Edit Profile -->
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>

  <?php echo $__env->make("$prefix.layout.javascript", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

  <script>
  $('#birthdate').change(function(){
      var birthdate = new Date(document.getElementById('birthdate').value);
      var today = new Date();
      var age = Math.floor((today-birthdate)/(365.25*24*60*60*1000));
      $('#age').val(age);
      $('#show_age').html(age);
  });
  function check_add() {
      var firstname = $('#firstname').val();

      if (firstname == "") {
          Swal.fire({
              icon: 'error',
              title: "เกิดข้อผิดพลาด",
              text: "กรุณากรอกข้อมูลที่มี * ให้ครบถ้วน",
              showCancelButton: false,
              confirmButtonText: 'ปิด',
          });
          return false;
      }
  }
  </script>
</body>

</html><?php /**PATH C:\laragon\www\cretive\cu-cat.com\resources\views/front-end/profile-setting.blade.php ENDPATH**/ ?>