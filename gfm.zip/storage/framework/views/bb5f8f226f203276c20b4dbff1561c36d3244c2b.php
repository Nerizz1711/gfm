<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>CU-CAT</title>

    <?php echo $__env->make("$prefix.layout.stylesheet", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</head>

<body>
    <section id="content">
        <div class="container-center success">
            <div class="mobile-size">
                <div class="row">
                    <div class="col-xl-12">
                        <div class="box-index">
                            <div class="box-banner">
                                <img src="frontend/assets/img/success.png" class="img-fluid" alt="">
                            </div>
                            <h3 class="title-sucess">คุณทำแบบสอบถามสำเร็จแล้ว</h3>
                            <p class="sub-success">กรุณาติดต่อเจ้าหน้าที่เพื่อทำแบบทดสอบสมรรถณะของข้อเข่าต่อไป</p>

                            <div class="box-button">
                                <a href="<?php echo e(url("home")); ?>" class="btn-custom btn-grays-outline">กลับสู่หน้าหลัก</a>
                                <a href="<?php echo e(url("performance")); ?>" class="btn-custom btn-orange-outline">แบบทดสอบสมรรถณะ</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <?php echo $__env->make("$prefix.layout.javascript", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</body>

</html>
<?php /**PATH C:\laragon\www\cretive\cu-cat.com\resources\views/front-end/success.blade.php ENDPATH**/ ?>