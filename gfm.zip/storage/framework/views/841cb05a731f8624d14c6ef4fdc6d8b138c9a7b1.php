<div class="modal-header">
    <h2>สร้าง รอบการรักษา</h2>
    <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
        <span class="svg-icon svg-icon-1">
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="currentColor" />
                <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="currentColor" />
            </svg>
        </span>
    </div>
</div>

<div class="modal-body py-lg-10 px-lg-10">
    <form id="form_submit" method="POST" enctype="multipart/form-data">
    <?php echo csrf_field(); ?>
        
        <div class="row mb-2">
            <label class="col-md-3 col-form-label">
                <img src="frontend/assets/img/menu-icon/icon-doctor.svg" class="img-fluid" alt=""> แพทย์ผู้รักษา
            </label>
            <div class="col-md-9">
                <select id="modal_doctor_id" name="modal_doctor_id" class="form-select">
                    <option value="">กรุณาเลือกแพทย์ที่รักษา</option>
                    <?php if(@$doctors): ?>
                        <?php $__currentLoopData = @$doctors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $doctor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e(@$doctor->id); ?>"><?php echo e(@$doctor->name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                </select>
            </div>
        </div>

        <div class="row mb-2">
            <label class="col-md-3 col-form-label">
                <img src="frontend/assets/img/menu-icon/icon-pill.svg" class="img-fluid" alt=""> ยาที่รักษา
            </label>
            <div class="col-md-9">
                <select id="modal_drug_id" name="modal_drug_id" class="form-select">
                    <option value="">กรุณาเลือกกลุ่มยาที่รักษา</option>
                    <?php if(@$drugs): ?>
                        <?php $__currentLoopData = @$drugs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $drug): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e(@$drug->id); ?>"><?php echo e(@$drug->name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                </select>
            </div>
        </div>
        <div class="row mb-2">
            <label class="col-md-3 col-form-label">
                <img src="frontend/assets/img/menu-icon/menu-doc.svg" class="img-fluid" alt=""> อื่นๆเพิ่มเติม
            </label>
            <div class="col-md-9">
                <input type="text" id="modal_note" name="modal_note" class="form-control" placeholder="กรุณาเลือกกลุ่มการรักษา" value="" />
            </div>
        </div>

        <div class="row mb-2">
            <label class="col-md-3 col-form-label">
                <img src="frontend/assets/img/menu-icon/menu-doc.svg" class="img-fluid" alt=""> วันที่นัดหมาย
            </label>
            <div class="col-md-9">
                <input type="date" class="form-control" id="modal_datetime_service_date" name="modal_datetime_service_date" value="<?php echo e(date('Y-m-d')); ?>">
            </div>
        </div>

        <div class="row mb-2">
            <label class="col-md-3 col-form-label">
                <img src="frontend/assets/img/menu-icon/menu-doc.svg" class="img-fluid" alt=""> เวลาที่นัดหมาย
            </label>
            <div class="col-md-9">
                <input type="time" class="form-control" id="modal_datetime_service_time" name="modal_datetime_service_time" value="<?php echo e(date('H:i')); ?>">
            </div>
        </div>

        <div class="row mb-2">
            <label class="col-md-3 col-form-label">
                <img src="frontend/assets/img/menu-icon/menu-doc.svg" class="img-fluid" alt=""> สถานะ
            </label>
            <div class="col-md-9">
                <select class="form-select" id="modal_isActive" name="modal_isActive">
                    <option value="waiting">รอทำแบบสอบถาม</option>
                    <option value="success">สิ้นสุดแบบสอบถาม</option>
                    <option value="reject">ไม่อนุมัติแบบสอบถาม</option>
                </select>
            </div>
        </div>

        <div class="row mb-2 mt-5">
        <div class="col-md-12 text-end">
            <a href="javascript:void(0);" id="" data-bs-dismiss="modal" class="btn btn-light me-2">ยกเลิก</a>
            <button type="button" id="" onclick="check_add();" class="btn btn-primary" style="background: #1C2842;"><span class="indicator-label">บันทึก</span></button>
        </div>
        </div>
    </form>

</div>

<script>

    function check_add() {
        var formData = new FormData($("#form_submit")[0]);
        Swal.fire({
            icon: 'warning',
            title: 'กรุณากดยืนยันเพื่อทำรายการ',
            showCancelButton: true,
            confirmButtonText: 'ยืนยัน',
            cancelButtonText: `ยกเลิก`,
        }).then((result) => {
            if (result.isConfirmed) {
                $.ajax({
                    type: 'POST',
                    url: "<?php echo e("$segment/$folder/questions/$questions->id/add"); ?>",
                    data: formData,
                    processData: false,
                    contentType: false,
                    dataType: 'json',
                    success: function(data) {
                        console.log(data);
                        if (data.status == 200) {
                            Swal.fire({
                                icon: 'success',
                                title: data.message,
                                text: data.desc,
                                showCancelButton: false,
                                confirmButtonText: 'ปิด',
                            }).then((result) => {
                                location.reload();
                            });
                        } else if (data.status == 500) {
                            Swal.fire({
                                icon: 'error',
                                title: data.message,
                                text: data.desc,
                                showCancelButton: false,
                                confirmButtonText: 'ปิด',
                            }).then((result) => {
                                location.reload();
                            });
                        }
                    }
                });
            }else{
                return false;
            }
        });

        return false;
        // var role = $('#role').val();
        // var status_check = $('#status_check').val();
        // var name = $('#name').val();
        // var username = $('#username').val();
        // var password = $('#password').val();
        // var confirm_password = $('#confirm_password').val();

        // if (role == "") {
        //     toastr.error('กรุณาเลือกระดับของผู้ใช้งานนี้');
        //     return false;
        // }
        // if (status_check == "") {
        //     toastr.error('กรุณาเลือกสถานะการใช้งาน');
        //     return false;
        // }
        // if (name == "" || username == "" || password == "" || confirm_password == "") {
        //     toastr.error('กรุณากรอกข้อมูลให้ครบถ้วนก่อนบันทึกรายการ');
        //     return false;
        // }
        // if (password != confirm_password) {
        //     toastr.error('กรุณากรอกรหัสผ่านให้เหมือนกัน');
        //     return false;
        // }
    }
</script><?php /**PATH C:\laragon\www\cretive\cu-cat.com\resources\views/back-end/pages/customer/add-question.blade.php ENDPATH**/ ?>