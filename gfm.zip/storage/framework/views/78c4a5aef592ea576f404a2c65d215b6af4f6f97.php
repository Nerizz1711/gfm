<div class="modal fade" id="showpagemodal" data-bs-backdrop="static" tabindex="-1" aria-labelledby="showpagemodalLabel"
    aria-hidden="true">
    <div class="modal-dialog modal-lg">
        <div class="show_modal"></div>
    </div>
</div>

<div class="modal fade" id="showpagemodal1" data-bs-backdrop="static" tabindex="-1" aria-labelledby="showpagemodal1Label"
    aria-hidden="true">
    <div class="modal-dialog modal-xl">
        <div class="show_modal1"></div>
    </div>
</div>

<div class="modal fade" id="secondmodal" data-bs-backdrop="static" aria-hidden="true" aria-labelledby="..."
    tabindex="-1">
    <div class="modal-dialog modal-xl">
        <div class="show_secondmodal"></div>
    </div>
</div>

<script src="<?php echo e(asset('backend/dist/js/app.js')); ?>"></script>
<script src="<?php echo e(asset('backend/libs/jquery/jquery.min.js')); ?>"></script>
<script src="<?php echo e(asset('backend/libs/toastr/toastr.js')); ?>"></script>
<!-- Sweet Alerts js -->
<script src="<?php echo e(asset('backend/libs/sweetalert2/sweetalert2.min.js')); ?>"></script>

<!-- Sweet alert init js-->
<script src="<?php echo e(asset('backend/libs/sweet-alerts/sweet-alerts.init.js')); ?>"></script>

<script src="https://cdn.ckeditor.com/4.16.0/full/ckeditor.js"></script>
<?php /**PATH C:\laragon\www\orange\pipat-template\resources\views/back-end/layout/script.blade.php ENDPATH**/ ?>