<!DOCTYPE html>
<html lang="en">
<!--begin::Head-->

<head>
    <?php echo $__env->make("$prefix.layout.head", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

</head>
<!--end::Head-->
<!--begin::Body-->

<body id="kt_app_body" data-kt-app-layout="dark-sidebar" data-kt-app-header-fixed="true" data-kt-app-sidebar-enabled="true"
    data-kt-app-sidebar-fixed="true" data-kt-app-sidebar-hoverable="true" data-kt-app-sidebar-push-header="true"
    data-kt-app-sidebar-push-toolbar="true" data-kt-app-sidebar-push-footer="true" data-kt-app-toolbar-enabled="true"
    class="app-default">


    <div class="d-flex flex-column flex-root app-root" id="kt_app_root">
        <!--begin::Page-->
        <div class="app-page flex-column flex-column-fluid" id="kt_app_page">
            <!--begin::Header-->
            <div id="kt_app_header" class="app-header">
                <!-- MENU -->
                <?php echo $__env->make("$prefix.layout.menu", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <!-- END MENU -->

                <!--begin::Main-->
                <div class="app-main flex-column flex-row-fluid" id="kt_app_main">
                    <!--begin::Content wrapper-->
                    <div class="d-flex flex-column flex-column-fluid">
                        <!--begin::Toolbar-->
                        <div id="kt_app_toolbar" class="app-toolbar py-3 py-lg-6">
                            <!--begin::Toolbar container-->
                            <?php echo $__env->make("$prefix.layout.breadcrumbs", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                            <!--end::Toolbar container-->
                        </div>
                        <!--end::Toolbar-->


                        <!--begin::Content-->
                        <div id="kt_app_content" class="app-content flex-column-fluid">
                            <!--begin::Content container-->
                            <div id="kt_app_content_container" class="app-container container-fluid">
                                <form id="menuForm" method="post" action="" onsubmit="return check_add();"  enctype="multipart/form-data">
                                    <?php echo csrf_field(); ?>
                                <div class=" d-flex flex-column flex-lg-row">

                                    <div class="d-flex flex-column gap-7 gap-lg-10 w-100 w-lg-300px mb-7 me-lg-10">
                                        <div class="card card-flush py-4">
                                            <div class="card-header">
                                                <div class="card-title">
                                                    <h2>Thumbnail</h2>
                                                </div>
                                            </div>
                                            <div class="card-body text-center pt-0">
                                                <div class="row">
                                                    <div class="col-md-12">
                                                        <img id="example_image01" src="no-img.png" class="img-fluid" alt="">
                                                        <input name="image" id="image" type="file" class="custom-file-input" onchange="readURL01(this);" hidden>
                                                    </div>
                                                </div>
                                                <div class="text-muted fs-7">อัพโหลดรูปภาพเฉพาะไฟล์ *.png, *.jpg and *.jpeg image เท่านั้น</div>
                                            </div>
                                        </div>
                                    </div>

                                    <div class="d-flex flex-column flex-row-fluid gap-7 gap-lg-10">
                                        <div class="card card-flush py-4">
                                            <div class="card-header">
                                                <div class="card-title">
                                                    <h2>ข้อมูลการใช้งาน</h2>
                                                </div>
                                            </div>
                                            <div class="card-body pt-0">
                                                <div class="row">
                                                    <div class="col-md-6 mb-3">
                                                        <label class="form-label">ระดับสิทธิ์</label>
                                                        <select class="form-select" name="role" id="role">
                                                            <option value="">กรุณาเลือก</option>
                                                            <?php if(@$roles): ?>
                                                            <?php $__currentLoopData = @$roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <option value="<?php echo e($role->id); ?>"><?php echo e($role->name); ?></option>
                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                            <?php endif; ?>
                                                        </select>
                                                    </div>
                                                    <div class="col-md-6 mb-3">
                                                        <label class="form-label">สถานะ</label>
                                                        <select class="form-control" name="isActive" id="isActive">
                                                            <option value="" hidden>กรุณาเลือก</option>
                                                            <option value="Y">ใช้งาน</option>
                                                            <option value="N">ไม่ใช้งาน</option>
                                                        </select>
                                                    </div>
                                                </div>
                                              
                                               <div class="row">
                                                    <div class="col-md-6">
                                                        <div class="mb-10 fv-row">
                                                            <label class="form-label">อีเมล</label>
                                                            <input type="text" id="email" name="email" class="form-control mb-2" placeholder="" value="" />
                                                        </div>
                                                    </div>
                                                    <div class="col-md-6">
                                                        <div class="mb-10 fv-row">
                                                            <label class="form-label">รหัสผ่าน</label>
                                                            <input type="password" id="password" name="password" class="form-control mb-2" placeholder="" value="" />
                                                        </div>
                                                    </div>
                                               </div>
                                               
                                            </div>
                                        </div>

                                        <div class="card card-flush py-4">
                                            <div class="card-header">
                                                <div class="card-title">
                                                    <h2>ข้อมูลส่วนตัว</h2>
                                                </div>
                                            </div>
                                            <div class="card-body pt-0">

                                                <div class="row mb-2">
                                                    <label class="col-md-3 col-form-label">คำนำหน้าชื่อ</label>
                                                    <div class="col-md-9">
                                                        <select id="title" name="title" class="form-select">
                                                            <option value="นาย">นาย</option>
                                                            <option value="นาง">นาง</option>
                                                            <option value="นางสาว">นางสาว</option>
                                                        </select>
                                                    </div>
                                                </div>

                                                <div class="row mb-2">
                                                    <label class="col-md-3 col-form-label">ชื่อภาษาไทย <span class="text-danger">*</span></label>
                                                    <div class="col-md-9">
                                                        <input type="text" id="name_th" name="name_th" class="form-control mb-2" placeholder="ชื่อ-นามสกุล ภาษาไทย" value="" />
                                                    </div>
                                                </div>
                                                <div class="row mb-2">
                                                    <label class="col-md-3 col-form-label">ชื่อภาษาอังกฤษ</label>
                                                    <div class="col-md-9">
                                                        <input type="text" id="name_en" name="name_en" class="form-control mb-2" placeholder="ชื่อ-นามสกุล ภาษาอังกฤษ" value="" />
                                                    </div>
                                                </div>
                                                <div class="row mb-2">
                                                    <label class="col-md-3 col-form-label">เลขบัตรประชาชน/พาสปอร์ต</label>
                                                    <div class="col-md-9">
                                                        <input type="text" id="idcard" name="idcard" class="form-control mb-2" placeholder="เลขบัตรประชาชน/พาสปอร์ต" value="" />
                                                    </div>
                                                </div>
                                                <div class="row mb-2">
                                                    <label class="col-md-3 col-form-label">วันเกิด</label>
                                                    <div class="col-md-9">
                                                        <input type="date" id="birthdate" name="birthdate" class="form-control mb-2" placeholder="" value="" />
                                                    </div>
                                                </div>
                                                <div class="row mb-2">
                                                    <label class="col-md-3 col-form-label">เบอร์โทร </label>
                                                    <div class="col-md-9">
                                                        <input type="text" id="phone" name="phone" class="form-control mb-2" placeholder="เบอร์โทรติดต่อ" value="" />
                                                    </div>
                                                </div>

                                            </div>
                                        </div>

                                        <div class="d-flex justify-content-end">
                                            <a href="<?php echo e(url("$segment/$folder")); ?>" id="" class="btn btn-light me-5">ยกเลิก</a>
                                            <button type="submit" id="" class="btn btn-primary"><span class="indicator-label">บันทึก</span></button>
                                        </div>
                                    </div>
                                </div>

                            </form>
                            </div>
                            <!--end::Content container-->
                        </div>
                        <!--end::Content-->


                    </div>
                </div>
            </div>
        </div>
    </div>
    <!--begin::Javascript-->
    <?php echo $__env->make("$prefix.layout.script", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <script>
        $("#example_image01").click(function() {
            $("input[id='image']").click();
        });

        function readURL01(input) {
            if (input.files && input.files[0]) {
                var reader = new FileReader();
                reader.onload = function(e) {
                    $('#example_image01').attr('src', e.target.result);
                }
                reader.readAsDataURL(input.files[0]);
            }
        }

        function check_add() {
            // var role = $('#role').val();
            // var status_check = $('#status_check').val();
            // var name = $('#name').val();
            // var username = $('#username').val();
            // var password = $('#password').val();
            // var confirm_password = $('#confirm_password').val();

            // if (role == "") {
            //     toastr.error('กรุณาเลือกระดับของผู้ใช้งานนี้');
            //     return false;
            // }
            // if (status_check == "") {
            //     toastr.error('กรุณาเลือกสถานะการใช้งาน');
            //     return false;
            // }
            // if (name == "" || username == "" || password == "" || confirm_password == "") {
            //     toastr.error('กรุณากรอกข้อมูลให้ครบถ้วนก่อนบันทึกรายการ');
            //     return false;
            // }
            // if (password != confirm_password) {
            //     toastr.error('กรุณากรอกรหัสผ่านให้เหมือนกัน');
            //     return false;
            // }
        }
    </script>
    <!--end::Javascript-->
</body>
<!--end::Body-->

</html>
<?php /**PATH C:\laragon\www\cretive\cu-cat.com\resources\views/back-end/pages/administrator/user/add.blade.php ENDPATH**/ ?>