<div class="modal-content">
    <form id="frm_cus" action="" method="POST" autocomplete="off" onsubmit="return check_add();"
        enctype="multipart/form-data" class="noentersubmit">
        <?php echo e(csrf_field()); ?>

        <div class="modal-header flex-grow-1 overflow-hidden dragable_touch">
            <h2 class="font-medium text-base mr-auto">
                เมนู <?php echo e($data->name); ?>

            </h2>
            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>
        <div class="modal-body">

            <table class="table mb-0">
                <thead>
                    <tr>
                        <th class="text-center" style="width:5%">ลำดับ</th>
                        <th style="width:30%">ชื่อเมนูย่อย</th>
                        <th class="text-center" style="width:15%">ลำดับ</th>
                        <th class="text-center" style="width:10%">สถานะ</th>
                        <th class="text-center" style="width:20%">วันที่สร้าง</th>
                        <th class="text-center" style="width:10%">จัดการ</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if($rows): ?>
                    <?php $i=0; ?>
                    <?php $__currentLoopData = $rows; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php $i++; ?>
                    <tr>
                        <td class="w-10 text-center"><?php echo e(@$i); ?></td>
                        <td class="w-20"><?php echo e(@$row->name); ?></td>
                        <td class="w-10">
                            <?php $sorts = \App\Models\Backend\MenuModel::where('_id',$row->_id)->orderby('sort')->get(); ?>
                            <select id="sort_<?php echo e($row->id); ?>" name="sort_<?php echo e($row->id); ?>" class="form-select w100" onchange="changesort_sub('<?php echo e($row->id); ?>')">
                                <?php $__currentLoopData = $sorts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($s->sort); ?>" <?php if($s->sort == $row->sort): ?> selected <?php endif; ?>><?php echo e($s->sort); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>

                        </td>
                        <td class="w-10 text-center">
                            <div class="form-check form-switch w-full sm:w-auto sm:ml-auto mt-3 sm:mt-0">
                                <input id="status_change_<?php echo e(@$row->id); ?>" data-id="<?php echo e(@$row->id); ?>" onclick="status(<?php echo e(@$row->id); ?>);" class="show-code form-check-input mr-0 ml-3" type="checkbox" <?php if($row->status == "on"): ?> checked <?php endif; ?>>
                            </div>

                        </td>
                        <td class="w-10 text-center"><?php echo e(date('d/m/Y',strtotime('+543 Years',strtotime($row->created)))); ?></td>
                        <td class="w-40 text-center">
                            <a href="<?php echo e(url("$segment/$folder/$row->id")); ?>" ><i class="fa fa-edit" style="margin-right:5px;"></i></a>
                            <a href="javascript:void(0);" onclick="deleteItem_sub(<?php echo e($row->id); ?>)"><i class="fa fa-trash" style="margin-right:5px;"></i></a>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>


                </tbody>
            </table>

        </div>
        <div class="modal-footer">
            <button type="button" data-tw-dismiss="modal" class="btn btn-outline-secondary w-20 mr-1">ปิด</button>
        </div>
    </form>
</div>


<script>
   
</script>
<?php /**PATH C:\laragon\www\orange\pipat-template\resources\views/back-end/pages/administrator/menu/show_submenu.blade.php ENDPATH**/ ?>