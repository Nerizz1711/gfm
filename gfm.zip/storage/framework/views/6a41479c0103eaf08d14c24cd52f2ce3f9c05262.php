<!DOCTYPE html>
<html lang="en" class="light">
    <!-- BEGIN: Head -->
    <head>
        <?php echo $__env->make("$prefix.layout.header", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </head>
    <!-- END: Head -->
    <body class="main">
        
        <!-- BEGIN: MENU -->
        <?php echo $__env->make("$prefix.layout.menu-top", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <!-- END: Menu -->

       
        <div class="wrapper">
            <div class="wrapper-box">
                <!-- BEGIN: Side Menu -->
                <?php echo $__env->make("$prefix.layout.menu-slide", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <!-- END: Side Menu -->

                <!-- BEGIN: Content -->
                <div class="content">

                    <div class="intro-y flex flex-col sm:flex-row items-center mt-8 mb-2">
                        <h2 class="text-lg font-medium mr-auto">
                            Administrator / User
                        </h2>
                        <div class="w-full sm:w-auto flex mt-4 sm:mt-0">
                            <a href="<?php echo e(url("$segment/$folder/add")); ?>"><button type="button" class="btn btn-primary shadow-md mr-2">+ เพิ่มข้อมูล</button></a>
                        </div>
                    </div>
        
                    <div class="intro-y box">
                        <div class="p-5" id="head-options-table">
                            <div class="overflow-x-auto">
                                <div class="hidden md:block mx-auto text-slate-500"><b>Showing <?php echo e(@$items->currentPage()); ?> to <?php echo e(@$items->total()); ?>  of <?php echo e(@$items->total()); ?> entries</b></div>
                                <table class="table">
                                    <thead class="" style="background-color: #e8ecef;">
                                        <th style="width:5%;" class="text-center">#</th>
                                        <th style="width:5%;" class="text-left">รูปภาพ</th>
                                        <th style="width:35%;" class="text-left">ชื่อ</th>
                                        <th style="width:15%;" class="text-center">วันที่สร้าง</th>
                                        <th style="width:15%;" class="text-center">วันที่แก้ไข</th>
                                        <th style="width:10%;" class="text-center">สถานะ</th>
                                        <th style="width:15%;" class="text-center">จัดการ</th>
                                    </thead>
                                    <tbody>
                                        <?php if(@$items->count() > 0): ?>
                                            <?php $__currentLoopData = @$items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <tr>
                                                    <td class="text-center"> <?php echo e($items->pages->start+$index + 1); ?></td>
                                                    <td><a href="<?php echo e(@$item->image); ?>" target="_blank"><img src="<?php echo e(@$item->image); ?>" style="width:100%"></a></td>
                                                    <td><?php echo e(@$item->name); ?></td>
                                                    <td class="text-center"><?php echo e(date('d/m/Y, H:i น.',strtotime($item->created_at))); ?></td>
                                                    <td class="text-center"><?php echo e(date('d/m/Y, H:i น.',strtotime($item->updated_at))); ?></td>
                                                    <td class="text-center"><?php echo \Helper::isActive($item->isActive); ?></td>
                                                    <td class="text-center">
                                                        <a href="<?php echo e(url("$segment/$folder/$item->id")); ?>"><i class="fa fa-edit " style="margin-right:5px;"></i></a>
                                                        <a href="javascript:void(0);" onclick="deleteItem(<?php echo e($item->id); ?>)"><i class="fa fa-trash "></i></a>
                                                    </td>
                                                </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php else: ?>
                                            <tr>
                                                <td colspan="7" class="text-center">- No items -</td>
                                            </tr>
                                        <?php endif; ?>
                                    </tbody>
                                </table>
                                <div class="table-footer mt-2">
                                    <div class="row">
                                        <div class="col-sm-5">
                                            <p style=" ">
                                                
                                            </p>
                                        </div>
                                        <div class="col-sm-7" >
                                            <?php echo $items->appends(request()->all())->links('back-end.layout.pagination'); ?>

                                        </div>
                                    </div>
                                </div>
                                
                            </div>
                
                        </div>
                    </div>
                </div>
                <!-- END: Content -->

                
            </div>
        </div>
 
        <!-- BEGIN: JS Assets-->
        <?php echo $__env->make("$prefix.layout.script", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <!-- END: JS Assets-->

        <script>
            var fullUrl = window.location.origin + window.location.pathname;
    
            function deleteItem(ids) {
                const id = [ids];
                if (id.length > 0) {
                    destroy(id)
                }
            }
    
            function destroy(id) {
                Swal.fire({
                    title: "ลบข้อมูล",
                    text: "คุณต้องการลบข้อมูลใช่หรือไม่?",
                    icon: "warning",
                    showCancelButton: true,
                    confirmButtonColor: "#DD6B55",
                    showLoaderOnConfirm: true,
                    preConfirm: () => {
                        return fetch(fullUrl + '/destroy/' + id)
                            .then(response => response.json())
                            .then(data => location.reload())
                            .catch(error => {
                                Swal.showValidationMessage(`Request failed: ${error}`)
                            })
                    }
                });
            }
        </script>
    </body>
</html><?php /**PATH C:\laragon\www\orange\pipat-template\resources\views/back-end/pages/template/standard/index.blade.php ENDPATH**/ ?>