<!DOCTYPE html>
<html lang="en" class="light">
<!-- BEGIN: Head -->

<head>
    <?php echo $__env->make("$prefix.layout.header", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</head>
<!-- END: Head -->

<body class="main">

    <!-- BEGIN: MENU -->
    <?php echo $__env->make("$prefix.layout.menu-top", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- END: Menu -->


    <div class="wrapper">
        <div class="wrapper-box">
            <!-- BEGIN: Side Menu -->
            <!-- END: Side Menu -->

            <!-- BEGIN: Content -->
            <div class="content">

                <div class="grid grid-cols-12 gap-6 mt-8">
                    <div class="col-span-12 lg:col-span-3 2xl:col-span-2">
                        <div class="intro-y p-5">
                            <div class="border border-gray-300 border-dashed rounded min-w-125px py-3 px-4 mb-3 bg-success">
                                <h3 class="fw-bold mb-1 text-white"><b>Log Viewer</b></h3>
                                <div class="fw-semibold text-white fs-7 d-block lh-1">
                                    ย้อนกลับไป <a class="fw-semibold text-primary" href="<?php echo e(url("$segment")); ?>">หน้าแรก</a>
                                </div>
                            </div>
    
                            <div class="text-center border border-gray-300 border-dashed rounded min-w-125px py-3 px-4 mb-3 bg-danger">
                                <b class="text-white">LOG DATE</b>
                            </div>
                            <form id="searchForm" method="get">
                            <input type="date" class="form-control w-full" id="due_date" name="due_date" onchange="change_duedate();" value="<?php echo e($due_date); ?>">
                            </form>
                        </div>
                        
                    </div>

                    <div class="col-span-12 lg:col-span-9 2xl:col-span-9">
                        <div
                            class="border border-gray-300 border-dashed rounded min-w-125px py-3 px-4 mb-3 bg-success text-white">
                            <div class="hidden md:block mx-auto text-white-500"><b>Showing <?php echo e($items->currentPage()); ?> to <?php echo e($items->pages->start + 1); ?> of <?php echo e($items->pages->start + $items->count()); ?> entries</b></div>
                        </div>

                        <div class="intro-y box">
                            <div class="p-5" id="head-options-table">
                                <div class="overflow-x-auto">
                                    <table class="table">
                                        <thead class="">
                                            <th class="text-center" style="width:10%;">Code</th>
                                            <th style="width:10%;">Level</th>
                                            <th style="width:15%;">Time</th>
                                            <th style="width:5%;">Type</th>
                                            <th style="width:5%;">Env</th>
                                            <th style="width:55%;">Description</th>
                                        </thead>
                                        <tbody>
                                            <?php if($items->total() > 0): ?>
                                                <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index=>$item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <tr onclick="show_log(<?php echo e($item->id); ?>)">
                                                    <td class="mfont8 text-center"><?php echo e(@$item->id); ?></td>
                                                    <td class="mfont12"><?php echo Helper::typeLogs($item->level); ?></td>
                                                    <td class="mfont8"><?php echo e(date('Y-m-d H:i:s ',strtotime($item->date))); ?></td>
                                                    <td class="mfont8 text-center"><span class="text-muted"><?php echo Helper::typeLogsSystem($item->type); ?></span></td>
                                                    <td class="mfont12"><span class="text-muted"><?php echo e($item->env); ?></span></td>
                                                    <td class="mfont8"><span class="text-muted"><?php echo e($item->desc); ?></span>
                                                    </td>
                                                </tr>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            <?php else: ?>

                                            <?php endif; ?>
                                        </tbody>
                                    </table>
                                    <div class="table-footer mt-2">
                                        <div class="row">
                                            <div class="col-sm-5">
                                                <p style=" ">
                                                    
                                                </p>
                                            </div>
                                            <div class="col-sm-7" >
                                                <?php echo $items->appends(request()->all())->links('back-end.layout.pagination'); ?>

                                            </div>
                                        </div>
                                    </div>
                                    
                                </div>
                    
                            </div>
                        </div>
                    </div>

                </div>

            </div>
            <!-- END: Content -->


        </div>
    </div>

    <!-- BEGIN: JS Assets-->
    <?php echo $__env->make("$prefix.layout.script", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <script>
        var fullUrl = window.location.origin + window.location.pathname;
        function change_duedate(){
            document.getElementById("searchForm").submit();
        }

        function show_log(id) {
            const el = document.querySelector("#showpagemodal1");
            const modal = tailwind.Modal.getOrCreateInstance(el);
            $.ajax({
                type: 'GET',
                url: fullUrl + '/show-log',
                data: {
                    _token: "<?php echo e(csrf_token()); ?>",
                    id:id,
                },
                dataType: 'html',
                success: function(data) {
                    $('.show_modal1').html(data);
                    modal.show();
                }
            });
        }
    </script>
    <!-- END: JS Assets-->
</body>

</html>
<?php /**PATH C:\laragon\www\orange\pipat-template\resources\views/back-end/pages/log/index.blade.php ENDPATH**/ ?>