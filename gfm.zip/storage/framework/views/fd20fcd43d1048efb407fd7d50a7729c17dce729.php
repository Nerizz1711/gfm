<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>" />
    <title>CU-CAT</title>

    <?php echo $__env->make("$prefix.layout.stylesheet", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</head>

<body>

    <section id="content">
        <div class="result-score">
            <div class="mobile-size">
                <!-- Header -->
                <?php echo $__env->make("$prefix.layout.header", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <!-- End Header -->

                <div class="row">
                    <div class="col-xl-12">
                        <div class="box-heading">
                            <p class="name-heading"><?php echo e(@$max_point); ?></p>
                            <p class="sub-heading">คะแนนรวม</p>
                        </div>
                        <div>
                            
                            <div class="box-result-score">
                                <h5 class="title-questionnaire">VAS</h5>
                                <p class="title-date"><?php echo e(date('d/m/Y',strtotime(@$time->created_at))); ?></p>

                                <div class="box-score">
                                    <p class="title-score"><?php echo @$vas_point; ?> <span class="title-unit">คะแนน</span></p>
                                </div>
                            </div>

                            <div class="box-result-score">
                                <h5 class="title-questionnaire">Womac Score</h5>
                                <p class="title-date"><?php echo e(date('d/m/Y',strtotime(@$time->created_at))); ?></p>

                                <div class="box-score">
                                    <p class="title-score"><?php echo @$womac_point; ?> <span class="title-unit">คะแนน</span></p>
                                </div>
                            </div>

                            <div class="box-result-score">
                                <h5 class="title-questionnaire">SF - 12</h5>
                                <p class="title-date"><?php echo e(date('d/m/Y',strtotime(@$time->created_at))); ?></p>

                                <div class="box-score">
                                    <p class="title-score"><?php echo @$sf12_point; ?> <span class="title-unit">คะแนน</span></p>
                                </div>
                            </div>

                            <div class="container-center">
                                <a href="javascript:void(0);" onclick="submit_question();" class="btn  btn-nextpage" tabindex="-1" role="button" aria-disabled="false">ถัดไป</a>
                                <a href="<?php echo e(url("questionnaire?quest=".$backpage)); ?>" class="btn-custom  btn-grays-outline" tabindex="-1" role="button" aria-disabled="false">ย้อนกลับ</a>

                            </div>
                        </div>
                    </div>

                </div>
            </div>
    </section>

    <?php echo $__env->make("$prefix.layout.javascript", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <script>
    var fullUrl = window.location.origin + window.location.pathname;
    function submit_question() {
        Swal.fire({
            icon: 'warning',
            title: 'กรุณากดยืนยันเพื่อทำรายการ',
            html: 'เมื่อกดส่งแบบสอบถามแล้ว จะไม่สามารถแก้ไขข้อมูลได้ <br/>กรุณาตรวจสอบข้อมูลให้ครบถ้วนก่อนทำรายการ',
            showCancelButton: true,
            confirmButtonText: 'ยืนยัน',
            cancelButtonText: `ยกเลิก`,
        }).then((result) => {
            if (result.value == true) {
                $.ajaxSetup({
                    headers: {
                        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                    }
                });
                $.ajax({
                    type: 'POST',
                    url: fullUrl,
                    data: {

                    },
                    dataType: 'json',
                    success: function(data) {
                        if (data.status == 200) {
                            location.href="success";
                        } else if (data.status == 500) {
                            Swal.fire({
                                icon: 'error',
                                title: data.message,
                                text: data.desc,
                                showCancelButton: false,
                                confirmButtonText: 'ปิด',
                            }).then((result) => {
                                location.reload();
                            });
                        }
                    }
                });
            }else{
                return false;
            }
        });
    }
    </script>
</body>

</html>
<?php /**PATH C:\laragon\www\cretive\cu-cat.com\resources\views/front-end/result-score.blade.php ENDPATH**/ ?>