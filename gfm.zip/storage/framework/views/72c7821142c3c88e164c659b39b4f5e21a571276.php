<!DOCTYPE html>
<html lang="en">
<!--begin::Head-->

<head>
    <?php echo $__env->make("$prefix.layout.head", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

</head>
<!--end::Head-->
<!--begin::Body-->

<body id="kt_app_body" data-kt-app-layout="dark-sidebar" data-kt-app-header-fixed="true" data-kt-app-sidebar-enabled="true"
    data-kt-app-sidebar-fixed="true" data-kt-app-sidebar-hoverable="true" data-kt-app-sidebar-push-header="true"
    data-kt-app-sidebar-push-toolbar="true" data-kt-app-sidebar-push-footer="true" data-kt-app-toolbar-enabled="true"
    class="app-default">


    <div class="d-flex flex-column flex-root app-root" id="kt_app_root">
        <!--begin::Page-->
        <div class="app-page flex-column flex-column-fluid" id="kt_app_page">
            <!--begin::Header-->
            <div id="kt_app_header" class="app-header">
                <!-- MENU -->
                <?php echo $__env->make("$prefix.layout.menu", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <!-- END MENU -->

                <!--begin::Main-->
                <div class="app-main flex-column flex-row-fluid" id="kt_app_main">
                    <!--begin::Content wrapper-->
                    <div class="d-flex flex-column flex-column-fluid">
                        <!--begin::Toolbar-->
                        <div id="kt_app_toolbar" class="app-toolbar py-3 py-lg-6">
                            <!--begin::Toolbar container-->
                            <?php echo $__env->make("$prefix.layout.breadcrumbs", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                            <!--end::Toolbar container-->
                        </div>
                        <!--end::Toolbar-->


                        <!--begin::Content-->
                        <div id="kt_app_content" class="app-content flex-column-fluid">
                            <!--begin::Content container-->
                            <div id="kt_app_content_container" class="app-container container-fluid">
                                

                                <div class="row">
                                    <div class="col-md-3">
                                        <div class="card mb-5 mb-xl-8">
                                            <div class="card-body pt-15">
                                                <div class="d-flex flex-center flex-column mb-5">
                                                    <div class="symbol symbol-150px symbol-circle mb-7">
                                                        <img src="<?php echo e($row->image); ?>" alt="image">
                                                    </div>
                                                    <a href="<?php echo e(url("$segment/$folder/view/$row->id")); ?>" class="fs-3 text-gray-800 text-hover-primary fw-bold mb-1"><?php echo e($row->fullname()); ?></a>
                                                </div>
                                                <div class="d-flex flex-stack fs-4 py-3">
                                                    <div class="fw-bold">รายละเอียด</div>
                                                    <?php echo @Helper::checkCurse(Auth::guard('user')->id()); ?>

                                                </div>
                                                <div class="separator separator-dashed my-3"></div>

                                                <div class="row">
                                                    <div class="col-md-12 fw-bold mt-5">เลขบัตรประชาชน</div>
                                                    <div class="col-md-12 text-gray-600"><?php echo e($row->idcard); ?></div>
                                                </div>

                                                <div class="row">
                                                    <div class="col-md-12 fw-bold mt-5">เบอร์โทรศัพท์</div>
                                                    <div class="col-md-12 text-gray-600"><?php echo e($row->phone); ?></div>
                                                </div>

                                                <div class="row">
                                                    <div class="col-md-12 fw-bold mt-5">เพศ</div>
                                                    <div class="col-md-12 text-gray-600"><?php echo e($row->sex); ?></div>
                                                </div>

                                                <div class="row">
                                                    <div class="col-md-12 fw-bold mt-5">วันเกิด</div>
                                                    <div class="col-md-12 text-gray-600"><?php echo e(date('d-m-Y',strtotime($row->birthdate))); ?></div>
                                                </div>

                                                <div class="row">
                                                    <div class="col-md-12 fw-bold mt-5">อายุ</div>
                                                    <div class="col-md-12 text-gray-600"><?php echo e($row->age); ?></div>
                                                </div>

                                                <div class="separator separator-dashed my-3"></div>
                                                <div class="row">
                                                    <div class="col-md-12 fw-bold">ข้อมูลดัชนีมวลกาย</div>
                                                </div>

                                                <div class="row">
                                                    <div class="col-md-12 fw-bold mt-5">ส่วนสูง</div>
                                                    <div class="col-md-12 text-gray-600"><?php echo e($row->height); ?></div>
                                                </div>

                                                <div class="row">
                                                    <div class="col-md-12 fw-bold mt-5">น้ำหนัก</div>
                                                    <div class="col-md-12 text-gray-600"><?php echo e($row->weight); ?></div>
                                                </div>

                                                <div class="row">
                                                    <div class="col-md-12 fw-bold mt-5">BMI</div>
                                                    <div class="col-md-12 text-gray-600"><?php echo e($row->bmi); ?></div>
                                                </div>


                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-9">
                                        <div class="flex-lg-row-fluid ms-lg-15">
                                            <ul class="nav nav-custom nav-tabs nav-line-tabs nav-line-tabs-2x border-0 fs-4 fw-semibold mb-8" role="tablist">
												<li class="nav-item" role="presentation">
													<a class="nav-link text-active-primary pb-4 active" data-bs-toggle="tab" href="#kt_ecommerce_customer_overview" aria-selected="true" role="tab">ภาพรวม</a>
												</li>
											</ul>

                                            <div class="tab-pane fade show active" id="kt_ecommerce_customer_overview" role="tabpanel">
                                                <div class="row row-cols-1 row-cols-md-2 mb-6 mb-xl-9">
                                                    <div class="col">
                                                        <!--begin::Card-->
                                                        <div class="card pt-4 h-md-100 mb-6 mb-md-0">
                                                            <!--begin::Card header-->
                                                            <div class="card-header border-0">
                                                                <!--begin::Card title-->
                                                                <div class="card-title">
                                                                    <h2 class="fw-bold">ข้อมูลการพบแพทย์</h2>
                                                                </div>
                                                                <!--end::Card title-->
                                                            </div>
                                                            <!--end::Card header-->
                                                            <!--begin::Card body-->
                                                            <div class="card-body pt-0">
                                                                <div class="fw-bold fs-2">
                                                                    <div class="d-flex">
                                                                        <!--begin::Svg Icon | path: icons/duotune/general/gen030.svg-->
                                                                        <span class="svg-icon svg-icon-info svg-icon-2x">
                                                                            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                                                <path d="M18.3721 4.65439C17.6415 4.23815 16.8052 4 15.9142 4C14.3444 4 12.9339 4.73924 12.003 5.89633C11.0657 4.73913 9.66 4 8.08626 4C7.19611 4 6.35789 4.23746 5.62804 4.65439C4.06148 5.54462 3 7.26056 3 9.24232C3 9.81001 3.08941 10.3491 3.25153 10.8593C4.12155 14.9013 9.69287 20 12.0034 20C14.2502 20 19.875 14.9013 20.7488 10.8593C20.9109 10.3491 21 9.81001 21 9.24232C21.0007 7.26056 19.9383 5.54462 18.3721 4.65439Z" fill="currentColor"></path>
                                                                            </svg>
                                                                        </span>
                                                                        <!--end::Svg Icon-->
                                                                        <?php 
                                                                        ?>
                                                                        <div class="ms-2"><span id="show_curse">0</span>
                                                                        <span class="text-muted fs-4 fw-semibold">ครั้ง</span></div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                            <!--end::Card body-->
                                                        </div>
                                                        <!--end::Card-->
                                                    </div>
                                                </div>

                                                <div class="row">
                                                    <div class="col-md-12 mb-2 text-end">
                                                        <a href="javascript:void(0);" onclick="createModal();" class="btn btn-sm btn-info">+ เพิ่มการรักษา</a>
                                                    </div>
                                                    <div class="col-md-12">
                                                        <div class="card">
                                                            <div class="card-body pt-0">
                                                                <table class="table align-middle table-row-dashed fs-6 gy-5"
                                                                    id="kt_ecommerce_products_table">
                                                                    <thead>
                                                                        <tr class="text-start text-gray-400 fw-bold fs-7 text-uppercase gs-0">
                                                                            <th style="width:5%;" class="text-center">#</th>
                                                                            <th style="width:25%;" class="text-left">การรักษา</th>
                                                                            <th style="width:10%;" class="text-left">กลุ่มการรักษา</th>
                                                                            <th style="width:10%;" class="text-left">แพทย์ผู้รักษา</th>
                                                                            <th style="width:10%;" class="text-center">จำนวนรอบรักษา</th>
                                                                            <th style="width:10%;" class="text-center">วันที่สร้าง</th>
                                                                            <th style="width:10%;" class="text-center">วันที่แก้ไข</th>
                                                                            <th style="width:10%;" class="text-center">จัดการ</th>
                                                                        </tr>
                                                                    </thead>
                                                                    <tbody>
                                                                        <?php if(@$questions): ?>
                                                                            <?php $__currentLoopData = @$questions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index=>$question): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                            <?php 
                                                                            $time = \App\Models\Backend\Customer_question_timeModel::where(["customer_id"=>$question->customer_id, "question_head_id"=>$question->id])->count();
                                                                            ?>
                                                                            <tr>
                                                                                <td class="text-center">1</td>
                                                                                <td class="text-left"><?php echo e(@$question->curse_detail); ?></td>
                                                                                <td class="text-left">-</td>
                                                                                <td class="text-left">-</td>
                                                                                <td class="text-center"><?php echo e(@$time); ?></td>
                                                                                <td class="text-center"><?php echo e(date('d/m/Y',strtotime('+543 years',strtotime($question->created_at)))); ?></td>
                                                                                <td class="text-center"><?php echo e(date('d/m/Y',strtotime('+543 years',strtotime($question->updated_at)))); ?></td>
                                                                                <td class="text-center">
                                                                                    <a href="<?php echo e("$segment/$folder/view-cure/$question->id"); ?>"><i class="fa fa-search fa-2x"></i></a>
                                                                                </td>
                                                                            </tr>
                                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                        <?php endif; ?>
                                                                    </tbody>
                                                                </table>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>

                                                <!--begin::Card-->
                                               
                                            </div>
                                        </div>
                                    </div>
                                </div>

                            </div>
                            <!--end::Content container-->
                        </div>
                        <!--end::Content-->


                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="modal fade" id="modelShow" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered mw-650px">
            <div class="modal-content">
                <div class="show_modal"></div>
            </div>
        </div>
    </div>

    <!--begin::Javascript-->
    <?php echo $__env->make("$prefix.layout.script", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <script>
        function createModal() {
            $.ajax({
                type: 'GET',
                url: "<?php echo e("$segment/$folder/curse/$row->id/add"); ?>",
                data: {
                    "_token": "<?php echo e(csrf_token()); ?>",
                },
                dataType: 'html',
                success: function(data) {
                    $('#modelShow').modal('show');
                    $('.show_modal').html(data);
                }
            })
        }

        $("#example_image01").click(function() {
            $("input[id='image']").click();
        });

        function readURL01(input) {
            if (input.files && input.files[0]) {
                var reader = new FileReader();
                reader.onload = function(e) {
                    $('#example_image01').attr('src', e.target.result);
                }
                reader.readAsDataURL(input.files[0]);
            }
        }

        function check_add() {
            // var role = $('#role').val();
            // var status_check = $('#status_check').val();
            // var name = $('#name').val();
            // var username = $('#username').val();
            // var password = $('#password').val();
            // var confirm_password = $('#confirm_password').val();

            // if (role == "") {
            //     toastr.error('กรุณาเลือกระดับของผู้ใช้งานนี้');
            //     return false;
            // }
            // if (status_check == "") {
            //     toastr.error('กรุณาเลือกสถานะการใช้งาน');
            //     return false;
            // }
            // if (name == "" || username == "" || password == "" || confirm_password == "") {
            //     toastr.error('กรุณากรอกข้อมูลให้ครบถ้วนก่อนบันทึกรายการ');
            //     return false;
            // }
            // if (password != confirm_password) {
            //     toastr.error('กรุณากรอกรหัสผ่านให้เหมือนกัน');
            //     return false;
            // }
        }
    </script>
    <!--end::Javascript-->
</body>
<!--end::Body-->

</html>
<?php /**PATH C:\laragon\www\cretive\cu-cat.com\resources\views/back-end/pages/customer/view.blade.php ENDPATH**/ ?>