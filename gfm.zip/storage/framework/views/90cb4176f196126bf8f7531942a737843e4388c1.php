<div class="modal-header">
    <h2>สร้าง ข้อมูลยา</h2>
    <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
        <span class="svg-icon svg-icon-1">
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="currentColor" />
                <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="currentColor" />
            </svg>
        </span>
    </div>
</div>

<div class="modal-body py-lg-10 px-lg-10">
    <form id="form_submit" method="POST" enctype="multipart/form-data">
    <?php echo csrf_field(); ?>
      
        <div class="row mb-2">
            <label class="col-md-3 col-form-label">ชื่อ <span class="text-danger">*</span></label>
            <div class="col-md-9">
                <input type="text" id="name" name="name" class="form-control" placeholder="กรุณากรอกชื่อยา" value="" />
            </div>
        </div>

        <div class="row">
            <label class="col-md-3 col-form-label">สถานะ</label>
            <div class="col-md-9 mt-3">
                <label class="form-check form-switch form-switch-sm form-check-custom form-check-solid">
                    <input class="form-check-input" type="checkbox" value="Y" id="isActive" name="isActive">
                    <span class="form-check-label fw-semibold text-muted" for="">ใช้งาน</span>
                </label>
            </div>
        </div>

        <div class="row mb-2 mt-5">
        <div class="col-md-12 text-end">
            <a href="javascript:void(0);" id="" data-bs-dismiss="modal" class="btn btn-light me-2">ยกเลิก</a>
            <button type="button" id="" onclick="check_add();" class="btn btn-primary" style="background: #1C2842;"><span class="indicator-label">บันทึก</span></button>
        </div>
        </div>
    </form>

</div>

<script>

    function check_add() {
        var formData = new FormData($("#form_submit")[0]);
        Swal.fire({
            icon: 'warning',
            title: 'กรุณากดยืนยันเพื่อทำรายการ',
            showCancelButton: true,
            confirmButtonText: 'ยืนยัน',
            cancelButtonText: `ยกเลิก`,
        }).then((result) => {
            if (result.isConfirmed) {
                $.ajax({
                    type: 'POST',
                    url: "<?php echo e("$segment/$folder/add"); ?>",
                    data: formData,
                    processData: false,
                    contentType: false,
                    dataType: 'json',
                    success: function(data) {
                        console.log(data);
                        if (data.status == 200) {
                            Swal.fire({
                                icon: 'success',
                                title: data.message,
                                text: data.desc,
                                showCancelButton: false,
                                confirmButtonText: 'ปิด',
                            }).then((result) => {
                                location.reload();
                            });
                        } else if (data.status == 500) {
                            Swal.fire({
                                icon: 'error',
                                title: data.message,
                                text: data.desc,
                                showCancelButton: false,
                                confirmButtonText: 'ปิด',
                            }).then((result) => {
                                location.reload();
                            });
                        }
                    }
                });
            }else{
                return false;
            }
        });

        return false;
        // var role = $('#role').val();
        // var status_check = $('#status_check').val();
        // var name = $('#name').val();
        // var username = $('#username').val();
        // var password = $('#password').val();
        // var confirm_password = $('#confirm_password').val();

        // if (role == "") {
        //     toastr.error('กรุณาเลือกระดับของผู้ใช้งานนี้');
        //     return false;
        // }
        // if (status_check == "") {
        //     toastr.error('กรุณาเลือกสถานะการใช้งาน');
        //     return false;
        // }
        // if (name == "" || username == "" || password == "" || confirm_password == "") {
        //     toastr.error('กรุณากรอกข้อมูลให้ครบถ้วนก่อนบันทึกรายการ');
        //     return false;
        // }
        // if (password != confirm_password) {
        //     toastr.error('กรุณากรอกรหัสผ่านให้เหมือนกัน');
        //     return false;
        // }
    }
</script><?php /**PATH C:\laragon\www\cretive\cu-cat.com\resources\views/back-end/pages/doctor/add.blade.php ENDPATH**/ ?>