<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>CU-CAT</title>
    <?php echo $__env->make("$prefix.layout.stylesheet", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</head>

<body>
    <section id="content">
        <div class="container-center">
            <div class="mobile-size">
                <div class="row">
                    <div class="col-xl-12">
                        <div class="box-index">
                            <div class="box-banner">
                                <img src="frontend/assets/img/banner-login.png" class="img-fluid" alt="">
                            </div>
                            <p class="title-welcome">ยินดีต้อนรับเข้าสู่</p>
                            <h3 class="title-logosmall">ศูนย์รักษาข้อ</h3>
                            <h1 class="title-logo">CU-CAT</h1>
                            <p class="sub-welcome">CU Center for Arthritis Treatment</p>

                            <div class="box-titlebg">
                                <p class="title-box">Healthy joint for life</p>
                            </div>

                            <div class="box-button">
                                <a href="<?php echo e(url("login")); ?>" class="btn-custom btn-line"><i class="icofont-line"></i> เข้าสู่ระบบ TEST</a>
                            </div>
                            <div class="box-button">
                                <a href="<?php echo e(url("register")); ?>" class="btn-custom btn-line"><i class="icofont-line"></i> เข้าสู่ระบบด้วยไลน์</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <?php echo $__env->make("$prefix.layout.javascript", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</body>

</html><?php /**PATH C:\laragon\www\cretive\cu-cat.com\resources\views/front-end/index.blade.php ENDPATH**/ ?>