<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>CU-CAT</title>
  <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>" />
  <?php echo $__env->make("$prefix.layout.stylesheet", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</head>

<body>

  <section id="content">
    <div class="register">
      <div class="mobile-size">
        <div class="box-banner">
          <img src="frontend/assets/img/bg-register.png" class="img-fluid" alt="">
        </div>
        <div class="container-center">
          <div class="row">
            <div class="col-xl-12">

              <div class="box-title">
                <h1 class="title-logo">CU-CAT</h1>
                <p class="title-welcome">เข้าสู่ระบบ</p>
              </div>

              <!-- Form Register -->
              <form id="frm_cus" class="form w-100" action="" method="post" onsubmit="return login_submit();">
                <div class="mb-3">
                  <label for="phone" class="form-label">เบอร์โทรศัพท์</label>
                  <input type="text" name="phone" class="form-control" id="phone" placeholder="กรอกเบอร์โทรศัพท์">
                </div>

                <div class="mb-3">
                  <label for="password" class="form-label">รหัสผ่าน</label>
                  <input type="password" name="password" class="form-control" id="password" placeholder="กรอกรหัสผ่าน">
                </div>
                <button type="button" class="btn-custom btn-orange" onclick="login_submit();">เข้าสู่ระบบ</button>
              </form>
              <!-- End Form Register -->

            </div>
          </div>
        </div>
      </div>
    </div>
  </section>

  <?php echo $__env->make("$prefix.layout.javascript", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  <script src="frontend/assets/js/helpers.js"></script>
  <script>
    var fullUrl = window.location.origin + window.location.pathname;

    $.ajaxSetup({
        headers: {
            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
        }
    });
    function login_submit() {
        var formData = new FormData($("#frm_cus")[0]);
        var phone = $('#phone').val();
        var password = $('#password').val();
        if(phone == "" || password == ""){
            toastr.error("กรุณากรอกข้อมูลให้ครบถ้วน !");
            return false;
        }
        
        $.ajax({
            type: 'POST',
            url: fullUrl,
            data: formData,
            processData: false,
            contentType: false,
            dataType: 'json',
            success: function(data) {
                if(data.result == "success"){
                   location.href = "home";
                }else{
                    Swal.fire({
                        title: "" + data.title,
                        text: "" + data.text,
                        icon: 'error',
                        showCancelButton: false,
                        confirmButtonColor: '#3085d6',
                        cancelButtonColor: '#d33',
                        confirmButtonText: 'Close',
                    });
                }
            }
        });
    }
</script>


</body>

</html><?php /**PATH C:\laragon\www\cretive\cu-cat.com\resources\views/front-end/login.blade.php ENDPATH**/ ?>