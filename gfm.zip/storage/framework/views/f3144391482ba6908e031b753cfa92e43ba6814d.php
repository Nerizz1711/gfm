<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>CU-CAT</title>
  <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>" />
  <?php echo $__env->make("$prefix.layout.stylesheet", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</head>

<body>

  <section id="content">
    <div class="questionnaire">
      <div class="mobile-size">
        <!-- Header -->
        <?php echo $__env->make("$prefix.layout.header", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <!-- End Header -->
        <?php 
        $status = "";
        if(@$question->type == "vas"){ $status = "VAS"; }
        else if(@$question->type == "womac"){ $status = "Womac Score"; }
        else if(@$question->type == "sf12"){ $status = "SF-12"; }
        ?>
        <div class="row">
          <div class="col-xl-12">
            <div class="box-heading">
              <p class="name-heading"><?php echo e(@$status); ?></p>
            </div>
            <div class="container-center">
              <div class="box-question">
                <p class="topic-question-head">คำถามที่ <?php echo e(@$question->sort); ?>:</p>
                <p class="topic-question"><?php echo e(@$question->name); ?></p>
                <div class="progress" role="progressbar" aria-label="Basic example" aria-valuenow="0" aria-valuemin="0" aria-valuemax="100" style="height: 6px">
                  <div class="progress-bar" style="width: <?php echo e(@$percent); ?>%"></div>
                </div>
                <h3 class="title-question-sub"><?php echo e(@$question->detail); ?></h3>
                <?php $count_question = 0; ?>
                <form id="frm_cus" class="form w-100" action="" method="post">
                  <?php if(@$question): ?>
                    <?php $point = 0; ?>
                    <?php for($i=1; $i<=6; $i++): ?>
                      <?php $point = $question->{'sf12_point'.$i}; ?>
                      
                      <div class="box-itemselect" <?php if($question->{'sf12_choice'.$i} == "" && $question->{'sf12_point'.$i} == ""): ?> hidden <?php endif; ?>>
                        <div class="row">
                          <div class="col-12">
                            <div class="item-select">
                              <input type="radio" class="btn-check" <?php if(@$quest_point): ?><?php if(@$point == $quest_point->sf12_point): ?> checked <?php endif; ?> <?php endif; ?> data-name="<?php echo e($question->{'sf12_choice'.$i}); ?>" name="options_questionnaire" id="btn-check-outlined-<?php echo $i; ?>" autocomplete="off" onclick="getDataCheck(`<?php echo $question->{'sf12_choice'.$i}; ?>`,`<?php echo $question->{'sf12_point'.$i}; ?>`)">
                              <label class="btn btn-outline-primary  btn-questionaire" for="btn-check-outlined-<?php echo $i; ?>">
                                <div class="row">
                                  <div class="col-10">
                                    <span><?php echo e(@$question->{'sf12_choice'.$i}); ?></span>
                                  </div>
                                  <div class="col-2">
                                    <div class="circle-border"><i class="fa-solid fa-check"></i></div>
                                  </div>
                                </div>
                              </label>
                            </div>
                          </div>
                        </div>
                      </div>
                      
                      
                    <?php $count_question++; ?>
                    <?php endfor; ?>
                  <?php endif; ?>

                  <div class="box-resultcheck">
                    <p class="text-result">คำตอบของคุณ: <span id="checkResult"></span></p>
                  </div>
                  <input type="hidden" id="question_time_id" name="question_time_id" value="<?php echo e(@$time->id); ?>">
                  <input type="hidden" id="question_id" name="question_id" value="<?php echo e(@$question->id); ?>">
                  <input type="hidden" id="point" name="point" value="<?php echo e(@$quest_point->sf12_point); ?>">


                    <?php if($question->sort < $limit): ?>
                      <a href="javascript:void(0);" onclick="next_question(<?php echo e($question->sort+1); ?>);" class="btn disabled btn-nextpage" tabindex="-1" role="button" aria-disabled="false">ถัดไป</a>
                    <?php else: ?>
                      <a href="javascript:void(0)" onclick="next_question(0);" class="btn disabled btn-nextpage" tabindex="-1" role="button" aria-disabled="false">ถัดไป</a>
                    <?php endif; ?>

                    <?php if(@$question->sort == 1): ?>
                      <a href="<?php echo e(url("home")); ?>" class="btn-custom  btn-grays-outline" tabindex="-1" role="button" aria-disabled="false">ย้อนกลับ</a>
                    <?php else: ?>
                      <a href="<?php echo e(url("questionnaire?quest=".$question->sort - 1)); ?>" class="btn-custom  btn-grays-outline" tabindex="-1" role="button" aria-disabled="false">ย้อนกลับ</a>
                    <?php endif; ?>

                </form>
              </div>
            </div>
          </div>
        </div>
      </div>
  </section>

  <?php echo $__env->make("$prefix.layout.javascript", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  <?php if(@$quest_point && @$quest_point->sf12_point >= 0): ?>
  <script>
    $(document).ready(function(){
      for (var i = 1; i <= <?php echo e($count_question); ?>; i++) {
        var input = document.querySelector('input[name="options_questionnaire"][id="btn-check-outlined-' + i + '"]');
        if (input.checked) 
        {
          document.getElementById("checkResult").innerHTML = input.getAttribute('data-name');
        }
      }
      $('.btn-nextpage').removeClass('disabled')
    });
  </script>
  <?php endif; ?>
  
  <script>

    const getDataCheck = (e,i) => {
      document.getElementById("checkResult").innerHTML = e;
      $('#point').val(i);
      $('.btn-nextpage').removeClass('disabled')

    }
    var fullUrl = window.location.origin + window.location.pathname;
    function next_question(pagenext){

      var formData = new FormData($("#frm_cus")[0]);
        var point = $('#point').val();
        if(point == ""){
            toastr.error("Sorry, please complete the information.");
            return false;
        }
        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            }
        });
        $.ajax({
            type: 'POST',
            url: fullUrl,
            data: formData,
            processData: false,
            contentType: false,
            dataType: 'json',
            success: function(data) {
              console.log(data);
                if(data.status == "200"){
                  if(pagenext == 0){
                    location.href = "result-score";
                  }else{
                    location.href = "questionnaire?quest="+pagenext;
                  }
                }else{
                    Swal.fire({
                        title: "" + data.title,
                        text: "" + data.text,
                        icon: 'error',
                        showCancelButton: false,
                        confirmButtonColor: '#3085d6',
                        cancelButtonColor: '#d33',
                        confirmButtonText: 'Close',
                    });
                }
            }
        });
    }
  </script>
</body>

</html><?php /**PATH C:\laragon\www\cretive\cu-cat.com\resources\views/front-end/questionnaire-sf12.blade.php ENDPATH**/ ?>