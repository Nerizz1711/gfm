<!DOCTYPE html>
<html lang="en" class="light">
    <!-- BEGIN: Head -->
    <head>
        <?php echo $__env->make("$prefix.layout.header", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </head>
    <!-- END: Head -->
    <body class="main">
        
        <!-- BEGIN: MENU -->
        <?php echo $__env->make("$prefix.layout.menu-top", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <!-- END: Menu -->

       
        <div class="wrapper">
            <div class="wrapper-box">
                <!-- BEGIN: Side Menu -->
                <?php echo $__env->make("$prefix.layout.menu-slide", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <!-- END: Side Menu -->

                <!-- BEGIN: Content -->
                <div class="content">

                   <!-- BEGIN: Content -->
                    <div class="intro-y flex flex-col sm:flex-row items-center mt-8">
                        <h2 class="text-lg font-medium mr-auto">
                            ฟอร์มข้อมูล
                        </h2>
                    </div>
        
                    <form id="menuForm" method="post" action="" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                        <div class="grid grid-cols-12 gap-6 mt-5">
                            <div class="intro-y col-span-12 lg:col-span-6">
                                <!-- BEGIN: Form Layout -->
                                <div class="intro-y box p-5">

                                    <div class="grid grid-cols-12 gap-6 mt-5 mb-3">
                                        <div class="col-span-6 lg:col-span-6">
                                            <img id="example_image01" class="mb-2" src="no-img.png" class="img-fluid" alt="">
                                            <input name="image" id="image" type="file" class="custom-file-input" accept="image/*" onchange="readURL01(this);">
                                        </div>
                                    </div>
    
                                    <div class="grid grid-cols-12 gap-6 mt-5 mb-3">
                                        <div class="col-span-12 lg:col-span-12">
                                            <label for="horizontal-form-1" class="form-label">รูปภาพ <small class="form-help">(อัพโหลดรูปภาพเฉพาะไฟล์ *.png, *.jpg and *.jpeg image เท่านั้น)</small> </label> 
                                        </div>
                                    </div>
                                    
                                    <div class="grid grid-cols-12 gap-6 mt-5 mb-3">
                                        <div class="col-span-6 lg:col-span-6">
                                            <label for="crud-form-1" class="form-label">ระดับ</label>
                                            <select class="form-select" name="role" id="role">
                                                <option value="">กรุณาเลือก</option>
                                                <?php if(@$roles): ?>
                                                <?php $__currentLoopData = @$roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($role->id); ?>"><?php echo e($role->name); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                <?php endif; ?>
                                            </select>
                                        </div>
                                        <div class="col-span-6 lg:col-span-6">
                                            <label for="crud-form-1" class="form-label">สถานะ</label>
                                            <select class="form-control" name="isActive" id="isActive">
                                                <option value="" hidden>กรุณาเลือก</option>
                                                <option value="Y">ใช้งาน</option>
                                                <option value="N">ไม่ใช้งาน</option>
                                            </select>
                                        </div>
                                    </div>

                                    <div class="grid grid-cols-12 gap-6 mt-5 mb-3">
                                        <div class="col-span-6 lg:col-span-6">
                                            <label for="crud-form-1" class="form-label">ชื่อ <span class="text-danger">*</span></label>
                                            <input class="form-control" id="name" type="text" name="name" value="" placeholder="ชื่อ-นามสกุล" autocomplete="off">
                                        </div>
                                        <div class="col-span-6 lg:col-span-6">
                                            <label for="crud-form-1" class="form-label">เบอร์โทรติดต่อ</label>
                                            <input class="form-control" id="phone" type="text" name="phone" value="" placeholder="เบอร์โทรติดต่อ" autocomplete="off">
                                        </div>
                                    </div>

                                    <div class="grid grid-cols-12 gap-6 mt-5 mb-3">
                                        <div class="col-span-6 lg:col-span-6">
                                            <label for="crud-form-1" class="form-label">อีเมล <span class="text-danger">*</span></label>
                                            <input class="form-control" id="email" type="text" name="email" value="" placeholder="อีเมล" autocomplete="off">
                                        </div>
                                    </div>

                                    <div class="grid grid-cols-12 gap-6 mt-5 mb-3">
                                        <div class="col-span-6 lg:col-span-6">
                                            <label for="crud-form-1" class="form-label">รหัสผ่าน <span class="text-danger">*</span></label>
                                            <div class="input-group col-mb-6">
                                                <input type="password" id="password" class="form-control" name="password" placeholder="รหัสผ่าน" autocomplete="off">
                                                <div class="input-group-append">
                                                    <div class="input-group-text">
                                                        <span class="card-link show_pass"><i class="far fa-eye" data-id="password"></i></span>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-span-6 lg:col-span-6">
                                            <label for="crud-form-1" class="form-label">ยืนยันรหัสผ่าน <span class="text-danger">*</span></label>
                                            <div class="input-group col-mb-6">
                                                <input type="password" id="confirm_password" class="form-control" name="confirm_password" placeholder="ยืนยันรหัสผ่าน" autocomplete="off">
                                                <div class="input-group-append">
                                                    <div class="input-group-text">
                                                        <span class="card-link show_pass_confirm"><i class="far fa-eye" data-id="confirm_password"></i></span>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>

                                
                                    <div class="text-right mt-5">
                                        <a class="btn btn-outline-secondary w-24 mr-1" href="<?php echo e(url("$segment/$folder")); ?>">ยกเลิก</a>
                                        <button type="button" onclick="check_add();" class="btn btn-primary w-24">บันทึกข้อมูล</button>
                                    </div>
                                </div>
                                <!-- END: Form Layout -->
                            </div>
                        </div>
                    </form>

                </div>
                <!-- END: Content -->

                
            </div>
        </div>
 
        <!-- BEGIN: JS Assets-->
        <?php echo $__env->make("$prefix.layout.script", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <script>
        $("#example_image01").click(function() {
            $("input[id='image']").click();
        });

        function readURL01(input) {
            if (input.files && input.files[0]) {
                var reader = new FileReader();
                reader.onload = function(e) {
                    $('#example_image01').attr('src', e.target.result);
                }
                reader.readAsDataURL(input.files[0]);
            }
        }

        function check_add() {
            var role = $('#role').val();
            var status_check = $('#status_check').val();
            var name = $('#name').val();
            var email = $('#email').val();
            var password = $('#password').val();
            var confirm_password = $('#confirm_password').val();
            var resetpassword = $('#resetpassword').val();

            if (role == "") {
                toastr.error('กรุณาเลือกระดับของผู้ใช้งานนี้');
                return false;
            }
            if (status_check == "") {
                toastr.error('กรุณาเลือกสถานะการใช้งาน');
                return false;
            }
            if (name == "" || email == "" || password == "") {
                toastr.error('กรุณากรอกข้อมูลให้ครบถ้วนก่อนบันทึกรายการ');
                return false;
            }
            if (password != confirm_password) {
                toastr.error('กรุณากรอกรหัสผ่านให้เหมือนกัน');
                return false;
            }
            Swal.fire({
                icon: 'warning',
                title: 'กรุณากดยืนยันเพื่อทำรายการ',
                showCancelButton: true,
                confirmButtonText: 'ยืนยัน',
                cancelButtonText: `ยกเลิก`,
            }).then((result) => {
                if (result.isConfirmed) {
                    $('#menuForm').submit();
                }
            });
           
        }
        //== Script Ajax Regular ==
        $('#resetpassword').change(function() {
            if ($(this).prop("checked") == true) {
                $('#password').attr('disabled', false);
                $('#confirm_password').attr('disabled', false);
            } else if ($(this).prop("checked") == false) {
                $('#password').attr('disabled', true);
                $('#confirm_password').attr('disabled', true);
                $('#password').val(null);
                $('#confirm_password').val(null);
            }
        });

        $('.show_pass').click(function() {
            var password = $('#password').attr('type');
            if (password == "password") {
                $('#password').attr('type', 'text');
            } else {
                $('#password').attr('type', 'password');
            }
        });


        $('.show_pass_confirm').click(function() {
            var confirm_password = $('#confirm_password').attr('type');
            if (confirm_password == "password") {
                $('#confirm_password').attr('type', 'text');
            } else {
                $('#confirm_password').attr('type', 'password');
            }
        });
    
        </script>
        <!-- END: JS Assets-->
    </body>
</html><?php /**PATH C:\laragon\www\orange\pipat-template\resources\views/back-end/pages/administrator/user/add.blade.php ENDPATH**/ ?>