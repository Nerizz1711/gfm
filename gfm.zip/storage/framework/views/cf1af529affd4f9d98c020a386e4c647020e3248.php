<div id="kt_app_toolbar_container" class="app-container container-fluid d-flex flex-stack">
    <div class="page-title d-flex flex-column justify-content-center flex-wrap me-3">
        <?php
            $breadName = 'หน้าแรก';
        ?>
        <h1 class="page-heading d-flex text-dark fw-bold fs-3 flex-column justify-content-center my-0">
            <?php echo e(@$breadName); ?></h1>
        <ul class="breadcrumb breadcrumb-separatorless fw-semibold fs-7 my-0 pt-1">
            <li class="breadcrumb-item text-muted"><a href="<?php echo e(url('webpanel')); ?>" class="text-muted text-hover-primary">Dashboards</a> </li>
            <?php if(@$navs): ?>
                <?php $__currentLoopData = $navs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $nav): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li class="breadcrumb-item"><span class="bullet bg-gray-400 w-5px h-2px"></span></li>
                <li class="breadcrumb-item text-muted"><a href="<?php echo e(@$nav['url']); ?>" class="text-muted text-hover-primary"><?php echo e(@$nav['name']); ?></a></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
        </ul>
    </div>
</div>
<?php /**PATH C:\laragon\www\cretive\cu-cat.com\resources\views/back-end/layout/breadcrumbs.blade.php ENDPATH**/ ?>