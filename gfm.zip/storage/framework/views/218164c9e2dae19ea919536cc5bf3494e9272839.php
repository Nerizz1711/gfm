<?php
    $prefix = '';
    $member = App\Models\Backend\AdminModel::find(Auth::guard('admin')->id());
    $image = 'backend/assets/media/avatars/300-1.jpg';
?>

<div id="kt_app_sidebar" class="app-sidebar flex-column" data-kt-drawer="true" data-kt-drawer-name="app-sidebar" data-kt-drawer-activate="{default: true, lg: false}" data-kt-drawer-overlay="true" data-kt-drawer-width="225px" data-kt-drawer-direction="start" data-kt-drawer-toggle="#kt_app_sidebar_mobile_toggle">
    <!--begin::Logo-->
    <div class="app-sidebar-logo px-6" id="kt_app_sidebar_logo">
        <!--begin::Logo image-->
        <a href="<?php echo e(url("$segment")); ?>">
            <img alt="Logo" src="backend/assets/media/logos/default-dark.svg" class="h-25px app-sidebar-logo-default" />
            <img alt="Logo" src="backend/assets/media/logos/default-small.svg" class="h-20px app-sidebar-logo-minimize" />
        </a>
        
        <div id="kt_app_sidebar_toggle" class="app-sidebar-toggle btn btn-icon btn-shadow btn-sm btn-color-muted btn-active-color-primary h-30px w-30px position-absolute top-50 start-100 translate-middle rotate" data-kt-toggle="true" data-kt-toggle-state="active" data-kt-toggle-target="body" data-kt-toggle-name="app-sidebar-minimize">
            <i class="ki-duotone ki-black-left-line fs-3 rotate-180">
                <span class="path1"></span>
                <span class="path2"></span>
            </i>
        </div>
        <!--end::Sidebar toggle-->
    </div>
    <!--end::Logo-->

    <div class="app-sidebar-menu overflow-hidden flex-column-fluid">
        <div id="kt_app_sidebar_menu_wrapper" class="app-sidebar-wrapper">
            <div id="kt_app_sidebar_menu_scroll" class="scroll-y my-5 mx-3" data-kt-scroll="true" data-kt-scroll-activate="true" data-kt-scroll-height="auto" data-kt-scroll-dependencies="#kt_app_sidebar_logo, #kt_app_sidebar_footer" data-kt-scroll-wrappers="#kt_app_sidebar_menu" data-kt-scroll-offset="5px" data-kt-scroll-save-state="true">
                <div class="menu menu-column menu-rounded menu-sub-indention fw-semibold fs-6" id="#kt_app_sidebar_menu" data-kt-menu="true" data-kt-menu-expand="false">
                    
                    <?php $menus = \Helper::mainMenu(); ?>
                    <?php if(@$menus): ?>
                        <?php $__currentLoopData = @$menus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$menu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php $arraymenu = array(); ?>
                            <?php if($menu->position == "topic"): ?>
                            <div class="menu-item pt-5">
                                <div class="menu-content">
                                    <span class="menu-heading fw-bold text-uppercase fs-7"><?php echo e(@$menu->name); ?></span>
                                </div>
                            </div>
                            <?php else: ?>
                                <?php
                                $subs = \Helper::subMenu($menu->id);
                                 if($subs->count() > 0){
                                    foreach($subs as $submenu){
                                        array_push($arraymenu, $submenu->url);
                                    }
                                }
                                ?>
                                <!-- Begin:Menu -->
                                <?php if($subs->count() <= 0): ?>
                                <div class="menu-item">
                                    <a class="menu-link <?php if(@$folder == $menu->url): ?> active  <?php endif; ?>" href="<?php echo e("".$menu->url); ?>">
                                        <span class="menu-icon">
                                            <i class="<?php echo e(@$menu->icon); ?>"> </i>
                                        </span>
                                        <span class="menu-title"><?php echo e(@$menu->name); ?></span>
                                    </a>
                                </div>
                                <?php else: ?>
                                <div data-kt-menu-trigger="click" id="main_menu_<?php echo e(@$menu->id); ?>" class="menu-item menu-accordion">
                                    <!--begin:Menu link-->
                                    <span class="menu-link">
                                        <span class="menu-icon">
                                            <i class="<?php echo e(@$menu->icon); ?>"> </i>
                                        </span>
                                        <span class="menu-title"><?php echo e(@$menu->name); ?></span>
                                        <span class="menu-arrow"></span>
                                    </span>
                                    <!--end:Menu link-->
                                    <!--begin:Menu sub-->
                                    <div class="menu-sub menu-sub-accordion">
                                        <?php if($subs): ?>
                                            <?php $__currentLoopData = $subs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sub): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php 
                                            try{
                                                if(in_array(@$folder, $arraymenu)){
                                                    echo "<script>
                                                        var element = document.getElementById('main_menu_'+ $menu->id);
                                                            element.classList.add('here');
                                                            element.classList.add('show');
                                                        </script>";
                                                }
                                            }catch (\Exception $e) {
            
                                            }
                                            ?>
                                            
                                            <div class="menu-item">
                                                <a class="menu-link <?php if(@$folder == $sub->url): ?> active <?php endif; ?>" href="<?php echo e("".$sub->url); ?>">
                                                    <span class="menu-bullet">
                                                        <span class="bullet bullet-dot"></span>
                                                    </span>
                                                    <span class="menu-title"><?php echo e(@$sub->name); ?></span>
                                                </a>
                                            </div>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php endif; ?>
                                    </div>
                                    <!--end:Menu sub-->
                                </div>
                                <?php endif; ?>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>

                    
                    <div class="menu-item pt-5">
                        <div class="menu-content">
                            <span class="menu-heading fw-bold text-uppercase fs-7">Help</span>
                        </div>
                    </div>
                    <div class="menu-item">
                        <a class="menu-link" href="javascript:void(0);">
                            <span class="menu-icon">
                                <i class="ki-duotone ki-rocket fs-2">
                                    <span class="path1"></span>
                                    <span class="path2"></span>
                                </i>
                            </span>
                            <span class="menu-title">Components</span>
                        </a>
                    </div>
                    <div class="menu-item">
                        <a class="menu-link" href="javascript:void(0);">
                            <span class="menu-icon">
                                <i class="ki-duotone ki-abstract-26 fs-2">
                                    <span class="path1"></span>
                                    <span class="path2"></span>
                                </i>
                            </span>
                            <span class="menu-title">Documentation</span>
                        </a>
                    </div>
                    <div class="menu-item">
                        <a class="menu-link" href="javascript:void(0);">
                            <span class="menu-icon">
                                <i class="ki-duotone ki-code fs-2">
                                    <span class="path1"></span>
                                    <span class="path2"></span>
                                    <span class="path3"></span>
                                    <span class="path4"></span>
                                </i>
                            </span>
                            <span class="menu-title">Changelog v8.2.0</span>
                        </a>
                    </div>

                </div>
            </div>
        </div>
    </div>
    <!--begin::Footer-->
    <div class="app-sidebar-footer flex-column-auto pt-2 pb-6 px-6" id="kt_app_sidebar_footer">
        <a href="<?php echo e(url("$segment/logout")); ?>" class="btn btn-flex flex-center btn-custom btn-primary overflow-hidden text-nowrap px-0 h-40px w-100" data-bs-trigger="hover" data-bs-dismiss-="click" title="Sign Out">
            <span class="btn-label">Sign Out</span>
            <i class="ki-duotone ki-document btn-icon fs-2 m-0">
                <span class="path1"></span>
                <span class="path2"></span>
            </i>
        </a>
    </div>
    <!--end::Footer-->
</div><?php /**PATH C:\laragon\www\template\resources\views/back-end/layout/side-menu.blade.php ENDPATH**/ ?>