<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\Webpanel as Webpanel;
use App\Http\Controllers\Functions as Functions;
use App\Http\Controllers\Auth\LoginController;


Route::get('/line-login', [LoginController::class, 'index']);
Route::get('/login/line', [LoginController::class, 'redirectToProvider'])->name('login.line');
Route::get('/login/line/callback', [LoginController::class, 'handleProviderCallback']);